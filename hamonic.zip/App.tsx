
// FIX: Corrected the import statement. 'aistudio' is not exported from 'react'.
import React, { useState, useEffect } from 'react';
import { Screen, TarotCardData, AppState, ReadingLog, UserProfile, KarmaRitualType, ChatMessage } from './types';
import HomeScreen from './components/HomeScreen';
import MindFocusScreen from './components/MindFocusScreen';
import ReadingResultScreen from './components/ReadingResultScreen';
import BottomNavBar from './components/BottomNavBar';
import { MAJOR_ARCANA } from './constants';
import CharityScreen from './components/CharityScreen';
import CommunityScreen from './components/CommunityScreen';
import ProfileScreen from './components/ProfileScreen';
import IntuitionGameScreen from './components/IntuitionGameScreen';
import WallpaperScreen from './components/WallpaperScreen';
import WallpaperResultScreen from './components/WallpaperResultScreen';
import BirthChartScreen from './components/BirthChartScreen';
import BirthChartResultScreen from './components/BirthChartResultScreen';
import DonationUploadScreen from './components/DonationUploadScreen';
import OnboardingScreen from './components/OnboardingScreen';
import SymbolAnalysisScreen from './components/SymbolAnalysisScreen';
import SymbolAnalysisResultScreen from './components/SymbolAnalysisResultScreen';
import PalmReadingScreen from './components/PalmReadingScreen';
import PalmReadingResultScreen from './components/PalmReadingResultScreen';
import TransparencyLogScreen from './components/TransparencyLogScreen';
import KarmaClearingScreen from './components/KarmaClearingScreen';
import KarmaClearingResultScreen from './components/KarmaClearingResultScreen';
import PersonalCounselorScreen from './components/PersonalCounselorScreen';
import SubscriptionModal from './components/SubscriptionModal';
import { getPersonalAdvice } from './services/geminiService';
import { loadState, saveState, getInitialState, STORAGE_KEY } from './services/storageService';
import { checkAchievements } from './utils/achievementUtils';
import { soundService } from './services/soundService';


const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = React.useState<Screen>(Screen.Home);
  const [selectedCards, setSelectedCards] = React.useState<TarotCardData[] | null>(null);
  const [readingCategory, setReadingCategory] = React.useState<string>('ไพ่ประจำวัน');
  const [appState, setAppState] = React.useState<AppState>(loadState());
  const [wallpaperBirthYear, setWallpaperBirthYear] = React.useState<number | null>(null);
  const [birthChartData, setBirthChartData] = React.useState<{ year: number; day?: number; month?: number; type: 'chinese' | 'thai' } | null>(null);
  const [symbolAnalysisImage, setSymbolAnalysisImage] = React.useState<{data: string; mimeType: string} | null>(null);
  const [palmReadingImage, setPalmReadingImage] = React.useState<{data: string; mimeType: string} | null>(null);
  const [karmaClearingData, setKarmaClearingData] = React.useState<{ worryText: string; ritualType: KarmaRitualType } | null>(null);
  const [isCounselorLoading, setIsCounselorLoading] = React.useState(false);
  const [isSubscriptionModalOpen, setIsSubscriptionModalOpen] = React.useState(false);
  
  React.useEffect(() => {
    saveState(appState);
    // Sync sound mute state with app state
    soundService.setMute(!appState.isSoundEnabled);
  }, [appState]);

  // One-time setup for BGM on first interaction
  React.useEffect(() => {
    const handleInteraction = () => {
        if (appState.isSoundEnabled) {
            soundService.startBGM();
        }
        window.removeEventListener('click', handleInteraction);
        window.removeEventListener('touchstart', handleInteraction);
    };

    window.addEventListener('click', handleInteraction);
    window.addEventListener('touchstart', handleInteraction);

    return () => {
        window.removeEventListener('click', handleInteraction);
        window.removeEventListener('touchstart', handleInteraction);
    };
  }, [appState.isSoundEnabled]);

  const handleOnboardingComplete = (profile: UserProfile) => {
    soundService.playInteraction('success');
    setAppState(prevState => ({
      ...prevState,
      userProfile: profile,
      lastLogin: new Date().toISOString(),
    }));
  };

  const handleToggleSound = () => {
    soundService.triggerHaptic('light');
    setAppState(prevState => ({
      ...prevState,
      isSoundEnabled: !prevState.isSoundEnabled,
    }));
  };

  const handleNavigate = (screen: Screen) => {
    // Play Swoosh sound on navigation
    soundService.playInteraction('swoosh');
    setCurrentScreen(screen);
  };

  const handleStartReading = (category: string) => {
    soundService.playInteraction('tap');
    setReadingCategory(category);
    setCurrentScreen(Screen.MindFocus);
  };
  
  const handleStartWallpaper = () => {
    soundService.playInteraction('tap');
    setCurrentScreen(Screen.Wallpaper);
  };

  const handleStartBirthChart = () => {
    soundService.playInteraction('tap');
    setCurrentScreen(Screen.BirthChart);
  };

  const handleStartSymbolAnalysis = () => {
    soundService.playInteraction('tap');
    setCurrentScreen(Screen.SymbolAnalysis);
  };

  const handleStartPalmReading = () => {
    soundService.playInteraction('tap');
    setCurrentScreen(Screen.PalmReading);
  };

  const handleStartKarmaClearing = () => {
    soundService.playInteraction('tap');
    setCurrentScreen(Screen.KarmaClearing);
  };

  const handleStartPersonalCounselor = () => {
    soundService.playInteraction('tap');
    setCurrentScreen(Screen.PersonalCounselor);
  };
  
  const handleAnalyzeSymbol = (base64Data: string, mimeType: string) => {
    soundService.playInteraction('tap');
    setSymbolAnalysisImage({ data: base64Data, mimeType });
    setCurrentScreen(Screen.SymbolAnalysisResult);
  };

  const handleAnalyzePalm = (base64Data: string, mimeType: string) => {
    soundService.playInteraction('tap');
    setPalmReadingImage({ data: base64Data, mimeType });
    setCurrentScreen(Screen.PalmReadingResult);
  };

  const handleKarmaClearingComplete = (worryText: string, ritualType: KarmaRitualType) => {
    soundService.playInteraction('success');
    setKarmaClearingData({ worryText, ritualType });
    setCurrentScreen(Screen.KarmaClearingResult);
  };
  
  const handleGenerateWallpaper = (year: number) => {
    soundService.playInteraction('tap');
    setWallpaperBirthYear(year);
    setCurrentScreen(Screen.WallpaperResult);
  };
  
  const handleGenerateBirthChart = (year: number, type: 'chinese' | 'thai', day?: number, month?: number) => {
    soundService.playInteraction('tap');
    setBirthChartData({ year, day, month, type });
    setCurrentScreen(Screen.BirthChartResult);
  };

  const handleReadingComplete = () => {
    soundService.playInteraction('success');
    const shuffled = [...MAJOR_ARCANA].sort(() => 0.5 - Math.random());
    setSelectedCards(shuffled.slice(0, 3));
    setCurrentScreen(Screen.ReadingResult);
    
    setAppState(prevState => {
      const newState: AppState = {
        ...prevState,
        stats: {
          ...prevState.stats,
          meditations: prevState.stats.meditations + 1,
        }
      };
      const unlocked = checkAchievements(newState);
      return { ...newState, achievements: unlocked };
    });
  };

  const handleSaveReading = React.useCallback((log: ReadingLog) => {
    setAppState(prevState => {
      const today = new Date().toDateString();
      const lastReadingDate = prevState.streak.lastReadingDate;
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      
      let newStreakCount = prevState.streak.count;
      if (lastReadingDate !== today) {
        if (lastReadingDate === yesterday.toDateString()) {
          newStreakCount += 1;
        } else {
          newStreakCount = 1;
        }
      }

      const newState: AppState = {
        ...prevState,
        readings: [log, ...prevState.readings.slice(0, 49)],
        streak: {
          count: newStreakCount,
          lastReadingDate: today,
        },
        stats: {
          ...prevState.stats,
          readings: prevState.stats.readings + 1,
        }
      };
      
      const unlocked = checkAchievements(newState);
      return { ...newState, achievements: unlocked };
    });
  }, []);
  
  const handleVoted = () => {
    soundService.playInteraction('tap');
    setAppState(prevState => ({
      ...prevState,
      votedToday: new Date().toDateString()
    }));
  };

  const handleDonated = () => {
    soundService.playInteraction('success');
    setAppState(prevState => {
       const newState: AppState = {
        ...prevState,
        donatedToday: new Date().toDateString(),
        stats: {
          ...prevState.stats,
          donations: prevState.stats.donations + 1,
          meritPoints: (prevState.stats.meritPoints || 0) + 1 // Increment Merit Points
        }
      };
      const unlocked = checkAchievements(newState);
      return { ...newState, achievements: unlocked };
    });
  }

  const handleSendCounselorMessage = async (message: string) => {
    soundService.triggerHaptic('light'); // Feedback when sending
    const userMessage: ChatMessage = { role: 'user', parts: [{ text: message }] };
    const newHistory = [...appState.counselorChatHistory, userMessage];

    setAppState(prevState => ({ ...prevState, counselorChatHistory: newHistory }));
    setIsCounselorLoading(true);

    try {
      // Pass the userProfile to the service function
      const responseText = await getPersonalAdvice(newHistory, appState.userProfile);
      soundService.playInteraction('tap'); // Sound when message arrives
      const modelMessage: ChatMessage = { role: 'model', parts: [{ text: responseText }] };
      setAppState(prevState => ({
        ...prevState,
        counselorChatHistory: [...newHistory, modelMessage],
      }));
    } catch (error: any) {
      soundService.triggerHaptic('error');
      const errorMessage: ChatMessage = { role: 'model', parts: [{ text: `ขออภัยค่ะ: ${error.message}` }] };
       setAppState(prevState => ({
        ...prevState,
        counselorChatHistory: [...newHistory, errorMessage],
      }));
    } finally {
        setIsCounselorLoading(false);
    }
  };

  const handleImageGenerated = () => {
      soundService.playInteraction('success'); // Magic sound for image generation
      setAppState(prevState => ({
          ...prevState,
          dailyImageCount: (prevState.dailyImageCount || 0) + 1,
          lastImageGenDate: new Date().toDateString(),
      }));
  };

  // Premium Subscription Logic
  const handleOpenSubscription = () => {
      soundService.playInteraction('tap');
      setIsSubscriptionModalOpen(true);
  };

  const handleSubscribeConfirm = () => {
      setAppState(prev => ({ ...prev, isPremium: true }));
      setIsSubscriptionModalOpen(false);
      soundService.playInteraction('success'); // Celebration sound
  };

  const handleLogout = () => {
    soundService.playInteraction('tap');
    localStorage.removeItem(STORAGE_KEY);
    setAppState(getInitialState());
  };

  if (!appState.userProfile) {
    return (
       <div
        className="min-h-[100dvh] font-sans text-white bg-transparent overflow-hidden"
      >
        <div className="mx-auto max-w-md w-full h-[100dvh] flex flex-col relative overflow-hidden">
          <main className="flex-grow overflow-y-auto p-4 relative z-10">
             <OnboardingScreen onComplete={handleOnboardingComplete} />
          </main>
        </div>
      </div>
    );
  }

  const renderScreen = () => {
    const homeScreenProps = {
      onStartReading: handleStartReading,
      onStartWallpaper: handleStartWallpaper,
      onStartBirthChart: handleStartBirthChart,
      onStartSymbolAnalysis: handleStartSymbolAnalysis,
      onStartPalmReading: handleStartPalmReading,
      onStartKarmaClearing: handleStartKarmaClearing,
      onStartPersonalCounselor: handleStartPersonalCounselor,
      userName: appState.userProfile?.firstName || '',
      lastLogin: appState.lastLogin,
      streak: appState.streak.count,
      isPremium: appState.isPremium,
      onUpgrade: handleOpenSubscription,
      onNavigate: handleNavigate, // Added onNavigate to allow internal linking
    };
    
    const hasDonatedToday = appState.donatedToday === new Date().toDateString();
    const hasVotedToday = appState.votedToday === new Date().toDateString();

    switch (currentScreen) {
      case Screen.Home:
        return <HomeScreen {...homeScreenProps} />;
      case Screen.MindFocus:
        return <MindFocusScreen onComplete={handleReadingComplete} isSoundEnabled={appState.isSoundEnabled} onToggleSound={handleToggleSound} />;
      case Screen.ReadingResult:
        return selectedCards ? <ReadingResultScreen cards={selectedCards} category={readingCategory} onSaveReading={handleSaveReading} onVoted={handleVoted} hasVotedToday={hasVotedToday} onNavigate={handleNavigate} userName={appState.userProfile?.firstName} /> : <HomeScreen {...homeScreenProps} />;
      case Screen.Charity:
        return <CharityScreen onNavigate={handleNavigate} hasDonatedToday={hasDonatedToday} meritPoints={appState.stats.meritPoints || 0} />;
      case Screen.Community:
        return <CommunityScreen onNavigate={handleNavigate} />;
      case Screen.Profile:
        return <ProfileScreen appState={appState} onLogout={handleLogout} onNavigate={handleNavigate} onUpgrade={handleOpenSubscription} />;
      case Screen.IntuitionGame:
        return <IntuitionGameScreen />;
      case Screen.Wallpaper:
        return <WallpaperScreen onGenerate={handleGenerateWallpaper} onBack={() => handleNavigate(Screen.Home)} userDOB={appState.userProfile?.dob} />;
      case Screen.WallpaperResult:
        return wallpaperBirthYear ? <WallpaperResultScreen birthYear={wallpaperBirthYear} onBack={() => handleNavigate(Screen.Home)} onNavigate={handleNavigate} userName={appState.userProfile?.firstName} /> : <HomeScreen {...homeScreenProps} />;
      case Screen.BirthChart:
        return <BirthChartScreen onGenerate={handleGenerateBirthChart} onBack={() => handleNavigate(Screen.Home)} userDOB={appState.userProfile?.dob} />;
      case Screen.BirthChartResult:
        return birthChartData ? <BirthChartResultScreen birthYear={birthChartData.year} birthDay={birthChartData.day} birthMonth={birthChartData.month} type={birthChartData.type} onBack={() => handleNavigate(Screen.Home)} /> : <HomeScreen {...homeScreenProps} />;
      case Screen.DonationUpload:
        return <DonationUploadScreen onDonated={handleDonated} onNavigate={handleNavigate} />;
      case Screen.SymbolAnalysis:
        return <SymbolAnalysisScreen onAnalyze={handleAnalyzeSymbol} onBack={() => handleNavigate(Screen.Home)} />;
      case Screen.SymbolAnalysisResult:
        return symbolAnalysisImage ? <SymbolAnalysisResultScreen imageData={symbolAnalysisImage} onBack={() => handleNavigate(Screen.SymbolAnalysis)} /> : <HomeScreen {...homeScreenProps} />;
      case Screen.PalmReading:
        return <PalmReadingScreen onAnalyze={handleAnalyzePalm} onBack={() => handleNavigate(Screen.Home)} />;
      case Screen.PalmReadingResult:
        return palmReadingImage ? <PalmReadingResultScreen imageData={palmReadingImage} onBack={() => handleNavigate(Screen.PalmReading)} /> : <HomeScreen {...homeScreenProps} />;
      case Screen.TransparencyLog:
        return <TransparencyLogScreen onNavigate={handleNavigate} />;
      case Screen.KarmaClearing:
        return <KarmaClearingScreen onComplete={handleKarmaClearingComplete} onBack={() => handleNavigate(Screen.Home)} />;
      case Screen.KarmaClearingResult:
        return karmaClearingData ? <KarmaClearingResultScreen ritualType={karmaClearingData.ritualType} intention={karmaClearingData.worryText} onBack={() => handleNavigate(Screen.Home)} onNavigate={handleNavigate} /> : <HomeScreen {...homeScreenProps} />;
      case Screen.PersonalCounselor:
        return (
            <PersonalCounselorScreen 
                onBack={() => handleNavigate(Screen.Home)} 
                chatHistory={appState.counselorChatHistory} 
                onSendMessage={handleSendCounselorMessage} 
                isLoading={isCounselorLoading} 
                dailyImageCount={appState.dailyImageCount}
                isPremium={appState.isPremium}
                onImageGenerated={handleImageGenerated}
                onUpgrade={handleOpenSubscription}
                onNavigate={handleNavigate}
            />
        );
      default:
        return <HomeScreen {...homeScreenProps} />;
    }
  };

  return (
    <div
      className="min-h-[100dvh] font-sans text-white bg-transparent overflow-hidden pt-safe pb-safe"
    >
      {/* Main Container: Use px-safe-area for smart horizontal padding */}
      <div className="mx-auto max-w-md w-full h-[100dvh] flex flex-col relative overflow-hidden shadow-2xl">
        <main key={currentScreen} className="flex-grow overflow-y-auto px-safe-area py-4 pb-32 relative z-10 animate-fade-in no-scrollbar">
          {renderScreen()}
        </main>
        <BottomNavBar activeScreen={currentScreen} onNavigate={handleNavigate} />
        
        <SubscriptionModal 
          isOpen={isSubscriptionModalOpen}
          onClose={() => setIsSubscriptionModalOpen(false)}
          onConfirm={handleSubscribeConfirm}
        />
      </div>
    </div>
  );
};

export default App;