
// FIX: Added React import to resolve the 'Cannot find namespace React' error.
import React from 'react';

export enum Screen {
  Home = 'Home',
  MindFocus = 'MindFocus',
  ReadingResult = 'ReadingResult',
  Charity = 'Charity',
  Community = 'Community',
  Profile = 'Profile',
  IntuitionGame = 'IntuitionGame',
  Wallpaper = 'Wallpaper',
  WallpaperResult = 'WallpaperResult',
  BirthChart = 'BirthChart',
  BirthChartResult = 'BirthChartResult',
  DonationUpload = 'DonationUpload',
  Onboarding = 'Onboarding',
  SymbolAnalysis = 'SymbolAnalysis',
  SymbolAnalysisResult = 'SymbolAnalysisResult',
  PalmReading = 'PalmReading',
  PalmReadingResult = 'PalmReadingResult',
  TransparencyLog = 'TransparencyLog',
  KarmaClearing = 'KarmaClearing',
  KarmaClearingResult = 'KarmaClearingResult',
  PersonalCounselor = 'PersonalCounselor',
}

export interface TarotCardReadingDetail {
  position: string; // e.g., "Past", "Present", "Future"
  card_name_thai: string;
  interpretation: string;
}

export interface TarotReading {
  spread_type: string;
  cards: TarotCardReadingDetail[];
  overall_summary: string;
  lucky_action: string;
  daily_quest: string;
}

export interface TarotCardData {
  name: string;
  roman: string;
  imageKey: string;
}

export interface ReadingLog {
  date: string;
  category: string;
  cards: TarotCardData[];
  reading: TarotReading;
}

export interface StreakData {
  count: number;
  lastReadingDate: string | null;
}

export interface Stats {
  readings: number;
  meditations: number;
  donations: number;
  meritPoints: number; // New: Collected Golden Lotuses
}

export interface UserProfile {
  firstName: string;
  lastName?: string;
  dob?: {
    day?: number;
    month?: number;
    year: number; // Gregorian year
  };
}

export interface ChatMessage {
    role: 'user' | 'model';
    parts: { text: string }[];
}

export interface AppState {
  userProfile: UserProfile | null;
  isPremium: boolean; // Premium Status
  readings: ReadingLog[];
  streak: StreakData;
  achievements: string[]; // Array of achievement IDs
  stats: Stats;
  votedToday: string | null; // Date string
  donatedToday: string | null; // Date string
  isSoundEnabled: boolean;
  lastLogin?: string; // ISO date string
  counselorChatHistory: ChatMessage[];
  // Image Generation Quota
  dailyImageCount: number;
  lastImageGenDate: string | null;
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: React.FC<{className?: string}>;
  isUnlocked: (state: AppState) => boolean;
}

export interface BirthChartReading {
  title: string;
  personality: string;
  strength: string;
  weakness: string;
  guidance: string;
  future_age_forecast: {
    target_age: number;
    prediction: string;
    caution: string;
  };
  lucky_wallpaper_recommendation: {
    title: string;
    reason: string;
  };
}

export interface DigitalOriginAnalysis {
  is_ai_generated: boolean;
  ai_probability_score: number; // 0-100
  artifacts_found: string[]; // e.g., "Unnatural hands", "Warped text"
  verdict: string; // "Likely Real Photo" or "Likely AI Generated"
}

export interface SymbolAnalysisReading {
  symbol_identified: string;
  spiritual_insight: {
    title_th: string;
    guidance_th: string;
  };
  luck_insight: {
    title_th: string;
    primary_numbers: string[];
    justification_th: string;
  };
  digital_origin_analysis: DigitalOriginAnalysis;
}

export interface PalmLineAnalysis {
  description: string;
  prediction: string;
  age_timing?: string;
}

export interface PalmReadingAnalysis {
  hand_analysis: {
    life_line: PalmLineAnalysis;
    head_line: PalmLineAnalysis;
    heart_line: PalmLineAnalysis;
    fate_line: PalmLineAnalysis;
    dominant_mounts?: {
      mount_name: string;
      meaning: string;
    };
  };
  special_signs: string[];
  cautions: {
    health: string;
    finance: string;
    love: string;
  };
  final_verdict: string;
}

export interface VisualQualityAssessment {
  quality_assessment: {
    score: number;
    is_ready_for_analysis: boolean;
    feedback_message_th?: string;
  }
}

export interface TransparencyPost {
  id: string;
  date: string; // e.g., "มิถุนายน 2567"
  title: string;
  description: string;
  amount: number;
  proofImageUrl: string;
}

export type KarmaRitualType = 'lantern' | 'fish' | 'bird';

export interface KarmaClearingBlessing {
  blessing: string;
  guidance: string;
}

export interface LotteryPrediction {
    numbers_2_digit: string[];
    numbers_3_digit: string[];
    reasoning: string;
}