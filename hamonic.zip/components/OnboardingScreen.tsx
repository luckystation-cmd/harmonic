import React, { useState } from 'react';
import { UserProfile } from '../types';
import { ProfileIcon } from './icons';

interface OnboardingScreenProps {
  onComplete: (profile: UserProfile) => void;
}

const OnboardingScreen: React.FC<OnboardingScreenProps> = ({ onComplete }) => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [birthYear, setBirthYear] = useState('');
  const [birthMonth, setBirthMonth] = useState('');
  const [birthDay, setBirthDay] = useState('');

  const currentBuddhistYear = new Date().getFullYear() + 543;
  const minYear = currentBuddhistYear - 100;

  const handleSubmit = () => {
    if (!firstName.trim()) {
      alert('กรุณากรอกชื่อของคุณ');
      return;
    }

    let dob: UserProfile['dob'] | undefined = undefined;
    const yearNum = birthYear ? parseInt(birthYear, 10) : undefined;
    
    if (yearNum) {
        if (yearNum < minYear || yearNum > currentBuddhistYear) {
            alert(`ปี พ.ศ. ต้องอยู่ระหว่าง ${minYear} - ${currentBuddhistYear}`);
            return;
        }

        const monthNum = birthMonth ? parseInt(birthMonth, 10) : undefined;
        const dayNum = birthDay ? parseInt(birthDay, 10) : undefined;

        if (monthNum && (monthNum < 1 || monthNum > 12)) {
            alert('เดือนเกิดต้องอยู่ระหว่าง 1 - 12');
            return;
        }
        if (dayNum && (dayNum < 1 || dayNum > 31)) {
            alert('วันที่เกิดต้องอยู่ระหว่าง 1 - 31');
            return;
        }

        dob = {
            year: yearNum - 543, // Convert to Gregorian year for storage
            ...(dayNum && { day: dayNum }),
            ...(monthNum && { month: monthNum }),
        };
    }
    
    const profile: UserProfile = {
      firstName: firstName.trim(),
      lastName: lastName.trim() || undefined,
      dob,
    };
    onComplete(profile);
  };

  return (
    <div className="flex flex-col items-center justify-center h-full text-center text-slate-300 space-y-6 pt-8">
        <div style={{animationDelay: '100ms'}} className="animate-slide-in-up">
            <ProfileIcon className="w-20 h-20 text-purple-400" />
        </div>
        <div style={{animationDelay: '200ms'}} className="animate-slide-in-up">
            <h1 className="text-3xl font-bold text-amber-300">ยินดีต้อนรับ</h1>
            <p className="mt-2 max-w-xs text-slate-300/80">
                กรอกข้อมูลเพื่อสร้างประสบการณ์ที่เป็นส่วนตัวสำหรับคุณ
            </p>
        </div>

        <div style={{animationDelay: '300ms'}} className="w-full max-w-xs space-y-3 animate-slide-in-up">
            <input
                type="text"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                placeholder="ชื่อ (จำเป็น)"
                className="w-full bg-slate-800 border border-slate-600 rounded-lg p-3 text-center text-white placeholder-slate-400 font-semibold focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-amber-400"
                autoComplete="off"
                autoCorrect="off"
                spellCheck="false"
            />
            <input
                type="text"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                placeholder="นามสกุล (ไม่บังคับ)"
                className="w-full bg-slate-800 border border-slate-600 rounded-lg p-3 text-center text-white placeholder-slate-400 font-semibold focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-amber-400"
                autoComplete="off"
                autoCorrect="off"
                spellCheck="false"
            />
            <input
                type="number"
                value={birthYear}
                onChange={(e) => /^\d{0,4}$/.test(e.target.value) && setBirthYear(e.target.value)}
                placeholder="ปีเกิด พ.ศ. (ไม่บังคับ)"
                className="w-full bg-slate-800 border border-slate-600 rounded-lg p-3 text-center text-white placeholder-slate-400 font-semibold [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-amber-400"
                autoComplete="off"
                autoCorrect="off"
                spellCheck="false"
            />
             <div className="flex space-x-3">
                <input
                    type="number"
                    value={birthDay}
                    onChange={(e) => /^\d{0,2}$/.test(e.target.value) && setBirthDay(e.target.value)}
                    placeholder="วันที่เกิด"
                    className="w-1/2 bg-slate-800 border border-slate-600 rounded-lg p-3 text-center text-white placeholder-slate-400 font-semibold [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-amber-400"
                    autoComplete="off"
                    autoCorrect="off"
                    spellCheck="false"
                />
                <input
                    type="number"
                    value={birthMonth}
                    onChange={(e) => /^\d{0,2}$/.test(e.target.value) && setBirthMonth(e.target.value)}
                    placeholder="เดือนเกิด"
                    className="w-1/2 bg-slate-800 border border-slate-600 rounded-lg p-3 text-center text-white placeholder-slate-400 font-semibold [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-amber-400"
                    autoComplete="off"
                    autoCorrect="off"
                    spellCheck="false"
                />
            </div>
        </div>

        <p style={{animationDelay: '400ms'}} className="text-xs text-slate-500 max-w-xs pt-2 animate-slide-in-up">
            🔒 ข้อมูลนี้จะถูกบันทึกไว้ในอุปกรณ์ของคุณเท่านั้น
        </p>

        <div style={{animationDelay: '500ms'}} className="animate-slide-in-up">
            <button
                onClick={handleSubmit}
                disabled={!firstName.trim()}
                className={`px-8 py-3 rounded-full font-bold text-lg transition-all duration-300 ${
                firstName.trim()
                    ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/20 transform hover:scale-105'
                    : 'bg-slate-700 text-slate-400 cursor-not-allowed'
                }`}
            >
                เริ่มต้นการเดินทาง
            </button>
        </div>
    </div>
  );
};

export default OnboardingScreen;