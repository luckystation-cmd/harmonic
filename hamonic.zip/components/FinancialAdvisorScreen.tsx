import React, { useState, useEffect, useRef } from 'react';
import { ChatMessage } from '../types';
// FIX: FinancialAdvisorIcon is not an exported member of './icons'. Aliased CounselorIcon as it is a suitable generic icon for an advisor chat screen.
import { CounselorIcon as FinancialAdvisorIcon } from './icons';

interface FinancialAdvisorScreenProps {
  onBack: () => void;
  chatHistory: ChatMessage[];
  onSendMessage: (message: string) => void;
  isLoading: boolean;
}

const TypingIndicator: React.FC = () => (
    <div className="flex items-center space-x-2">
        <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></div>
        <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
        <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{animationDelay: '0.4s'}}></div>
    </div>
);

const FinancialAdvisorScreen: React.FC<FinancialAdvisorScreenProps> = ({ onBack, chatHistory, onSendMessage, isLoading }) => {
  const [inputMessage, setInputMessage] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatHistory, isLoading]);

  const handleSend = () => {
    if (inputMessage.trim() && !isLoading) {
      onSendMessage(inputMessage.trim());
      setInputMessage('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  return (
    <div className="flex flex-col h-full">
      <header className="flex items-center p-4 border-b border-slate-700 bg-slate-900/80 backdrop-blur-sm fixed top-0 left-0 right-0 max-w-md mx-auto z-20">
        <button onClick={onBack} className="text-amber-300 font-semibold">
          &larr; กลับ
        </button>
        <div className="flex-1 text-center">
            <h1 className="text-xl font-bold text-slate-200">ที่ปรึกษาการเงิน</h1>
        </div>
        <div className="w-8"></div>
      </header>

      <div className="flex-1 overflow-y-auto pt-20 pb-24 space-y-4 px-4">
        {chatHistory.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full text-center text-slate-400">
                <FinancialAdvisorIcon className="w-16 h-16 mb-4 text-green-400" />
                <p>สวัสดีครับ! มีอะไรให้ผมช่วยเรื่องการเงินวันนี้?</p>
                <p className="text-sm">(เช่น "อยากเริ่มลงทุนต้องทำยังไง?" หรือ "วิธีออมเงินให้ได้ผล")</p>
            </div>
        )}
        {chatHistory.map((msg, index) => (
          <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-xs md:max-w-md p-3 rounded-2xl ${
                msg.role === 'user' 
                ? 'bg-blue-600 text-white rounded-br-none' 
                : 'bg-slate-700 text-slate-200 rounded-bl-none'
            }`}>
              <p className="whitespace-pre-wrap">{msg.parts[0].text}</p>
            </div>
          </div>
        ))}
        {isLoading && (
            <div className="flex justify-start">
                <div className="bg-slate-700 text-slate-200 p-3 rounded-2xl rounded-bl-none">
                    <TypingIndicator />
                </div>
            </div>
        )}
        <div ref={chatEndRef} />
      </div>

      <footer className="fixed bottom-16 left-0 right-0 max-w-md mx-auto z-20 p-4 bg-slate-900/80 backdrop-blur-sm border-t border-slate-700">
        <div className="flex items-center space-x-2">
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="พิมพ์คำถามของคุณ..."
            disabled={isLoading}
            className="flex-1 bg-slate-800 border border-slate-600 rounded-full p-3 px-4 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-400"
          />
          <button
            onClick={handleSend}
            disabled={isLoading || !inputMessage.trim()}
            className="bg-amber-400 text-slate-900 rounded-full p-3 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </button>
        </div>
      </footer>
    </div>
  );
};

export default FinancialAdvisorScreen;