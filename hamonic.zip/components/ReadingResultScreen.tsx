
import React, { useState, useEffect, useRef } from 'react';
import { getTarotReading } from '../services/geminiService';
import { TarotReading, TarotCardData, ReadingLog, Screen } from '../types';
import TarotCard from './TarotCard';
import { soundService } from '../services/soundService';
import { LotusIcon } from './icons';

interface ReadingResultScreenProps {
  cards: TarotCardData[];
  category: string;
  onSaveReading: (log: ReadingLog) => void;
  onVoted: () => void;
  hasVotedToday: boolean;
  onNavigate: (screen: Screen) => void;
  userName?: string;
}

const FormattedText: React.FC<{ text: string }> = ({ text }) => {
    const parts = text.split(/(\*\*.*?\*\*|\*.*?\*)/g);
    return (
        <span>
            {parts.map((part, index) => {
                if (part.startsWith('**') && part.endsWith('**')) {
                    return <span key={index} className="font-bold text-amber-300">{part.slice(2, -2)}</span>;
                }
                if (part.startsWith('*') && part.endsWith('*')) {
                     return <span key={index} className="italic text-purple-300">{part.slice(1, -1)}</span>;
                }
                return <span key={index}>{part}</span>;
            })}
        </span>
    );
};

const LoadingIndicator: React.FC = () => (
    <div className="flex flex-col items-center justify-center h-full space-y-6 animate-fade-in">
        <div className="relative w-32 h-32">
            <div className="absolute inset-0 border-4 border-purple-500/30 rounded-full"></div>
            <div className="absolute inset-0 border-4 border-t-amber-400 rounded-full animate-spin"></div>
            <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-4xl animate-pulse">🔮</span>
            </div>
        </div>
        <p className="text-purple-200 font-medium animate-pulse">กำลังสื่อสารกับไพ่...</p>
    </div>
);

const ReadingResultScreen: React.FC<ReadingResultScreenProps> = ({ cards, category, onSaveReading, onVoted, hasVotedToday, onNavigate, userName }) => {
  const [reading, setReading] = useState<TarotReading | null>(null);
  const [revealedCards, setRevealedCards] = useState<boolean[]>([false, false, false]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Date formatting
  const today = new Date();
  const dateString = today.toLocaleDateString('th-TH-u-ca-buddhist', {
        day: '2-digit', month: 'short', year: 'numeric'
  }).replace('พ.ศ. ', '');

  useEffect(() => {
    const fetchReading = async () => {
      try {
        const cardNames = cards.map(c => c.name);
        const result = await getTarotReading(cardNames, category, userName);
        setReading(result);

        const logEntry: ReadingLog = {
          date: new Date().toISOString(),
          category,
          cards,
          reading: result,
        };
        onSaveReading(logEntry);

      } catch (err: any) {
        setError(err.message || 'เกิดข้อผิดพลาดในการรับคำทำนาย');
      } finally {
        setIsLoading(false);
      }
    };

    fetchReading();
  }, [cards, category, onSaveReading, userName]);

  const handleCardReveal = (index: number) => {
      if (revealedCards[index]) return;
      const newRevealed = [...revealedCards];
      newRevealed[index] = true;
      setRevealedCards(newRevealed);
      // Note: Haptic feedback is now handled inside TarotCard component on click
  };

  if (isLoading) return <LoadingIndicator />;
  if (error || !reading) return <div className="text-center text-red-400 pt-20">{error}</div>;

  const positions = ['อดีต (Past)', 'ปัจจุบัน (Present)', 'อนาคต (Future)'];

  return (
    <div className="space-y-8 pb-24 animate-fade-in">
        <header className="text-center space-y-1">
            <h1 className="text-2xl font-bold text-white drop-shadow-lg">{category}</h1>
            <p className="text-sm text-white/60">{dateString}</p>
            <p className="text-xs text-amber-400/80 uppercase tracking-widest">Three Card Spread</p>
        </header>

        {/* Cards Area */}
        <div className="grid grid-cols-3 gap-3 md:gap-4 w-full px-2">
            {cards.map((card, index) => (
                <div key={card.name} className="flex flex-col items-center space-y-2">
                    <p className="text-[10px] font-bold text-white/50 uppercase tracking-wider">{positions[index].split(' ')[1].replace(/[()]/g, '')}</p>
                    <TarotCard 
                        card={card} 
                        isRevealed={revealedCards[index]}
                        onReveal={() => handleCardReveal(index)}
                    />
                </div>
            ))}
        </div>

        {/* Interpretation Area - Shows up as cards are revealed */}
        <div className="space-y-4">
            {reading.cards.map((detail, index) => (
                <div 
                    key={index}
                    className={`transition-all duration-1000 ${revealedCards[index] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10 hidden'}`}
                >
                    <div className="glass-card p-5 rounded-xl border-l-4 border-purple-500">
                        <div className="flex items-center mb-2">
                            <span className="text-xs font-bold bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded mr-2">
                                {detail.position}
                            </span>
                            <h3 className="font-bold text-white">{detail.card_name_thai}</h3>
                        </div>
                        <p className="text-white/90 text-sm leading-relaxed">
                            <FormattedText text={detail.interpretation} />
                        </p>
                    </div>
                </div>
            ))}
        </div>

        {/* Summary - Shows only when all cards are revealed */}
        {revealedCards.every(r => r) && (
            <div className="animate-fade-in space-y-6">
                {/* Personalized Protection Blessing (Key Update) */}
                <div className="mt-2 p-4 bg-gradient-to-r from-purple-900/40 to-indigo-900/40 rounded-xl border border-purple-500/20 backdrop-blur-sm text-center relative overflow-hidden shadow-lg">
                    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-amber-400/50 to-transparent opacity-50"></div>
                    <p className="text-white/90 text-xs italic font-medium leading-relaxed">
                        "แด่คุณ <span className="text-amber-300 font-bold">{userName || 'เจ้าของชะตา'}</span>... <br/>
                        เสริมอำนาจบารมี ปกป้องคุ้มภัย และเอาชนะอุปสรรคศัตรูทั้งปวง นำพาความสำเร็จและความเจริญรุ่งเรืองมาสู่ชีวิต"
                    </p>
                </div>

                <div className="bg-gradient-to-br from-amber-900/40 to-orange-900/40 p-6 rounded-2xl border border-amber-500/30 text-center shadow-lg">
                    <h3 className="text-lg font-bold text-amber-200 mb-3">บทสรุปคำทำนาย</h3>
                    <p className="text-white text-lg font-medium italic leading-relaxed">
                        "<FormattedText text={reading.overall_summary} />"
                    </p>
                </div>

                <div className="bg-white/5 p-5 rounded-xl border border-white/10 flex items-start space-x-4">
                    <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0">
                        <span className="text-xl">🍀</span>
                    </div>
                    <div>
                        <h4 className="font-bold text-green-300 text-sm uppercase tracking-wider mb-1">Lucky Action</h4>
                        <p className="text-white/80 text-sm"><FormattedText text={reading.lucky_action} /></p>
                    </div>
                </div>
                
                {/* Money Spot Button (Charity Nudge) */}
                <div className="flex justify-center pt-2">
                    <button 
                        onClick={() => onNavigate(Screen.Charity)}
                        className="flex items-center space-x-2 bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-300 hover:to-orange-400 text-white px-6 py-3 rounded-full text-sm font-bold border border-white/20 shadow-[0_0_15px_rgba(251,191,36,0.5)] transition-all transform hover:scale-105 active:scale-95 animate-pulse-slow"
                    >
                        <LotusIcon className="w-5 h-5" />
                        <span>บูชาครู 9.-</span>
                    </button>
                </div>
                
                {!hasVotedToday && (
                    <button onClick={onVoted} className="w-full py-3 rounded-full border border-white/20 text-white/60 hover:bg-white/5 hover:text-white transition-colors text-sm">
                        บันทึกความรู้สึกวันนี้
                    </button>
                )}
            </div>
        )}
        
        {!revealedCards.every(r => r) && (
             <p className="text-center text-white/40 text-sm animate-pulse">แตะที่ไพ่แต่ละใบเพื่อเปิดคำทำนาย</p>
        )}
    </div>
  );
};

export default ReadingResultScreen;
