
import React, { useState, useEffect, useRef } from 'react';
import { getBirthChartAnalysis } from '../services/geminiService';
import { BirthChartReading } from '../types';
import { BirthChartIcon } from './icons';

interface BirthChartResultScreenProps {
  birthYear: number;
  birthDay?: number;
  birthMonth?: number;
  type: 'chinese' | 'thai';
  onBack: () => void;
}

const loadingMessages = [
  "กำลังวิเคราะห์ดวงชะตา...",
  "ตรวจสอบการโคจรของดวงดาว...",
  "คำนวณอายุย่างและเกณฑ์ชะตา...",
  "ค้นหาคำแนะนำสำหรับคุณ...",
];

// Shared Text Formatter
const FormattedText: React.FC<{ text: string }> = ({ text }) => {
    if (!text) return null;
    // Split by bold markers (**)
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return (
        <span>
            {parts.map((part, index) => {
                if (part.startsWith('**') && part.endsWith('**')) {
                    // Render bold text in amber color
                    return <span key={index} className="font-bold text-amber-600 dark:text-amber-400">{part.slice(2, -2)}</span>;
                }
                // Render normal text
                return <span key={index}>{part}</span>;
            })}
        </span>
    );
};

interface BirthChartProgressIndicatorProps {
  isComplete: boolean;
  onAnimationEnd: () => void;
}

const BirthChartProgressIndicator: React.FC<BirthChartProgressIndicatorProps> = ({ isComplete, onAnimationEnd }) => {
  const [progress, setProgress] = useState(0);
  const [message, setMessage] = useState(loadingMessages[0]);
  const isDoneRef = useRef(false);

  useEffect(() => {
    const messageInterval = setInterval(() => {
      if (isDoneRef.current) return;
      setMessage(prevMessage => {
        const currentIndex = loadingMessages.indexOf(prevMessage);
        const nextIndex = (currentIndex + 1) % loadingMessages.length;
        return loadingMessages[nextIndex];
      });
    }, 2500);

    const progressInterval = setInterval(() => {
      if (isDoneRef.current) return;
      setProgress(prev => {
        if (prev >= 90) return prev;
        const increment = Math.random() * 5;
        return Math.min(prev + increment, 90);
      });
    }, 500);

    return () => {
      clearInterval(messageInterval);
      clearInterval(progressInterval);
    };
  }, []);

  useEffect(() => {
    if (isComplete) {
      isDoneRef.current = true;
      setProgress(100);
      setMessage("วิเคราะห์เสร็จสิ้น!");
      setTimeout(() => {
        onAnimationEnd();
      }, 1000);
    }
  }, [isComplete, onAnimationEnd]);


  const circumference = 2 * Math.PI * 28;
  const offset = circumference - (progress / 100) * circumference;

  return (
    <div className="flex flex-col items-center justify-center text-center space-y-4">
      <div className="relative w-32 h-32">
        <svg className="w-full h-full" viewBox="0 0 64 64">
          <circle
            className="text-stone-300/50 dark:text-stone-500/50"
            strokeWidth="4"
            stroke="currentColor"
            fill="transparent"
            r="28"
            cx="32"
            cy="32"
          />
          <circle
            className="text-purple-500 dark:text-purple-300"
            strokeWidth="4"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
            stroke="currentColor"
            fill="transparent"
            r="28"
            cx="32"
            cy="32"
            style={{ transform: 'rotate(-90deg)', transformOrigin: '50% 50%', transition: 'stroke-dashoffset 0.5s ease-out' }}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center font-bold text-lg text-purple-900 dark:text-white">
          {Math.round(progress)}%
        </div>
      </div>
      <p className="text-purple-900 dark:text-white font-medium transition-opacity duration-500">{message}</p>
    </div>
  );
};


const ResultSection: React.FC<{ title: string; content: string; icon: string; }> = ({ title, content, icon }) => (
    <div className="bg-white/50 dark:bg-white/5 p-4 rounded-lg border border-black/10 dark:border-white/10">
        <h3 className="text-lg font-semibold text-purple-800 dark:text-white mb-2 flex items-center">
            <span className="text-2xl mr-3">{icon}</span>
            {title}
        </h3>
        <p className="text-stone-700 dark:text-stone-300 whitespace-pre-wrap leading-relaxed">
            <FormattedText text={content} />
        </p>
    </div>
);

const BirthChartResultScreen: React.FC<BirthChartResultScreenProps> = ({ birthYear, birthDay, birthMonth, type, onBack }) => {
  const [reading, setReading] = useState<BirthChartReading | null>(null);
  const [isUiLoading, setIsUiLoading] = useState(true);
  const [isApiFinished, setIsApiFinished] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const generate = async () => {
      try {
        const result = await getBirthChartAnalysis(birthYear, birthDay, birthMonth, type);
        setReading(result);
      } catch (err: any) {
        setError(err.message || 'ไม่สามารถวิเคราะห์ดวงชะตาได้ กรุณาลองใหม่');
        console.error(err);
      } finally {
        setIsApiFinished(true);
      }
    };
    generate();
  }, [birthYear, birthDay, birthMonth, type]);

  const getFormattedDate = () => {
    const yearBE = birthYear + 543;
    if (birthDay && birthMonth) {
        const thaiMonths = [ "มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน", "กรกฎาคม", "สิงหาคม", "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม"];
        return `วันที่ ${birthDay} ${thaiMonths[birthMonth - 1]} ${yearBE}`;
    }
    return `ปีเกิด ${yearBE}`;
  }

  const handleOrderWallpaper = (promptTitle: string) => {
      alert(`ระบบกำลังนำคุณไปสร้าง "${promptTitle}"...\n(ฟีเจอร์จำลอง: กด OK เพื่อกลับหน้าหลักแล้วลองไปที่เมนู "AI จิตรกรสายมู")`);
      onBack();
  }

  if (isUiLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <BirthChartProgressIndicator 
          isComplete={isApiFinished}
          onAnimationEnd={() => setIsUiLoading(false)}
        />
      </div>
    );
  }

  if (error || !reading) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center">
        <p className="text-red-400 mb-4">{error}</p>
        <button onClick={onBack} className="bg-black/5 dark:bg-white/10 border border-black/10 dark:border-white/20 text-stone-700 dark:text-stone-200 py-2 px-6 rounded-full font-semibold transition-colors hover:bg-black/10 dark:hover:bg-white/20">
          กลับหน้าหลัก
        </button>
      </div>
    );
  }

  return (
    <div className="animate-fade-in space-y-6 pb-20">
      <header className="text-center space-y-2">
         <BirthChartIcon className="w-12 h-12 mx-auto text-purple-600 dark:text-purple-300"/>
        <h1 className="text-2xl font-bold text-purple-900 dark:text-white">{`ผลการวิเคราะห์ดวงชะตา`}</h1>
        <p className="text-lg font-medium text-purple-800 dark:text-purple-200">({type === 'chinese' ? 'โหราศาสตร์จีน' : 'โหราศาสตร์ไทย'})</p>
        <h2 className="text-xl font-bold text-purple-900 dark:text-white">{getFormattedDate()}</h2>
        <p className="text-xl font-medium text-stone-900 dark:text-amber-200"><FormattedText text={reading.title} /></p>
      </header>
      
      <div className="space-y-4">
          {/* Future Age Forecast Section - Highlighted */}
          {reading.future_age_forecast && (
              <div className="bg-gradient-to-br from-purple-900/80 to-indigo-900/80 p-5 rounded-xl border border-amber-400/50 shadow-lg transform hover:scale-[1.01] transition-transform">
                   <h3 className="text-lg font-bold text-amber-300 mb-3 flex items-center">
                        <span className="text-2xl mr-3">⏳</span>
                        ดวงชะตาย่างเข้าอายุ {reading.future_age_forecast.target_age} ปี
                   </h3>
                   <div className="space-y-3">
                       <div>
                           <span className="text-xs font-bold text-purple-200 uppercase tracking-wider bg-white/10 px-2 py-0.5 rounded">คำทำนาย</span>
                           <p className="text-white mt-1 leading-relaxed"><FormattedText text={reading.future_age_forecast.prediction} /></p>
                       </div>
                       <div className="bg-red-900/20 p-3 rounded-lg border border-red-500/30">
                           <span className="text-xs font-bold text-red-300 uppercase tracking-wider">⚠️ ข้อควรระวัง</span>
                           <p className="text-white/90 mt-1 text-sm"><FormattedText text={reading.future_age_forecast.caution} /></p>
                       </div>
                   </div>
              </div>
          )}

          <ResultSection title="ลักษณะนิสัย" content={reading.personality} icon="👤" />
          <ResultSection title="จุดแข็ง" content={reading.strength} icon="💪" />
          <ResultSection title="จุดอ่อน" content={reading.weakness} icon="🤔" />
          <ResultSection title="คำแนะนำ" content={reading.guidance} icon="✨" />

          {/* Cross-Selling Section */}
          {reading.lucky_wallpaper_recommendation && (
               <div className="glass-card p-5 rounded-xl border border-white/10 mt-6 relative overflow-hidden">
                    <div className="absolute top-0 right-0 -mt-4 -mr-4 w-24 h-24 bg-amber-400/20 rounded-full blur-2xl"></div>
                    <h3 className="text-md font-bold text-white flex items-center mb-2">
                        <span className="text-xl mr-2">🎨</span> เสริมดวงรับวัย {reading.future_age_forecast?.target_age || 'ใหม่'}
                    </h3>
                    <p className="text-sm text-white/80 mb-4">
                        <FormattedText text={reading.lucky_wallpaper_recommendation.reason} /> <br/>
                        <span className="text-amber-300 font-bold">แนะนำ: "<FormattedText text={reading.lucky_wallpaper_recommendation.title} />"</span>
                    </p>
                    <button 
                        onClick={() => handleOrderWallpaper(reading.lucky_wallpaper_recommendation.title)}
                        className="w-full bg-gradient-to-r from-amber-400 to-orange-500 text-purple-900 font-bold py-3 rounded-full shadow-lg hover:shadow-amber-400/30 transition-all active:scale-95 flex items-center justify-center"
                    >
                        <span>เนรมิตวอลเปเปอร์นี้ทันที</span>
                        <span className="ml-2 text-xs bg-white/20 px-1.5 py-0.5 rounded">AI Art</span>
                    </button>
               </div>
          )}
      </div>

       <div className="pt-4">
         <button onClick={onBack} className="w-full bg-black/5 dark:bg-white/10 border border-black/10 dark:border-white/20 text-stone-700 dark:text-stone-200 py-3 rounded-full font-semibold transition-colors hover:bg-black/10 dark:hover:bg-white/20">
            กลับหน้าหลัก
        </button>
       </div>
    </div>
  );
};

export default BirthChartResultScreen;
