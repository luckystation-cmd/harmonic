

import React, { useMemo } from 'react';
import { CommunityIcon, BrainIcon } from './icons';
import { Screen, TarotCardData } from '../types';
import { MAJOR_ARCANA } from '../constants';
import TarotCard from './TarotCard';

interface CommunityScreenProps {
    onNavigate: (screen: Screen) => void;
}

const CommunityScreen: React.FC<CommunityScreenProps> = ({ onNavigate }) => {
    const dailyFeedCards = useMemo(() => {
        const shuffled = [...MAJOR_ARCANA].sort(() => 0.5 - Math.random());
        return shuffled.slice(0, 6);
    }, []);

    return (
        <div className="space-y-8">
            <header style={{animationDelay: '100ms'}} className="text-center animate-slide-in-up">
                <CommunityIcon className="w-12 h-12 mx-auto mb-2 text-amber-200" />
                <h1 className="text-3xl font-bold text-amber-200">ชุมชนสายมู</h1>
                <p className="text-slate-300/80">เชื่อมต่อและเติบโตไปด้วยกัน</p>
            </header>

            <section 
                style={{animationDelay: '200ms'}}
                onClick={() => onNavigate(Screen.IntuitionGame)}
                className="bg-slate-800/50 backdrop-blur-md rounded-2xl p-6 border border-slate-700 text-center cursor-pointer transform hover:scale-105 transition-transform duration-300 flex items-center justify-center space-x-4 animate-slide-in-up"
            >
                <BrainIcon className="w-10 h-10 text-amber-200"/>
                <div>
                    <h2 className="text-xl font-bold text-amber-300 mb-1">ทดสอบสัญชาตญาณ</h2>
                    <p className="text-slate-200">ทดสอบและพัฒนาสัญชาตญาณของคุณ</p>
                </div>
            </section>

            <section style={{animationDelay: '300ms'}} className="animate-slide-in-up">
                <h3 className="text-lg font-semibold text-amber-200 mb-4">ตรวจสอบพลังงานประจำวัน</h3>
                <div className="bg-slate-800/50 backdrop-blur-md rounded-xl p-4 border border-slate-700">
                    <p className="text-center text-sm text-slate-300/80 mb-3">สถิติ Vibe ของผู้ใช้ทั้งหมดในวันนี้</p>
                    <div className="space-y-2 text-slate-200">
                        <div className="flex items-center">
                            <span className="w-20 text-sm">ดีมาก 👍</span>
                            <div className="w-full bg-black/20 rounded-full h-4"><div className="bg-green-500 h-4 rounded-full" style={{width: '65%'}}></div></div>
                        </div>
                         <div className="flex items-center">
                            <span className="w-20 text-sm">ปกติ 😐</span>
                            <div className="w-full bg-black/20 rounded-full h-4"><div className="bg-blue-500 h-4 rounded-full" style={{width: '25%'}}></div></div>
                        </div>
                         <div className="flex items-center">
                            <span className="w-20 text-sm">ท้าทาย 💪</span>
                            <div className="w-full bg-black/20 rounded-full h-4"><div className="bg-red-500 h-4 rounded-full" style={{width: '10%'}}></div></div>
                        </div>
                    </div>
                     <p className="text-center text-xs text-slate-400 mt-3">โหวตได้หลังดูไพ่ประจำวันของคุณ</p>
                </div>
            </section>
            
            <section style={{animationDelay: '400ms'}} className="animate-slide-in-up">
                <h3 className="text-lg font-semibold text-amber-200 mb-4">ไพ่จากชุมชน</h3>
                <p className="text-sm text-slate-400 mb-4">ไพ่ที่เพื่อนๆ ในชุมชนได้รับในวันนี้ (ข้อมูลจำลอง)</p>
                <div className="grid grid-cols-3 gap-4">
                    {dailyFeedCards.map(card => (
                        <div key={card.name} className="opacity-70">
                            <TarotCard card={card}/>
                        </div>
                    ))}
                </div>
            </section>
        </div>
    );
};

export default CommunityScreen;