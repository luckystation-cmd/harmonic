
import React, { useState, useEffect } from 'react';
import { generateWallpaperImage } from '../services/geminiService';
import { Screen } from '../types';
import { LotusIcon } from './icons';

interface WallpaperResultScreenProps {
  birthYear: number;
  onBack: () => void;
  onNavigate: (screen: Screen) => void;
  userName?: string;
}

const loadingMessages = [
  "กำลังรังสรรค์วอลเปเปอร์...",
  "ผสมผสานพลังแห่งดวงดาว...",
  "เลือกสรรสีมงคลสำหรับคุณ...",
  "ปลุกเสกพลังงานศักดิ์สิทธิ์...",
];

interface WallpaperProgressIndicatorProps {
  isComplete: boolean;
  onAnimationEnd: () => void;
}

const WallpaperProgressIndicator: React.FC<WallpaperProgressIndicatorProps> = ({ isComplete, onAnimationEnd }) => {
  const [message, setMessage] = useState(loadingMessages[0]);

  useEffect(() => {
    if (isComplete) {
      setMessage("สร้างวอลเปเปอร์เสร็จสิ้น!");
      setTimeout(onAnimationEnd, 1200);
      return;
    }

    const interval = setInterval(() => {
      setMessage(prevMessage => {
        const currentIndex = loadingMessages.indexOf(prevMessage);
        const nextIndex = (currentIndex + 1) % loadingMessages.length;
        return loadingMessages[nextIndex];
      });
    }, 3000);

    return () => clearInterval(interval);
  }, [isComplete, onAnimationEnd]);
  
  if (isComplete) {
     return (
       <div className="flex flex-col items-center justify-center text-center space-y-6 animate-fade-in">
        <div className="relative w-24 h-24 flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="w-20 h-20 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
        </div>
        <p className="text-purple-900 dark:text-amber-200 font-medium">{message}</p>
      </div>
    );
  }
  
  return (
    <div className="flex flex-col items-center justify-center text-center space-y-6">
      <div className="relative w-24 h-24">
        <div className="absolute inset-0 rounded-full bg-purple-500/20 dark:bg-amber-300/20 animate-pulse-slow"></div>
        <svg xmlns="http://www.w3.org/2000/svg" className="w-full h-full text-purple-600 dark:text-amber-300 relative" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.25 12l2.846.813a4.5 4.5 0 01-3.09 3.09L15 18.75l-.813-2.846a4.5 4.5 0 013.09-3.09zM18.25 12l2.846-.813a4.5 4.5 0 00-3.09-3.09L15 5.25l-.813 2.846a4.5 4.5 0 003.09 3.09z" />
        </svg>
      </div>
      <p className="text-purple-900 dark:text-amber-200 font-medium transition-opacity duration-500">{message}</p>
      <p className="text-stone-600 dark:text-stone-300 text-sm max-w-xs">ขั้นตอนนี้อาจใช้เวลาสักครู่ โปรดรอสักครู่และอย่าปิดแอปพลิเคชัน</p>
      <style>{`
        @keyframes pulse-slow {
          0%, 100% { opacity: 0.7; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.15); }
        }
        .animate-pulse-slow {
          animation: pulse-slow 3s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
      `}</style>
    </div>
  );
};


const WallpaperResultScreen: React.FC<WallpaperResultScreenProps> = ({ birthYear, onBack, onNavigate, userName }) => {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [isUiLoading, setIsUiLoading] = useState(true);
  const [isApiFinished, setIsApiFinished] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const generate = async () => {
      try {
        const base64Image = await generateWallpaperImage(birthYear);
        setImageUrl(`data:image/jpeg;base64,${base64Image}`);
      } catch (err: any) {
        setError(err.message || 'ไม่สามารถสร้างวอลเปเปอร์ได้ กรุณาลองใหม่ในภายหลัง');
        console.error(err);
      } finally {
        setIsApiFinished(true);
      }
    };
    generate();
  }, [birthYear]);

  if (isUiLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <WallpaperProgressIndicator 
          isComplete={isApiFinished}
          onAnimationEnd={() => setIsUiLoading(false)}
        />
      </div>
    );
  }

  if (error || !imageUrl) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center">
        <p className="text-red-400 mb-4">{error}</p>
        <button onClick={onBack} className="bg-black/5 dark:bg-white/10 border border-black/10 dark:border-white/20 text-stone-700 dark:text-stone-200 py-2 px-6 rounded-full font-semibold transition-colors hover:bg-black/10 dark:hover:bg-white/20">
          กลับหน้าหลัก
        </button>
      </div>
    );
  }

  return (
    <div className="animate-fade-in space-y-6 pb-20">
      <div className="text-center">
        <h1 className="text-2xl font-bold text-purple-900 dark:text-amber-200">วอลเปเปอร์มงคล</h1>
        {/* Personalized Blessing */}
        <div className="mt-4 p-4 bg-white/5 rounded-xl border border-amber-500/20 backdrop-blur-sm shadow-lg">
            <p className="text-white/90 text-sm italic font-medium leading-relaxed">
                "สำหรับคุณ <span className="text-amber-300 font-bold">{userName || 'เจ้าของชะตา'}</span>... <br/>
                เสริมอำนาจบารมี ปกป้องคุ้มภัย และเอาชนะอุปสรรคศัตรูทั้งปวง นำพาความสำเร็จและความเจริญรุ่งเรืองมาสู่ชีวิต"
            </p>
        </div>
        <p className="text-white/50 text-[10px] mt-2 opacity-70">
           Created by Lucky Station App (Download Free)
        </p>
      </div>
      
      {imageUrl && (
        <div className="flex flex-col items-center space-y-6">
            <div className="relative group">
                <div className="absolute -inset-1 bg-gradient-to-r from-amber-300 to-purple-600 rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-1000"></div>
                <img src={imageUrl} alt="Generated wallpaper for luck" className="relative rounded-2xl shadow-2xl shadow-black/50 w-full max-w-[240px] aspect-[9/16] object-cover border border-white/10" />
            </div>
            
            {/* Money Spot Button (Charity Nudge) */}
            <button 
                onClick={() => onNavigate(Screen.Charity)}
                className="flex items-center space-x-2 bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-300 hover:to-orange-400 text-white px-6 py-3 rounded-full text-sm font-bold border border-white/20 shadow-[0_0_15px_rgba(251,191,36,0.5)] transition-all transform hover:scale-105 active:scale-95 animate-pulse-slow"
            >
                <LotusIcon className="w-5 h-5" />
                <span>บูชาครู 9.-</span>
            </button>

            <div className="flex space-x-4 w-full max-w-sm px-4">
                 <button onClick={onBack} className="flex-1 bg-black/20 dark:bg-white/10 border border-black/10 dark:border-white/20 text-stone-200 py-3 rounded-full font-semibold transition-colors hover:bg-black/30 dark:hover:bg-white/20 text-sm">
                    กลับ
                </button>
                <a 
                    href={imageUrl} 
                    download={`luckystation-harmonic-wallpaper-${birthYear}.jpg`}
                    className="flex-1 bg-gradient-to-r from-purple-600 to-indigo-600 text-white dark:bg-gradient-to-r dark:from-amber-400 dark:to-orange-500 dark:text-purple-900 py-3 rounded-full font-bold text-center transition-transform transform hover:scale-105 inline-block text-sm shadow-lg"
                >
                    ดาวน์โหลด (HD)
                </a>
            </div>
        </div>
      )}
    </div>
  );
};

export default WallpaperResultScreen;
