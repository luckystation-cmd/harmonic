
import React from 'react';
import { Screen } from '../types';
import { TOTAL_DONATED_AMOUNT, TRANSPARENCY_LOG_DATA } from '../constants';
import { HeartIcon } from './icons';

interface TransparencyLogScreenProps {
  onNavigate: (screen: Screen) => void;
}

const TransparencyLogScreen: React.FC<TransparencyLogScreenProps> = ({ onNavigate }) => {
  return (
    <div className="space-y-6">
      <button onClick={() => onNavigate(Screen.Charity)} className="absolute top-6 left-6 text-purple-700 dark:text-amber-300 font-semibold bg-black/5 dark:bg-white/5 px-3 py-1 rounded-full z-10">
        &larr; กลับ
      </button>

      <header style={{animationDelay: '100ms'}} className="text-center animate-slide-in-up pt-12">
        <HeartIcon className="w-12 h-12 mx-auto mb-2 text-pink-400" />
        <h1 className="text-3xl font-bold text-purple-900 dark:text-amber-100">เส้นทางบุญของชุมชน</h1>
        <p className="text-white/80">ความโปร่งใสคือหัวใจของเรา</p>
      </header>
      
      <section style={{animationDelay: '200ms'}} className="animate-slide-in-up">
        <div className="bg-gradient-to-br from-purple-900/50 to-amber-900/50 p-6 rounded-2xl border border-white/20 backdrop-blur-md text-center">
            <h2 className="text-lg font-semibold text-amber-100">ยอดบริจาครวมจากผู้พัฒนา</h2>
            <p className="text-5xl font-bold text-white my-2 tracking-tight">
                {TOTAL_DONATED_AMOUNT.toLocaleString('th-TH')}
                <span className="text-2xl ml-2">บาท</span>
            </p>
            <p className="text-xs text-stone-300">อัปเดตล่าสุด: 1 สิงหาคม 2567</p>
        </div>
      </section>

      <section style={{animationDelay: '300ms'}} className="animate-slide-in-up">
        <h3 className="text-lg font-semibold text-purple-900 dark:text-amber-200 mb-4">ประวัติการบริจาค</h3>
        <div className="space-y-4">
            {TRANSPARENCY_LOG_DATA.map((post, index) => (
                <div 
                    key={post.id}
                    style={{animationDelay: `${300 + index * 100}ms`}}
                    className="bg-white/50 dark:bg-white/5 p-4 rounded-lg border border-black/10 dark:border-white/10 animate-slide-in-up"
                >
                    <img 
                        src={post.proofImageUrl} 
                        alt={`หลักฐานการบริจาคสำหรับ ${post.title}`}
                        className="w-full h-40 object-cover rounded-md mb-4"
                    />
                    <div className="flex justify-between items-start">
                        <div>
                            <p className="text-xs text-stone-500 dark:text-stone-400">{post.date}</p>
                            <h4 className="font-bold text-purple-800 dark:text-amber-300">{post.title}</h4>
                        </div>
                        <p className="font-bold text-lg text-purple-600 dark:text-amber-200">{post.amount.toLocaleString('th-TH')}.-</p>
                    </div>
                    <p className="text-sm text-white/90 mt-2">{post.description}</p>
                </div>
            ))}
        </div>
      </section>
    </div>
  );
};

export default TransparencyLogScreen;