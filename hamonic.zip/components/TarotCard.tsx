
import React, { useState } from 'react';
import { TarotCardData } from '../types';
import { CardBackSymbol, SparklesIcon } from './icons';
import { soundService } from '../services/soundService';

interface TarotCardProps {
  card: TarotCardData;
  isRevealed?: boolean;
  onReveal?: () => void;
  disabled?: boolean;
}

const TarotCard: React.FC<TarotCardProps> = ({ card, isRevealed = true, onReveal, disabled = false }) => {
  // Local state for flip if not controlled by parent
  const [localRevealed, setLocalRevealed] = useState(isRevealed);
  
  // Sync prop change
  React.useEffect(() => {
      setLocalRevealed(isRevealed);
  }, [isRevealed]);

  const handleInteraction = () => {
    if (disabled || localRevealed) return;
    
    // Play "Crystal Ting" (Magic Chime) sound + Haptic Feedback
    soundService.playInteraction('success');
    
    setLocalRevealed(true);
    if (onReveal) onReveal();
  };

  const imageUrl = `https://www.sacred-texts.com/tarot/pkt/img/${card.imageKey}.jpg`;

  return (
    <div 
        className="perspective-1000 w-full aspect-[2.75/4.75] cursor-pointer group"
        onClick={handleInteraction}
    >
      <div className={`relative w-full h-full transition-all duration-700 transform-style-3d ${localRevealed ? 'rotate-y-180' : ''}`}>
        
        {/* Card Back (Face Down) - The Portal */}
        <div className="absolute inset-0 backface-hidden w-full h-full rounded-xl overflow-hidden border border-white/10 shadow-xl bg-[#0F0518] flex items-center justify-center group-hover:scale-[1.02] transition-transform duration-300">
            {/* Cosmic Texture */}
            <div className="absolute inset-0 bg-gradient-to-br from-indigo-900/50 via-purple-900/50 to-black/80"></div>
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-30"></div>
            
            {/* Inner Frame */}
            <div className="w-[85%] h-[85%] border border-amber-500/30 rounded-lg flex items-center justify-center relative backdrop-blur-sm">
                 <div className="absolute inset-0 bg-amber-500/5 rounded-lg"></div>
                 <CardBackSymbol className="w-1/2 h-1/2 text-amber-200 opacity-60 animate-pulse-slow relative z-10 drop-shadow-[0_0_8px_rgba(251,191,36,0.5)]" />
            </div>
        </div>

        {/* Card Front (Face Up) - The Living Vision */}
        <div className={`absolute inset-0 backface-hidden w-full h-full rounded-xl overflow-hidden rotate-y-180 bg-[#05020a] border border-amber-400/30 transition-all duration-1000 ${localRevealed ? 'shadow-[0_0_25px_rgba(251,191,36,0.4)]' : ''}`}>
            <div className="relative w-full h-full">
                {/* 1. Base Image */}
                <img 
                    src={imageUrl} 
                    alt={card.name} 
                    className="w-full h-full object-cover filter contrast-[1.1] saturate-[0.9] brightness-[0.9]"
                    loading="lazy"
                />
                
                {/* 2. Mystical Overlays */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20 pointer-events-none"></div>
                <div className="absolute inset-0 bg-amber-500/10 mix-blend-overlay pointer-events-none"></div>

                {/* 3. Holographic Sheen */}
                <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"></div>
                
                {/* Card Name Overlay */}
                <div className="absolute bottom-0 left-0 right-0 p-2 pt-6 bg-gradient-to-t from-black to-transparent z-30">
                    <p className="text-[10px] text-amber-100 font-serif tracking-widest uppercase text-center drop-shadow-md">{card.name}</p>
                </div>
            </div>
        </div>

      </div>
      
      <style>{`
        .perspective-1000 { perspective: 1000px; }
        .transform-style-3d { transform-style: preserve-3d; }
        .backface-hidden { backface-visibility: hidden; }
        .rotate-y-180 { transform: rotateY(180deg); }
      `}</style>
    </div>
  );
};

export default TarotCard;