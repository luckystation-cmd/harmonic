
import React from 'react';
import { LogIcon } from './icons';
import { ReadingLog } from '../types';
import TarotCard from './TarotCard';

interface LogScreenProps {
  readings: ReadingLog[];
}

const LogScreen: React.FC<LogScreenProps> = ({ readings }) => {
  if (readings.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center text-slate-500 animate-slide-in-up pt-16">
        <LogIcon className="w-16 h-16 mb-4 text-purple-300" />
        <h1 className="text-2xl font-bold text-purple-800">ยังไม่มีบันทึก</h1>
        <p className="mt-2 max-w-xs text-slate-600">
          เมื่อคุณดูดวง คำทำนายจะถูกบันทึกไว้ที่นี่โดยอัตโนมัติ
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
       <div style={{animationDelay: '100ms'}} className="text-center animate-slide-in-up">
         <h1 className="text-3xl font-bold text-purple-800">บันทึกพลังงาน</h1>
         <p className="text-slate-600">ประวัติการทำนาย 50 ครั้งล่าสุดของคุณ</p>
      </div>
      {readings.map((log, index) => (
        <div 
          key={log.date} 
          style={{animationDelay: `${100 + index * 100}ms`}}
          className="bg-white/60 backdrop-blur-sm p-4 rounded-lg border border-white/50 shadow-sm animate-slide-in-up"
        >
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-bold text-purple-700">{log.category}</h2>
            <p className="text-xs text-slate-500">{new Date(log.date).toLocaleDateString('th-TH', { day: '2-digit', month: 'short', year: 'numeric' })}</p>
          </div>
          <div className="grid grid-cols-3 gap-2 mb-4">
            {log.cards.map(card => (
              <TarotCard key={card.name} card={card} />
            ))}
          </div>
          <p className="text-sm text-slate-700 italic">" {log.reading.overall_summary} "</p>
        </div>
      ))}
    </div>
  );
};

export default LogScreen;