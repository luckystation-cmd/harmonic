
import React from 'react';

interface IconProps {
  className?: string;
}

export const CardIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.59 14.37a6 6 0 01-5.84 7.38v-4.82m5.84-2.56a12.022 12.022 0 00-11.68 0 6 6 0 1111.68 0z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.37A6 6 0 1112 21.75a6 6 0 010-15.38z" />
  </svg>
);

export const LogIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
  </svg>
);

export const CharityIcon: React.FC<IconProps> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z" />
    </svg>
);

export const CommunityIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-4.682-2.72m-7.5-2.228a4.5 4.5 0 00-1.897 1.897M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-4.682-2.72m-7.5-2.228a4.5 4.5 0 00-1.897 1.897M12 6.75a4.5 4.5 0 11-9 0 4.5 4.5 0 019 0zM12 10.5a4.5 4.5 0 11-9 0 4.5 4.5 0 019 0z" />
  </svg>
);

export const ProfileIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" />
  </svg>
);

export const SoundOnIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" >
    <path strokeLinecap="round" strokeLinejoin="round" d="M19.114 5.636a9 9 0 010 12.728M16.463 8.288a5.25 5.25 0 010 7.424M6.75 8.25l4.72-4.72a.75.75 0 011.28.53v15.88a.75.75 0 01-1.28.53l-4.72-4.72H4.51c-.88 0-1.704-.507-1.938-1.354A9.01 9.01 0 012.25 12c0-.83.112-1.633.322-2.396C2.806 8.756 3.63 8.25 4.51 8.25H6.75z" />
  </svg>
);

export const SoundOffIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M17.25 9.75L19.5 12m0 0l2.25 2.25M19.5 12l2.25-2.25M19.5 12l-2.25 2.25m-10.5-6l4.72-4.72a.75.75 0 011.28.53v15.88a.75.75 0 01-1.28.53l-4.72-4.72H4.51c-.88 0-1.704-.507-1.938-1.354A9.01 9.01 0 012.25 12c0-.83.112-1.633.322-2.396C2.806 8.756 3.63 8.25 4.51 8.25H6.75z" />
  </svg>
);

export const CardBackSymbol: React.FC<IconProps> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4m11.314-5.657l-11.314 11.314m11.314 0L6.343 6.343" />
    </svg>
);


export const FlameIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="currentColor">
    <path fillRule="evenodd" d="M12.963 2.286a.75.75 0 00-1.071 1.052A9.75 9.75 0 0110.304 6 9.75 9.75 0 016.5 10.305a9.75 9.75 0 01-1.668 1.618.75.75 0 101.052 1.071 8.25 8.25 0 002.332-2.331 8.25 8.25 0 002.332 2.331.75.75 0 101.052-1.071A9.752 9.752 0 0113.5 10.305a9.75 9.75 0 013.204-5.048.75.75 0 00-1.071-1.052A8.25 8.25 0 0012 3.812a8.25 8.25 0 00.963-1.526zM15 15.375a3 3 0 11-6 0 3 3 0 016 0zM21.75 12a9.75 9.75 0 01-9.75 9.75c-4.343 0-8.09-2.823-9.356-6.634a.75.75 0 011.41-.439A8.25 8.25 0 0012 20.25a8.25 8.25 0 008.25-8.25.75.75 0 011.5 0z" clipRule="evenodd" />
  </svg>
);

export const HeartIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M11.645 20.91l-.007-.003-.022-.012a15.247 15.247 0 01-1.344-.905 60.46 60.46 0 01-4.634-3.956c-1.104-1.28-2.287-2.67-3.234-4.043a1.827 1.827 0 01.02-2.247c.052-.062.107-.12.166-.174l.058-.053a.81.81 0 01.673-.211l.003.001c.245.044.477.149.673.284l.028.019c.11.073.216.15.32.228l.001.001.001.001c.11.078.22.156.33.234l.005.004a.709.709 0 00.286.177c.105.044.212.082.32.114.102.03.204.052.308.065l.01.002c.105.012.21.018.316.018.212 0 .42-.028.622-.08l.004-.001a.68.68 0 00.32-.142l.002-.001c.102-.068.2-.14.29-.214l.009-.007.005-.004c.105-.078.21-.158.315-.24l.001-.001.002-.001.001-.001c.11-.08.215-.158.32-.235l.028-.02c.2-.137.432-.242.677-.286l.003-.001.002-.001a.81.81 0 01.673.211l.058.053c.059.054.114.112.166.174a1.827 1.827 0 01.02 2.247c-.947 1.373-2.13 2.763-3.234 4.043a60.46 60.46 0 01-4.634 3.956 15.247 15.247 0 01-1.344.905l-.022.012-.007.003z" />
  </svg>
);

export const StarIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="currentColor">
    <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.007z" clipRule="evenodd" />
  </svg>
);

export const MoonIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="currentColor">
    <path fillRule="evenodd" d="M12.54 2.246a.75.75 0 01-.293.722 21.739 21.739 0 00-7.98 12.216.75.75 0 01-1.49-.155 23.238 23.238 0 018.54-13.048.75.75 0 01.223.265zM15.75 9.75a.75.75 0 01.75.75 5.25 5.25 0 01-4.5 5.234.75.75 0 01-.016-1.498 3.75 3.75 0 003-3.736.75.75 0 01.766-.75z" clipRule="evenodd" />
  </svg>
);

export const SunIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M12 2.25a.75.75 0 01.75.75v2.25a.75.75 0 01-1.5 0V3a.75.75 0 01.75-.75zM7.5 12a4.5 4.5 0 119 0 4.5 4.5 0 01-9 0zM18.894 6.106a.75.75 0 010 1.06l-1.591 1.59a.75.75 0 11-1.06-1.06l1.59-1.59a.75.75 0 011.06 0zM21.75 12a.75.75 0 01-.75.75h-2.25a.75.75 0 010-1.5h2.25a.75.75 0 01.75.75zM17.836 17.836a.75.75 0 01-1.06 0l-1.59-1.591a.75.75 0 111.06-1.06l1.591 1.59a.75.75 0 010 1.061zM12 18a.75.75 0 01.75.75v2.25a.75.75 0 01-1.5 0v-2.25A.75.75 0 0112 18zM7.164 6.164a.75.75 0 011.06 0l1.591 1.59a.75.75 0 01-1.06 1.06L7.164 7.224a.75.75 0 010-1.06zM3 12a.75.75 0 01.75-.75h2.25a.75.75 0 010 1.5H3.75A.75.75 0 013 12zM6.106 18.894a.75.75 0 011.06 0l1.59-1.591a.75.75 0 111.06 1.06l-1.59 1.591a.75.75 0 01-1.06 0z" />
  </svg>
);


export const BrainIcon: React.FC<IconProps> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.25 12l2.846.813a4.5 4.5 0 01-3.09 3.09L15 18.75l-.813-2.846a4.5 4.5 0 013.09-3.09zM18.25 12l2.846-.813a4.5 4.5 0 00-3.09-3.09L15 5.25l-.813 2.846a4.5 4.5 0 003.09 3.09z" />
    </svg>
);

export const BirthChartIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M21.752 15.002A9.718 9.718 0 0118 15.75c-5.385 0-9.75-4.365-9.75-9.75 0-1.33.266-2.597.748-3.752A9.753 9.753 0 003 11.25C3 16.635 7.365 21 12.75 21a9.753 9.753 0 009.002-5.998z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 6.375l-1.336-2.672a.563.563 0 00-.932 0L9.9 6.375m3.6 0l-1.125 2.25M9.9 6.375l1.125 2.25m0 0l-1.125 2.25M11.25 10.875l1.125-2.25" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M17.25 9.75l-.375-.75a.563.563 0 00-.932 0l-.375.75m1.687 0l-.625 1.25m-.625-1.25l.625 1.25" />
  </svg>
);

export const SymbolAnalysisIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.432 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 8.25l1.125 2.25L15.375 12l-2.25 1.125L12 15.375l-1.125-2.25L8.625 12l2.25-1.125L12 8.25z" />
  </svg>
);

export const PalmIcon: React.FC<IconProps> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 9.75c0-2.06-1.35-3.83-3.25-4.5V4.5c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.75c-1.9.67-3.25 2.44-3.25 4.5s1.35 3.83 3.25 4.5v4.5c0 .83.67 1.5 1.5 1.5s1.5-.67 1.5-1.5v-4.5c1.9-.67 3.25-2.44 3.25-4.5zM9.75 3.75c0-.83-.67-1.5-1.5-1.5S6.75 2.92 6.75 3.75v16.5c0 .83.67 1.5 1.5 1.5s1.5-.67 1.5-1.5V3.75z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 6.75a1.5 1.5 0 113 0v13.5a1.5 1.5 0 01-3 0V6.75z" />
    </svg>
);


export const CameraIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
  </svg>
);

export const CloseIcon: React.FC<IconProps> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
);

export const LotusIcon: React.FC<IconProps> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 7.5l-.625 10.632a2.25 2.25 0 01-2.247 2.118H6.622a2.25 2.25 0 01-2.247-2.118L3.75 7.5M10.5 11.25h3M12 3.75a2.25 2.25 0 00-2.25 2.25v1.5a2.25 2.25 0 004.5 0v-1.5A2.25 2.25 0 0012 3.75z" />
    </svg>
);

export const LanternIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 3.104v5.714a2.25 2.25 0 01-.5 1.591L5.25 14.25M9.75 3.104a2.25 2.25 0 00-2.25 2.25v4.5a2.25 2.25 0 004.5 0v-4.5A2.25 2.25 0 009.75 3.104zM14.25 14.25L18.5 10.455a2.25 2.25 0 01.5-1.591v-5.714" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M5.25 14.25h9" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M5.25 14.25 2.25 18a.75.75 0 001.06 1.06l3.25-3.25" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M14.25 14.25l3 3.75a.75.75 0 101.06-1.06l-3.25-3.25" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 16.5v4.5" />
  </svg>
);

export const FishIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M11.25 9.75c.168.02.335.035.504.053v-2.12c-.169.018-.336.033-.504.053m0 0c.328.053.65.116.962.193m-1.466.06c-1.34-1.22-3.14-1.93-4.938-1.93-2.32 0-4.482.97-6.038 2.576m11.974 0c-.312-.077-.634-.14-.962-.193m0 0c-1.34-1.22-3.14-1.93-4.938-1.93-2.32 0-4.482.97-6.038 2.576m11.974 0c.266.07.524.15.776.238m2.162-2.814a5.25 5.25 0 00-5.486-4.434M13.5 9.75V3m0 0L12 4.5 10.5 3M13.5 3L12 4.5l-1.5-1.5M11.25 12.063c.168-.02.335-.035.504-.053m0 0c.328-.053.65-.116.962-.193m-1.466-.06c1.34 1.22 3.14 1.93 4.938 1.93 2.32 0 4.482-.97 6.038-2.576m-11.974 0c.312.077.634.14.962.193m0 0c1.34 1.22 3.14 1.93 4.938 1.93 2.32 0 4.482-.97 6.038-2.576M9.75 14.25v2.25M14.25 14.25v2.25" />
  </svg>
);

export const BirdIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12.75 15l-1.83 2.135a.75.75 0 01-1.156 0l-1.83-2.135M6.75 6.75h.008v.008H6.75V6.75zm.75 0a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5a.75.75 0 01.75-.75zm3 0a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5a.75.75 0 01.75-.75zm3 0a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5a.75.75 0 01.75-.75zm3 0a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5a.75.75 0 01.75-.75zM12 21a8.25 8.25 0 006.29-14.655.75.75 0 00-1.06-1.06A6.75 6.75 0 0112 18.75a6.75 6.75 0 01-5.23-2.465.75.75 0 00-1.06 1.06A8.25 8.25 0 0012 21z" />
  </svg>
);

export const CalculatorIcon: React.FC<IconProps> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 15.75V18m-4.5-8.25v8.25" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M3 10.5h18M5.25 3h13.5A2.25 2.25 0 0121 5.25v13.5A2.25 2.25 0 0118.75 21H5.25A2.25 2.25 0 013 18.75V5.25A2.25 2.25 0 015.25 3z" />
    </svg>
);

export const CalendarIcon: React.FC<IconProps> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0h18" />
    </svg>
);

export const CounselorIcon: React.FC<IconProps> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" d="M7.5 8.25h9m-9 3H12m-9.75 1.51c0 1.6 1.123 2.994 2.707 3.227 1.129.166 2.27.293 3.423.379.35.026.67.21.865.501L12 21l2.755-4.133a1.14 1.14 0 01.865-.501 48.172 48.172 0 003.423-.379c1.584-.233 2.707-1.626 2.707-3.228V6.741c0-1.602-1.123-2.995-2.707-3.228A48.394 48.394 0 0012 3c-2.392 0-4.744.175-7.043.513C3.373 3.746 2.25 5.14 2.25 6.741v6.018z" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6.75l-1.313 1.313" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 9.75l-1.313 1.313" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 6.75L9.563 8.063" />
    </svg>
);

export const SparklesIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.25 12l2.846.813a4.5 4.5 0 01-3.09 3.09L15 18.75l-.813-2.846a4.5 4.5 0 013.09-3.09zM18.25 12l2.846-.813a4.5 4.5 0 00-3.09-3.09L15 5.25l-.813 2.846a4.5 4.5 0 003.09 3.09z" />
  </svg>
);

export const PaintBrushIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.53 16.122a3 3 0 00-5.78 1.128 2.25 2.25 0 01-2.4 2.245 4.5 4.5 0 008.4-2.245c0-.399-.078-.78-.22-1.128zm0 0a15.998 15.998 0 003.388-1.62m-5.043-.025a15.994 15.994 0 011.622-3.395m3.42 3.42a15.995 15.995 0 004.764-4.635l3.61 3.61a.75.75 0 010 1.06l-4.635 4.764a15.998 15.998 0 00-3.739-4.799z" />
  </svg>
);

export const CrownIcon: React.FC<IconProps> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="currentColor">
        <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.007z" clipRule="evenodd" />
    </svg>
);

export const CheckCircleIcon: React.FC<IconProps> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="currentColor">
        <path fillRule="evenodd" d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm13.36-1.814a.75.75 0 10-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 00-1.06 1.06l2.25 2.25a.75.75 0 001.14-.094l3.75-5.25z" clipRule="evenodd" />
    </svg>
);
