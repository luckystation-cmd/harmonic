import React, { useState } from 'react';
import { getLotteryPrediction } from '../services/geminiService';
import { LotteryPrediction, UserProfile } from '../types';
import { CalculatorIcon } from './icons';

interface LotteryHubScreenProps {
  onBack: () => void;
  userDOB?: UserProfile['dob'];
}

const LoadingIndicator: React.FC = () => (
    <div className="flex flex-col items-center justify-center text-center space-y-4 h-full">
        <div className="relative w-16 h-16">
            <div className="absolute inset-0 border-4 border-t-amber-500 border-slate-200 rounded-full animate-spin"></div>
        </div>
        <p className="text-purple-800 font-medium">กำลังคำนวณเลขมงคล...</p>
    </div>
);

const LotteryHubScreen: React.FC<LotteryHubScreenProps> = ({ onBack, userDOB }) => {
  const [prediction, setPrediction] = useState<LotteryPrediction | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleCalculate = async () => {
    if (!userDOB) {
      setError("ไม่พบข้อมูลวันเกิด กรุณาตั้งค่าในหน้าโปรไฟล์");
      return;
    }
    setIsLoading(true);
    setError(null);
    try {
      const result = await getLotteryPrediction(userDOB);
      setPrediction(result);
    } catch (err: any) {
      setError(err.message || 'ไม่สามารถคำนวณเลขได้');
    } finally {
      setIsLoading(false);
    }
  };

  const renderContent = () => {
    if (isLoading) {
      return <LoadingIndicator />;
    }
    
    if (error) {
        return (
             <div className="flex flex-col items-center justify-center h-full text-center pt-16">
                <p className="text-red-500 mb-4">{error}</p>
                 <button onClick={() => {setError(null); setIsLoading(false)}} className="bg-white/50 border border-white/60 text-purple-800 py-2 px-6 rounded-full font-semibold transition-colors hover:bg-white/80 shadow-sm">
                    ลองอีกครั้ง
                </button>
            </div>
        )
    }

    if (prediction) {
      return (
        <div className="animate-fade-in space-y-4">
          <div className="bg-white/60 p-4 rounded-lg border border-white/50 space-y-4 shadow-sm">
              <h3 className="text-lg font-semibold text-purple-800 text-center">เลขเด็ด 2 ตัว</h3>
              <div className="flex justify-center space-x-4">
                  {prediction.numbers_2_digit.map((num, index) => (
                      <div key={index} className="w-16 h-16 flex items-center justify-center bg-white rounded-full border-2 border-amber-400 shadow-md">
                          <span className="text-3xl font-bold text-purple-900">{num}</span>
                      </div>
                  ))}
              </div>
          </div>
          <div className="bg-white/60 p-4 rounded-lg border border-white/50 space-y-4 shadow-sm">
              <h3 className="text-lg font-semibold text-purple-800 text-center">เลขเด็ด 3 ตัว</h3>
              <div className="flex justify-center space-x-4">
                   {prediction.numbers_3_digit.map((num, index) => (
                      <div key={index} className="w-24 h-16 flex items-center justify-center bg-white rounded-lg border-2 border-amber-400 shadow-md">
                          <span className="text-3xl font-bold text-purple-900">{num}</span>
                      </div>
                  ))}
              </div>
          </div>
          <div className="bg-white/60 p-4 rounded-lg border border-white/50 shadow-sm">
              <h3 className="text-lg font-semibold text-purple-800 mb-2">ที่มาของเลขชุดนี้</h3>
              <p className="text-slate-700 italic">"{prediction.reasoning}"</p>
          </div>
          <div className="pt-4">
             <button onClick={() => setPrediction(null)} className="w-full bg-white border border-white/60 text-purple-700 py-3 rounded-full font-semibold transition-colors hover:bg-purple-50 shadow-sm">
                คำนวณอีกครั้ง
            </button>
           </div>
        </div>
      );
    }
    
    // Initial State
    return (
      <div className="animate-fade-in space-y-6 flex flex-col items-center justify-center h-full pt-16 text-center">
        <p className="text-slate-600 max-w-xs">
          AI จะทำการวิเคราะห์วันเดือนปีเกิดของคุณเพื่อสร้างชุดเลขมงคลเฉพาะบุคคล
        </p>
        {!userDOB && (
            <p className="text-amber-800 bg-amber-100 p-3 rounded-lg text-sm border border-amber-200">
                ไม่พบข้อมูลวันเกิด กรุณาตั้งค่าในหน้าโปรไฟล์เพื่อใช้งานฟีเจอร์นี้
            </p>
        )}
        <div className="pt-4">
            <button
              onClick={handleCalculate}
              disabled={!userDOB}
              className="w-full bg-gradient-to-r from-amber-400 to-orange-500 text-white py-3 px-8 rounded-full font-bold text-lg text-center transition-transform transform hover:scale-105 disabled:from-slate-300 disabled:to-slate-300 disabled:cursor-not-allowed disabled:transform-none shadow-lg shadow-amber-200"
            >
              คำนวณเลขชุดพิเศษ
            </button>
        </div>
      </div>
    );
  };


  return (
    <div className="space-y-6">
      <button onClick={onBack} className="absolute top-6 left-6 text-purple-800 font-semibold bg-white/50 px-3 py-1 rounded-full z-20 shadow-sm">
        &larr; กลับ
      </button>
      <header className="text-center space-y-2 pt-8">
         <CalculatorIcon className="w-12 h-12 mx-auto text-amber-500"/>
        <h1 className="text-2xl font-bold text-purple-900">{`ห้องคำนวณเลข`}</h1>
        <p className="text-lg font-medium text-amber-600">(เลขศาสตร์จากวันเกิด)</p>
      </header>
      
      <div className="mt-6">
        {renderContent()}
      </div>
    </div>
  );
};

export default LotteryHubScreen;