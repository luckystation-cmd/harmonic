
import React, { useState, useEffect, useCallback } from 'react';
import { BrainIcon, CardBackSymbol } from './icons';
import { MAJOR_ARCANA } from '../constants';
import { TarotCardData } from '../types';
import TarotCard from './TarotCard';
import { soundService } from '../services/soundService';

// Durstenfeld shuffle algorithm
const shuffleArray = (array: any[]) => {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
};

const TARGET_CARD_NAME = "The Fool";

const CardBack: React.FC<{ isSelected: boolean }> = ({ isSelected }) => (
  <div className={`w-full aspect-[2.75/4.75] rounded-xl shadow-lg shadow-black/40 flex items-center justify-center bg-gradient-to-br from-indigo-900 to-purple-900 border-2 ${isSelected ? 'border-amber-400' : 'border-transparent'} transition-colors`}>
    <CardBackSymbol className="w-1/2 h-1/2 text-amber-300 opacity-20" />
  </div>
);

const IntuitionGameScreen: React.FC = () => {
  const [cards, setCards] = useState<TarotCardData[]>([]);
  const [selection, setSelection] = useState<number | null>(null);
  const [isRevealed, setIsRevealed] = useState(false);

  const setupGame = useCallback(() => {
    setIsRevealed(false);
    setSelection(null);
    
    const foolCard = MAJOR_ARCANA.find(c => c.name === TARGET_CARD_NAME);
    if (!foolCard) return; 
    
    const otherCards = MAJOR_ARCANA.filter(c => c.name !== TARGET_CARD_NAME);
    const shuffledOthers = shuffleArray([...otherCards]).slice(0, 3);
    
    const gameCards = shuffleArray([foolCard, ...shuffledOthers]);
    setCards(gameCards);
  }, []);

  useEffect(() => {
    setupGame();
  }, [setupGame]);

  const handleCardClick = (index: number) => {
    if (isRevealed) return;
    setSelection(index);
    soundService.playInteraction('tap'); // Sound on tap
    
    setTimeout(() => {
        setIsRevealed(true);
        const isWin = cards[index]?.name === TARGET_CARD_NAME;
        if (isWin) {
            soundService.playInteraction('success'); // Win sound
        } else {
            soundService.playInteraction('flip'); // Just a flip sound for loss
        }
    }, 300); 
  };
  
  const isWin = selection !== null && cards[selection]?.name === TARGET_CARD_NAME;

  return (
    <div className="flex flex-col items-center h-full text-center text-slate-300 space-y-6 pt-8">
      <header className="animate-slide-in-up">
        <BrainIcon className="w-12 h-12 mx-auto mb-2 text-amber-200" />
        <h1 className="text-3xl font-bold text-amber-200">เกมทดสอบสัญชาตญาณ</h1>
      </header>
      
      <p className="max-w-sm text-slate-200 leading-relaxed animate-slide-in-up" style={{ animationDelay: '100ms' }}>
        {isRevealed ? (
            isWin ? 'ยอดเยี่ยม! สัญชาตญาณของคุณเฉียบคมมาก ✨' : 'เกือบถูกแล้ว! ลองฝึกฝนแล้วกลับมาใหม่นะ'
        ) : `ไพ่ '${TARGET_CARD_NAME}' ถูกซ่อนอยู่ในนี้... คุณหาเจอหรือไม่?`}
      </p>

      <div className="w-full max-w-md grid grid-cols-2 gap-4 animate-slide-in-up" style={{ animationDelay: '200ms' }}>
        {cards.map((card, index) => (
          <div
            key={index}
            className="card-container"
            onClick={() => handleCardClick(index)}
          >
            <div className={`card-inner ${isRevealed ? 'is-flipped' : ''}`}>
              <div className="card-front">
                <CardBack isSelected={selection === index && !isRevealed} />
              </div>
              <div className="card-back">
                <TarotCard card={card} isRevealed={true} disabled={true} /> 
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {isRevealed && (
        <div className="animate-slide-in-up" style={{ animationDelay: '300ms' }}>
            <button
                onClick={() => {
                    soundService.playInteraction('tap');
                    setupGame();
                }}
                className="px-8 py-3 rounded-full font-bold text-lg bg-purple-600 text-white shadow-lg shadow-purple-500/20 transform hover:scale-105 transition-all"
            >
                เล่นอีกครั้ง
            </button>
        </div>
      )}
    </div>
  );
};

export default IntuitionGameScreen;
