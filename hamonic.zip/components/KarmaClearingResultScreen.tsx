
import React, { useState, useEffect } from 'react';
import { getKarmaClearingBlessing } from '../services/geminiService';
import { KarmaClearingBlessing, KarmaRitualType, Screen } from '../types';
import { LotusIcon } from './icons';

interface KarmaClearingResultScreenProps {
  ritualType: KarmaRitualType;
  intention: string;
  onBack: () => void;
  onNavigate: (screen: Screen) => void;
}

const LoadingIndicator: React.FC = () => (
    <div className="flex flex-col items-center justify-center text-center space-y-4 h-full">
        <div className="relative w-16 h-16">
            <div className="absolute inset-0 border-4 border-t-amber-400 border-stone-300/50 dark:border-stone-500/50 rounded-full animate-spin"></div>
        </div>
        <p className="text-white font-medium">กำลังรับพรจากเบื้องบน...</p>
    </div>
);

const KarmaClearingResultScreen: React.FC<KarmaClearingResultScreenProps> = ({ ritualType, intention, onBack, onNavigate }) => {
  const [result, setResult] = useState<KarmaClearingBlessing | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const getBlessing = async () => {
      try {
        const blessingResult = await getKarmaClearingBlessing(intention, ritualType);
        setResult(blessingResult);
      } catch (err: any) {
        setError(err.message || 'ไม่สามารถรับพรได้');
      } finally {
        setIsLoading(false);
      }
    };
    getBlessing();
  }, [intention, ritualType]);

  if (isLoading) {
    return <LoadingIndicator />;
  }

  if (error || !result) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center">
        <p className="text-red-400 mb-4">{error}</p>
        <button onClick={onBack} className="bg-black/10 dark:bg-white/10 border border-black/20 dark:border-white/20 text-stone-700 dark:text-stone-200 py-2 px-6 rounded-full font-semibold transition-colors hover:bg-black/20 dark:hover:bg-white/20">
          กลับ
        </button>
      </div>
    );
  }

  return (
    <div className="animate-fade-in space-y-6 text-center">
      <header className="space-y-2">
         <LotusIcon className="w-12 h-12 mx-auto text-amber-300"/>
        <h1 className="text-2xl font-bold text-white">พิธีกรรมเสร็จสมบูรณ์</h1>
      </header>
      
      <div className="bg-white/5 dark:bg-black/20 p-6 rounded-lg border border-white/10 space-y-4">
        <h3 className="text-lg font-semibold text-amber-200">✨ พรสำหรับคุณ ✨</h3>
        <p className="text-white text-lg leading-relaxed italic">
          "{result.blessing}"
        </p>
      </div>

      <div className="bg-white/5 dark:bg-black/20 p-6 rounded-lg border border-white/10 space-y-4">
        <h3 className="text-lg font-semibold text-purple-300">💡 แนวทางปฏิบัติ 💡</h3>
        <p className="text-white">
          {result.guidance}
        </p>
      </div>

      <div className="pt-6 space-y-4">
         <button onClick={() => onNavigate(Screen.Charity)} className="w-full bg-purple-600 text-white dark:bg-amber-300 dark:text-purple-900 py-3 rounded-full font-bold text-center transition-transform transform hover:scale-105 inline-block">
            สร้างบุญเสริมบารมี
        </button>
         <button onClick={onBack} className="w-full bg-black/20 dark:bg-white/10 border border-black/20 dark:border-white/20 text-stone-200 py-3 rounded-full font-semibold transition-colors hover:bg-black/30 dark:hover:bg-white/20">
            กลับหน้าหลัก
        </button>
       </div>
    </div>
  );
};

export default KarmaClearingResultScreen;