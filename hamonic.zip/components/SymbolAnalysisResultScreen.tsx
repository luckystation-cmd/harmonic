
import React, { useState, useEffect } from 'react';
import { getSymbolAnalysis } from '../services/geminiService';
import { SymbolAnalysisReading } from '../types';
import { SymbolAnalysisIcon } from './icons';

interface SymbolAnalysisResultScreenProps {
  imageData: {
    data: string;
    mimeType: string;
  };
  onBack: () => void;
}

const LoadingIndicator: React.FC = () => (
    <div className="flex flex-col items-center justify-center text-center space-y-4 h-full">
        <div className="relative w-16 h-16">
            <div className="absolute inset-0 border-4 border-t-purple-400 border-stone-300/50 dark:border-stone-500/50 rounded-full animate-spin"></div>
        </div>
        <p className="text-white font-medium">กำลังวิเคราะห์สัญลักษณ์ & ตรวจสอบพลังงาน...</p>
    </div>
);

// Reuse FormattedText for consistent styling
const FormattedText: React.FC<{ text: string }> = ({ text }) => {
    if (!text) return null;
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return (
        <span>
            {parts.map((part, index) => {
                if (part.startsWith('**') && part.endsWith('**')) {
                    return <span key={index} className="font-bold text-amber-400">{part.slice(2, -2)}</span>;
                }
                return <span key={index}>{part}</span>;
            })}
        </span>
    );
};

const ResultSection: React.FC<{ title: string; content: string; icon: string; }> = ({ title, content, icon }) => (
    <div className="bg-white/5 dark:bg-black/20 p-4 rounded-lg border border-white/10 dark:border-white/10">
        <h3 className="text-lg font-semibold text-white mb-2 flex items-center">
            <span className="text-2xl mr-3">{icon}</span>
            {title}
        </h3>
        <p className="text-white/90 whitespace-pre-wrap leading-relaxed">
            <FormattedText text={content} />
        </p>
    </div>
);

const LuckSection: React.FC<{ title: string; numbers: string[]; justification: string; icon: string; }> = ({ title, numbers, justification, icon }) => (
    <div className="bg-gradient-to-br from-purple-800/50 to-indigo-800/50 p-4 rounded-lg border border-amber-400/30">
        <h3 className="text-lg font-semibold text-white mb-3 flex items-center">
            <span className="text-2xl mr-3">{icon}</span>
            {title}
        </h3>
        <div className="flex justify-center space-x-4 mb-4">
            {numbers.map((num, index) => (
                <div key={index} className="w-16 h-16 flex items-center justify-center bg-black/30 rounded-full border-2 border-amber-300 shadow-lg shadow-amber-500/20">
                    <span className="text-3xl font-bold text-amber-200">{num}</span>
                </div>
            ))}
        </div>
        <p className="text-sm text-white/90 text-center italic">
            "<FormattedText text={justification} />"
        </p>
    </div>
);


const SymbolAnalysisResultScreen: React.FC<SymbolAnalysisResultScreenProps> = ({ imageData, onBack }) => {
  const [reading, setReading] = useState<SymbolAnalysisReading | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const analyze = async () => {
      try {
        const result = await getSymbolAnalysis(imageData.data, imageData.mimeType);
        setReading(result);
      } catch (err: any) {
        setError(err.message || 'ไม่สามารถวิเคราะห์รูปภาพได้');
      } finally {
        setIsLoading(false);
      }
    };
    analyze();
  }, [imageData]);

  const imageUrl = `data:${imageData.mimeType};base64,${imageData.data}`;

  if (isLoading) {
    return <LoadingIndicator />;
  }

  if (error || !reading) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center">
        <p className="text-red-400 mb-4">{error}</p>
        <button onClick={onBack} className="bg-black/10 dark:bg-white/10 border border-black/20 dark:border-white/20 text-stone-700 dark:text-stone-200 py-2 px-6 rounded-full font-semibold transition-colors hover:bg-black/20 dark:hover:bg-white/20">
          กลับ
        </button>
      </div>
    );
  }

  const aiProbability = reading.digital_origin_analysis?.ai_probability_score || 0;
  const isLikelyAI = aiProbability > 50;

  return (
    <div className="animate-fade-in space-y-6 pb-24">
      <header className="text-center space-y-2">
         <SymbolAnalysisIcon className="w-12 h-12 mx-auto text-purple-300"/>
        <h1 className="text-2xl font-bold text-white">{`ผลการวิเคราะห์สัญลักษณ์`}</h1>
        <p className="text-lg font-medium text-amber-300">
            "<FormattedText text={reading.symbol_identified} />"
        </p>
      </header>
      
      <div className="flex justify-center relative">
        <img src={imageUrl} alt="Uploaded for analysis" className="rounded-xl shadow-lg shadow-black/50 max-h-64 object-contain" />
        {isLikelyAI && (
            <div className="absolute bottom-2 right-2 bg-black/70 backdrop-blur-md px-2 py-1 rounded-md border border-fuchsia-500/50">
                <p className="text-[10px] text-fuchsia-300 font-bold">AI DETECTED</p>
            </div>
        )}
      </div>
      
      {/* Sacred Screening System (AI Detection Warning) */}
      {isLikelyAI && (
          <div className="bg-fuchsia-900/30 border border-fuchsia-500/40 rounded-xl p-4 animate-pulse-slow">
              <div className="flex items-start space-x-3">
                  <div className="w-10 h-10 rounded-full bg-fuchsia-500/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-xl">🔮</span>
                  </div>
                  <div>
                      <h3 className="font-bold text-fuchsia-200 mb-1">ระบบสัมผัสได้ถึงพลังงานดิจิทัล</h3>
                      <p className="text-sm text-white/80 leading-relaxed">
                          ภาพนี้ดูคล้ายภาพที่สร้างขึ้นจากคอมพิวเตอร์ (AI Generated {aiProbability}%) 
                          หากท่านต้องการคำทำนายที่แม่นยำสูงสุด แนะนำให้ใช้ <span className="font-bold text-white">ภาพถ่ายจริงจากมือถือ</span> ครับ
                      </p>
                  </div>
              </div>
              <div className="mt-3 flex justify-end">
                   <button onClick={onBack} className="text-xs bg-fuchsia-600 hover:bg-fuchsia-500 text-white px-3 py-1.5 rounded-full transition-colors">
                       ถ่ายภาพใหม่
                   </button>
              </div>
          </div>
      )}

      <div className="space-y-4">
          <ResultSection title={reading.spiritual_insight.title_th} content={reading.spiritual_insight.guidance_th} icon="✨" />
          <LuckSection 
            title={reading.luck_insight.title_th}
            numbers={reading.luck_insight.primary_numbers}
            justification={reading.luck_insight.justification_th}
            icon="🎲" 
          />
      </div>

       <div className="pt-4">
         <button onClick={onBack} className="w-full bg-black/20 dark:bg-white/10 border border-black/20 dark:border-white/20 text-stone-200 py-3 rounded-full font-semibold transition-colors hover:bg-black/30 dark:hover:bg-white/20">
            วิเคราะห์ภาพอื่น
        </button>
       </div>
    </div>
  );
};

export default SymbolAnalysisResultScreen;
