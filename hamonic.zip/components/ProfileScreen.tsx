
import React from 'react';
import { ProfileIcon, FlameIcon, BirthChartIcon, HeartIcon, SparklesIcon, CrownIcon, LotusIcon } from './icons';
import { AppState, Screen } from '../types';
import { ACHIEVEMENTS } from '../constants';
import { getChineseZodiac } from '../utils/zodiacUtils';

interface ProfileScreenProps {
  appState: AppState;
  onLogout: () => void;
  onNavigate: (screen: Screen) => void;
  onUpgrade: () => void;
}

const ProfileScreen: React.FC<ProfileScreenProps> = ({ appState, onLogout, onNavigate, onUpgrade }) => {
  const latestQuest = appState.readings.length > 0 ? appState.readings[0].reading.daily_quest : "ดูไพ่เพื่อรับภารกิจแรกของคุณ";
  const user = appState.userProfile;
  const userName = user ? `${user.firstName} ${user.lastName || ''}`.trim() : 'ผู้ใช้งาน';
  
  const meritPoints = appState.stats.meritPoints || 0;
  const hasGoldAura = meritPoints >= 9;

  const getFormattedDOB = () => {
    if (!user?.dob || !user.dob.day || !user.dob.month) {
        return null;
    }
    const { day, month, year } = user.dob;
    const thaiMonths = [ "มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน", "กรกฎาคม", "สิงหาคม", "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม"];
    const yearBE = year + 543;
    return `${day} ${thaiMonths[month - 1]} ${yearBE}`;
  };

  const formattedDOB = getFormattedDOB();
  const zodiacSign = user?.dob?.year ? getChineseZodiac(user.dob.year) : null;


  return (
    <div className="space-y-8 pb-20">
      <header style={{animationDelay: '100ms'}} className="flex items-center space-x-4 animate-slide-in-up">
        <div className={`w-20 h-20 rounded-full flex items-center justify-center border backdrop-blur-md relative ${hasGoldAura ? 'border-amber-400 shadow-[0_0_15px_rgba(251,191,36,0.6)] bg-amber-500/10' : 'border-white/30 bg-white/10'}`}>
             {hasGoldAura && <div className="absolute inset-0 rounded-full border-2 border-amber-300 animate-pulse-slow"></div>}
             <ProfileIcon className={`w-10 h-10 ${hasGoldAura ? 'text-amber-200' : 'text-purple-200'}`} />
        </div>
        <div>
        <h1 className={`text-3xl font-bold ${hasGoldAura ? 'text-amber-200 drop-shadow-md' : 'text-white'}`}>{userName}</h1>
        <div className="flex flex-wrap items-center gap-2 mt-1">
             <span className="text-white/70 text-xs">
                {appState.isPremium ? 
                    <span className="text-amber-400 font-bold tracking-wide bg-amber-400/10 px-2 py-0.5 rounded-md border border-amber-400/30 mr-2">ผู้สนับสนุนหลัก 👑</span> : 
                    "สมาชิกทั่วไป"
                }
            </span>
            {meritPoints > 0 && (
                <div className="flex items-center space-x-1 bg-pink-500/10 px-2 py-0.5 rounded-md border border-pink-500/20">
                    <LotusIcon className="w-3 h-3 text-pink-400" />
                    <span className="text-xs text-pink-300 font-bold">{meritPoints} ดอกบัว</span>
                </div>
            )}
        </div>
        </div>
      </header>

      { (formattedDOB || zodiacSign) && (
        <section style={{animationDelay: '200ms'}} className="animate-slide-in-up">
          <div className="bg-white/5 backdrop-blur-md rounded-2xl p-5 border border-white/10 flex items-center space-x-5 shadow-sm">
            <BirthChartIcon className="w-10 h-10 text-cyan-300 flex-shrink-0 drop-shadow-sm" />
            <div>
              {formattedDOB && <p className="text-white"><span className="font-semibold text-purple-300 mr-2">วันเกิด:</span> {formattedDOB}</p>}
              {zodiacSign && <p className="text-white"><span className="font-semibold text-purple-300 mr-2">ปีนักษัตร:</span> ปี{zodiacSign}</p>}
            </div>
          </div>
        </section>
      )}

      {/* Focus on Charity/Support - UPDATED: Navigate to Charity Screen */}
      <section style={{animationDelay: '250ms'}} className="animate-slide-in-up">
        <div 
            className="bg-gradient-to-br from-pink-500/20 via-purple-500/20 to-indigo-500/20 backdrop-blur-md rounded-2xl p-6 border border-pink-400/30 relative overflow-hidden shadow-lg group cursor-pointer" 
            onClick={() => onNavigate(Screen.Charity)}
        >
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent w-full h-full -translate-x-full group-hover:animate-[shimmer_1.5s_infinite]"></div>
            <div className="absolute -top-10 -right-10 w-32 h-32 bg-pink-500/20 rounded-full blur-2xl group-hover:bg-pink-500/30 transition-all"></div>
            
            <h3 className="text-lg font-bold text-pink-200 flex items-center mb-2 drop-shadow-sm">
                <HeartIcon className="w-6 h-6 mr-2 text-pink-400" />
                ร่วมสนับสนุนนักพัฒนา
            </h3>
            <p className="text-sm text-white/90 mb-4 leading-relaxed font-medium">
                ✨ ร่วมเป็นส่วนหนึ่งในการพัฒนาแอป <br/>
                ✨ รายได้ส่วนหนึ่งร่วมทำบุญทุกเดือน
            </p>
            <button 
                className="w-full bg-gradient-to-r from-pink-500 to-purple-600 text-white font-bold py-3 rounded-full shadow-[0_4px_15px_rgba(236,72,153,0.4)] hover:from-pink-400 hover:to-purple-500 transition-all transform active:scale-95 flex items-center justify-center"
            >
                <SparklesIcon className="w-4 h-4 mr-2 text-white" />
                ร่วมบุญ / สนับสนุน
            </button>
        </div>
      </section>

      <section style={{animationDelay: '300ms'}} className="grid grid-cols-2 gap-4 animate-slide-in-up">
        <div className="bg-white/5 backdrop-blur-md rounded-2xl p-5 border border-white/10 text-center shadow-sm">
          <FlameIcon className="w-8 h-8 mx-auto text-orange-400 mb-2" />
          <p className="text-4xl font-bold text-white tracking-tight">{appState.streak.count}</p>
          <p className="text-xs text-white/50 mt-1 uppercase tracking-wider">ความต่อเนื่อง (วัน)</p>
        </div>
        <div className="bg-white/5 backdrop-blur-md rounded-2xl p-5 border border-white/10 text-center shadow-sm">
          <ProfileIcon className="w-8 h-8 mx-auto text-cyan-400 mb-2" />
          <p className="text-4xl font-bold text-white tracking-tight">{appState.achievements.length} <span className="text-lg text-white/30">/ {ACHIEVEMENTS.length}</span></p>
          <p className="text-xs text-white/50 mt-1 uppercase tracking-wider">ความสำเร็จที่ปลดล็อก</p>
        </div>
      </section>

      <section style={{animationDelay: '400ms'}} className="animate-slide-in-up">
        <h3 className="text-lg font-bold text-white mb-3 flex items-center">
             <span className="w-1 h-5 bg-purple-500 rounded-full mr-3"></span>
             ภารกิจล่าสุด
        </h3>
        <div className="bg-white/5 p-5 rounded-2xl border border-white/10 shadow-sm backdrop-blur-md">
          <p className="text-white/90 italic font-medium text-center">"{latestQuest}"</p>
        </div>
      </section>

      <section style={{animationDelay: '500ms'}} className="animate-slide-in-up">
        <h3 className="text-lg font-bold text-white mb-3 flex items-center">
            <span className="w-1 h-5 bg-amber-500 rounded-full mr-3"></span>
            เหรียญตราความสำเร็จ
        </h3>
        <div className="grid grid-cols-3 gap-3">
          {ACHIEVEMENTS.map(ach => {
            const isUnlocked = appState.achievements.includes(ach.id);
            const Icon = ach.icon;
            return (
              <div 
                key={ach.id} 
                className={`bg-white/5 backdrop-blur-sm p-3 rounded-xl flex flex-col items-center text-center aspect-square justify-center border transition-all ${isUnlocked ? 'border-amber-400/40 shadow-[0_0_10px_rgba(251,191,36,0.1)] bg-amber-900/10' : 'border-transparent opacity-40 grayscale'}`}
                title={ach.description}
              >
                <Icon className={`w-8 h-8 mb-2 transition-opacity ${isUnlocked ? 'text-amber-400' : 'text-slate-400'}`} />
                <p className={`text-[10px] font-semibold leading-tight ${isUnlocked ? 'text-amber-100' : 'text-white/50'}`}>{ach.name}</p>
              </div>
            );
          })}
        </div>
      </section>

      <section style={{animationDelay: '550ms'}} className="animate-slide-in-up">
        <h3 className="text-lg font-bold text-white mb-3 flex items-center">
            <span className="w-1 h-5 bg-pink-500 rounded-full mr-3"></span>
            การทำบุญ (แต้มบุญ: {meritPoints})
        </h3>
        <div 
          onClick={() => onNavigate(Screen.TransparencyLog)}
          className="bg-white/5 p-4 rounded-2xl border border-white/10 flex items-center justify-between cursor-pointer hover:bg-white/10 transition-colors shadow-sm backdrop-blur-md group"
        >
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 rounded-full bg-pink-500/20 flex items-center justify-center">
                 <HeartIcon className="w-6 h-6 text-pink-400 group-hover:scale-110 transition-transform" />
            </div>
            <div>
                <h4 className="font-semibold text-white">เส้นทางบุญของชุมชน</h4>
                <p className="text-sm text-white/60">ดูบันทึกความโปร่งใส</p>
            </div>
          </div>
          <span className="text-white/30 text-xl">&rarr;</span>
        </div>
      </section>

      <section style={{animationDelay: '600ms'}} className="pt-6 mt-8 border-t border-white/10 animate-slide-in-up">
        <button
          onClick={onLogout}
          className="w-full text-center py-3.5 px-4 rounded-full text-white/80 hover:text-red-300 hover:bg-red-500/10 transition-all duration-200 font-semibold backdrop-blur-sm border border-white/10 shadow-sm text-sm"
        >
          ออกจากระบบ
        </button>
      </section>
    </div>
  );
};

export default ProfileScreen;
