
import React, { useState } from 'react';
import { Screen } from '../types';
import { HeartIcon } from './icons';

interface DonationUploadScreenProps {
  onDonated: () => void;
  onNavigate: (screen: Screen) => void;
}

const LoadingSpinner: React.FC<{text: string}> = ({text}) => (
    <div className="flex flex-col items-center justify-center text-center space-y-4">
        <div className="relative w-16 h-16">
            <div className="absolute inset-0 border-4 border-t-pink-400 border-stone-300/50 dark:border-stone-500/50 rounded-full animate-spin"></div>
        </div>
        <p className="text-purple-900 dark:text-amber-200 font-medium">{text}</p>
    </div>
);


const DonationUploadScreen: React.FC<DonationUploadScreenProps> = ({ onDonated, onNavigate }) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [status, setStatus] = useState<'idle' | 'verifying' | 'success'>('idle');

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      setSelectedFile(event.target.files[0]);
    }
  };

  const handleSubmit = () => {
    if (selectedFile) {
      setStatus('verifying');
      // Simulate verification process
      setTimeout(() => {
        setStatus('success');
        onDonated();
        // Navigate to profile after a short delay to show success message
        setTimeout(() => {
          onNavigate(Screen.Profile);
        }, 2500);
      }, 1500);
    }
  };

  if (status === 'verifying') {
    return (
        <div className="flex items-center justify-center h-full">
            <LoadingSpinner text="กำลังบันทึกผล..." />
        </div>
    );
  }

  if (status === 'success') {
    return (
        <div className="flex flex-col items-center justify-center h-full text-center text-stone-700 dark:text-stone-300 space-y-4">
            <HeartIcon className="w-16 h-16 text-pink-400" />
            <h2 className="text-2xl font-bold text-purple-900 dark:text-amber-200">อนุโมทนาบุญ!</h2>
            <p className="max-w-xs">ขอให้บุญที่ท่านตั้งใจทำ นำโชคลาภและความสมดุลมาสู่ชีวิตของท่าน!</p>
            <p className="text-sm">คุณได้รับเหรียญตรา "ผู้ให้" แล้ว</p>
            <p className="text-sm text-stone-500 dark:text-stone-400">กำลังนำท่านไปยังหน้าโปรไฟล์...</p>
        </div>
    );
  }


  return (
    <div className="flex flex-col items-center justify-center h-full text-center text-stone-700 dark:text-stone-300 space-y-8 pt-16">
      <button onClick={() => onNavigate(Screen.Charity)} className="absolute top-6 left-6 text-purple-700 dark:text-amber-300 font-semibold bg-black/5 dark:bg-white/5 px-3 py-1 rounded-full">
        &larr; กลับ
      </button>

      <div style={{animationDelay: '100ms'}} className="animate-slide-in-up">
        <HeartIcon className="w-20 h-20 text-pink-400" />
      </div>

      <div style={{animationDelay: '200ms'}} className="animate-slide-in-up">
        <h1 className="text-2xl font-bold text-purple-900 dark:text-amber-200">ยืนยันการสนับสนุน</h1>
        <p className="mt-2 max-w-xs text-white/90">
          กรุณาอัปโหลดหลักฐานการโอนเงิน (ภาพหน้าจอ) เพื่อรับเหรียญตรา
        </p>
      </div>
      
      <div style={{animationDelay: '300ms'}} className="w-full max-w-xs space-y-4 animate-slide-in-up">
        <label
          htmlFor="file-upload"
          className="w-full bg-black/5 dark:bg-white/10 border-2 border-dashed border-black/10 dark:border-white/20 rounded-lg p-6 text-center cursor-pointer hover:bg-black/10 dark:hover:bg-white/20 transition-colors"
        >
          {selectedFile ? (
            <span className="text-green-600 dark:text-green-300 font-semibold truncate">{selectedFile.name}</span>
          ) : (
            <span className="text-stone-600 dark:text-stone-300">เลือกไฟล์รูปภาพ...</span>
          )}
        </label>
        <input
            id="file-upload"
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="hidden"
        />
      </div>


      <div style={{animationDelay: '400ms'}} className="animate-slide-in-up">
        <button
          onClick={handleSubmit}
          disabled={!selectedFile}
          className={`px-8 py-3 rounded-full font-bold text-lg transition-all duration-300 ${
            selectedFile
              ? 'bg-purple-600 text-white dark:bg-amber-300 dark:text-purple-900 shadow-lg shadow-purple-400/20 dark:shadow-amber-300/20 transform hover:scale-105'
              : 'bg-stone-400/50 dark:bg-stone-500/20 text-stone-600 dark:text-stone-400 cursor-not-allowed'
          }`}
        >
          อัปโหลดและยืนยัน
        </button>
      </div>
    </div>
  );
};

export default DonationUploadScreen;