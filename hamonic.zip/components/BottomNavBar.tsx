import React from 'react';
import { Screen } from '../types';
import { CardIcon, CharityIcon, CommunityIcon, ProfileIcon } from './icons';

interface BottomNavBarProps {
  activeScreen: Screen;
  onNavigate: (screen: Screen) => void;
}

const NavItem: React.FC<{
  icon: React.ReactNode;
  label: string;
  screen: Screen;
  isActive: boolean;
  onClick: (screen: Screen) => void;
}> = ({ icon, label, screen, isActive, onClick }) => {
  const activeClass = isActive ? 'text-white' : 'text-white/40';
  const activeBg = isActive ? 'bg-white/15 shadow-[0_0_15px_rgba(255,255,255,0.1)] scale-110' : 'hover:bg-white/5';

  return (
    <button
      onClick={() => onClick(screen)}
      className={`relative flex flex-col items-center justify-center w-14 h-14 rounded-2xl transition-all duration-300 group`}
    >
      <div className={`absolute inset-0 rounded-2xl transition-all duration-300 ${activeBg}`}></div>
      <div className={`relative z-10 transition-transform duration-300 ${isActive ? '-translate-y-1' : ''}`}>
         <div className={`${activeClass} transition-colors duration-300`}>
            {icon}
         </div>
      </div>
      {isActive && (
        <span className="absolute bottom-2 text-[9px] font-bold text-white tracking-wide animate-fade-in">
           {/* Label removed for cleaner look on active state, or keep dot */}
           <span className="block w-1 h-1 bg-white rounded-full mx-auto mt-1 shadow-[0_0_5px_white]"></span>
        </span>
      )}
    </button>
  );
};

const BottomNavBar: React.FC<BottomNavBarProps> = ({ activeScreen, onNavigate }) => {
  const navItems = [
    { icon: <CardIcon className="w-6 h-6" />, label: 'ทำนาย', screen: Screen.Home },
    { icon: <CharityIcon className="w-6 h-6" />, label: 'ทำบุญ', screen: Screen.Charity },
    { icon: <CommunityIcon className="w-6 h-6" />, label: 'ชุมชน', screen: Screen.Community },
    { icon: <ProfileIcon className="w-6 h-6" />, label: 'โปรไฟล์', screen: Screen.Profile },
  ];

  const readingFlowScreens = [Screen.Home, Screen.MindFocus, Screen.ReadingResult];
  const isReadingFlowActive = readingFlowScreens.includes(activeScreen);

  const communityFlowScreens = [Screen.Community, Screen.IntuitionGame];
  const isCommunityFlowActive = communityFlowScreens.includes(activeScreen);

  return (
    <footer className="fixed bottom-6 left-0 right-0 z-50 px-6 pointer-events-none">
      <div className="max-w-xs mx-auto pointer-events-auto">
        {/* Floating Island Container */}
        <div className="bg-slate-900/80 backdrop-blur-xl border border-white/10 rounded-[2rem] shadow-[0_8px_32px_rgba(0,0,0,0.4)] p-2 flex justify-between items-center">
          {navItems.map((item) => {
             const isActive =
              (item.screen === Screen.Home && isReadingFlowActive) ||
              (item.screen === Screen.Community && isCommunityFlowActive) ||
              item.screen === activeScreen;

            return (
              <NavItem
                key={item.screen}
                {...item}
                isActive={isActive}
                onClick={onNavigate}
              />
            )
          })}
        </div>
      </div>
    </footer>
  );
};

export default BottomNavBar;