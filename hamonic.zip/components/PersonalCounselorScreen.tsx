
import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, Screen } from '../types';
import { CounselorIcon, SparklesIcon, CrownIcon, PaintBrushIcon, LotusIcon } from './icons';
import { soundService } from '../services/soundService';
import { generateImageFromPrompt } from '../services/geminiService';

interface PersonalCounselorScreenProps {
  onBack: () => void;
  chatHistory: ChatMessage[];
  onSendMessage: (message: string) => void;
  isLoading: boolean;
  dailyImageCount: number;
  isPremium: boolean;
  onImageGenerated: () => void;
  onUpgrade: () => void;
  onNavigate: (screen: Screen) => void;
}

const SUGGESTED_PROMPTS = [
    { 
        label: "🦅 พระนารายณ์ทรงครุฑ", 
        prompt: "ขอภาพพระนารายณ์ทรงครุฑ ประทับบนพญาครุฑมหาอำนาจ พร้อมลวดลายยันต์อักขระศักดิ์สิทธิ์เรืองแสงด้านหลัง เสริมดวงชะตาบารมีและชนะศัตรู (สไตล์วิจิตรศิลป์ไทย)" 
    },
    { 
        label: "🙏 นางกวักมหาลาภ", 
        prompt: "ขอนางกวักมหาลาภ ท่าทางถูกต้อง มือขวายกขึ้นหักข้อมือลง นิ้วทั้ง 5 เรียงชิดติดกันเหมือนไม้พาย ทำท่าโกยทรัพย์ (ห้ามจีบนิ้ว ห้ามชี้) มือซ้ายกอดถุงเงิน" 
    },
    { 
        label: "🐲 พญานาคราช", 
        prompt: "ขอวอลเปเปอร์พญานาคสีเขียวมรกต เลื้อยรอบกองทองคำ ดูขลังและศักดิ์สิทธิ์" 
    },
    { 
        label: "🐘 พระพิฆเนศ", 
        prompt: "ขอภาพพระพิฆเนศปางประทานพร โทนสีชมพูทอง สไตล์โมเดิร์น" 
    },
    { 
        label: "👹 ท้าวเวสสุวรรณ", 
        prompt: "ขอภาพท้าวเวสสุวรรณ หน้าเทพ ดูใจดีแต่มีอำนาจ พื้นหลังสีแดงทอง" 
    },
    { 
        label: "💖 ความรัก (วันจันทร์)", 
        prompt: "เกิดวันจันทร์ ขอวอลเปเปอร์เสริมดวงความรัก สไตล์ไทยโมเดิร์น โรแมนติกและขลัง" 
    },
];

const WallpaperCard: React.FC<{ 
    data: any, 
    onImageGenerated: () => void,
    isPremium: boolean
}> = ({ data, onImageGenerated, isPremium }) => {
    const [imageUrl, setImageUrl] = useState<string | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const generate = async () => {
            try {
                const fullPrompt = `${data.generation_prompts.midjourney_prompt} --no ${data.generation_prompts.negative_prompt} --ar ${data.generation_prompts.aspect_ratio}`;
                const base64 = await generateImageFromPrompt(fullPrompt);
                setImageUrl(`data:image/jpeg;base64,${base64}`);
                onImageGenerated();
            } catch (err) {
                setError("ไม่สามารถสร้างภาพได้ในขณะนี้");
            } finally {
                setLoading(false);
            }
        };
        generate();
    }, []);

    return (
        // Reduced max-width to max-w-[240px] for better mobile fit
        <div className="bg-slate-800 rounded-xl overflow-hidden border border-amber-400/30 shadow-lg w-full max-w-[240px] mx-auto mt-2 mb-4">
            <div className="p-2 bg-gradient-to-r from-purple-900 to-slate-900 border-b border-white/10">
                <h3 className="font-bold text-amber-300 text-xs flex items-center truncate">
                    <PaintBrushIcon className="w-3 h-3 mr-1 flex-shrink-0" />
                    {data.selling_points.title_thai}
                </h3>
            </div>
            
            <div className="relative aspect-[9/16] bg-black/50 flex items-center justify-center">
                {loading && (
                    <div className="text-center p-4">
                        <div className="w-8 h-8 border-2 border-amber-400 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
                        <p className="text-[10px] text-white/50 animate-pulse">กำลังร่ายมนตร์...</p>
                    </div>
                )}
                {error && <p className="text-red-400 text-[10px] p-2 text-center">{error}</p>}
                {imageUrl && (
                    <img src={imageUrl} alt="Generated Wallpaper" className="w-full h-full object-cover" />
                )}
            </div>

            <div className="p-3 space-y-2">
                <p className="text-[10px] text-white/80 italic line-clamp-2">"{data.selling_points.meaning_thai}"</p>
                
                {/* Artistic Disclaimer */}
                <div className="bg-black/30 p-2 rounded-lg border border-white/5">
                    <div className="flex items-start space-x-2">
                        <PaintBrushIcon className="w-3 h-3 text-amber-400/70 mt-0.5 flex-shrink-0" />
                        <p className="text-[9px] text-white/50 leading-tight">
                            <span className="text-amber-400/70 font-bold">Spiritual Art:</span><br/>
                            ภาพนี้คือ "นิมิตศิลป์" จาก AI ที่เน้นพลังงานและความหมายมงคล 
                        </p>
                    </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-white/10">
                    <div className="flex space-x-1">
                        {data.selling_points.lucky_numbers?.map((num: string, i: number) => (
                            <span key={i} className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] flex items-center justify-center border border-amber-500/30 font-bold">
                                {num}
                            </span>
                        ))}
                    </div>
                    {imageUrl && (
                        <a 
                            href={imageUrl} 
                            download="lucky-wallpaper.jpg"
                            className="text-[10px] bg-white/10 hover:bg-white/20 text-white px-2 py-1 rounded-full transition-colors"
                        >
                            ดาวน์โหลด
                        </a>
                    )}
                </div>
            </div>
        </div>
    );
};

const FormattedMessage: React.FC<{ text: string }> = ({ text }) => {
    let jsonData = null;
    try {
        const cleanText = text.replace(/```json/g, '').replace(/```/g, '').trim();
        const jsonMatch = cleanText.match(/\{[\s\S]*\}/);
        
        if (jsonMatch) {
            const potentialJson = JSON.parse(jsonMatch[0]);
            if (potentialJson.type === 'lucky_wallpaper_generation') {
                jsonData = potentialJson;
            }
        }
    } catch (e) {
        // Not JSON
    }

    if (jsonData) {
        return <WallpaperCard data={jsonData} onImageGenerated={() => {}} isPremium={true} />;
    }

    const parts = text.split(/(\*\*.*?\*\*)/g);
    return (
        <span className="text-sm leading-relaxed">
            {parts.map((part, index) => {
                if (part.startsWith('**') && part.endsWith('**')) {
                    return <span key={index} className="font-bold text-amber-300">{part.slice(2, -2)}</span>;
                }
                return <span key={index}>{part}</span>;
            })}
        </span>
    );
};

// Premium "Crystal Ball" Loading Animation
const CrystalBallLoader = () => (
  <div className="flex justify-start animate-fade-in">
    <div className="bg-slate-800/80 backdrop-blur-md border border-purple-500/30 text-white rounded-2xl rounded-bl-none p-4 flex items-center space-x-4 shadow-[0_0_15px_rgba(168,85,247,0.15)]">
      <div className="relative w-12 h-12 flex-shrink-0">
        {/* Outer Glow */}
        <div className="absolute inset-0 bg-purple-500/40 rounded-full blur-md animate-pulse"></div>
        {/* Ball */}
        <div className="relative w-full h-full rounded-full bg-gradient-to-br from-indigo-500 via-purple-500 to-indigo-900 border border-white/30 overflow-hidden shadow-inner">
           {/* Shine */}
           <div className="absolute top-1 left-2 w-4 h-3 bg-white/40 rounded-full blur-[2px] -rotate-12"></div>
           {/* Mist Animation */}
           <div className="absolute inset-0 bg-gradient-to-t from-purple-900/80 via-transparent to-transparent opacity-80 animate-[spin_4s_linear_infinite]"></div>
        </div>
        {/* Sparkle */}
        <SparklesIcon className="absolute -top-1 -right-1 w-4 h-4 text-amber-300 animate-spin-slow drop-shadow-[0_0_5px_rgba(251,191,36,0.8)]" />
      </div>
      <div className="flex flex-col justify-center">
        <p className="text-sm font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-200 to-amber-100 animate-pulse">กำลังเพ่งจิต...</p>
        <p className="text-[10px] text-purple-300/70">สื่อสารกับจักรวาล</p>
      </div>
    </div>
  </div>
);

const PersonalCounselorScreen: React.FC<PersonalCounselorScreenProps> = ({ 
    onBack, chatHistory, onSendMessage, isLoading, onUpgrade, isPremium, onImageGenerated, onNavigate
}) => {
    const [input, setInput] = useState('');
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        scrollToBottom();
    }, [chatHistory, isLoading]);

    const handleSend = () => {
        if (!input.trim()) return;
        onSendMessage(input);
        setInput('');
        soundService.playInteraction('tap');
    };

    const handlePromptClick = (prompt: string) => {
        onSendMessage(prompt);
        soundService.playInteraction('tap');
    };

    return (
        <div className="flex flex-col h-full bg-slate-900/50">
            {/* Header: Use px-safe-area */}
            <header className="flex items-center justify-between px-safe-area py-4 bg-slate-900/80 backdrop-blur-md border-b border-white/10 z-30 fixed top-0 left-0 right-0 mx-auto w-full max-w-md">
                <button onClick={onBack} className="text-amber-300 font-semibold">
                    &larr; กลับ
                </button>
                <div className="text-center">
                    <h1 className="text-lg font-bold text-white">AI จิตรกรสายมู</h1>
                    <p className="text-xs text-white/50">สร้างภาพมงคล & ปรึกษาดวง</p>
                </div>
                {/* REPLACED: Crown/Upgrade button with Lotus/Charity button */}
                <button 
                    onClick={() => onNavigate(Screen.Charity)} 
                    className="text-pink-400 animate-pulse-slow hover:scale-110 transition-transform bg-white/5 p-1.5 rounded-full border border-pink-500/30"
                >
                    <LotusIcon className="w-6 h-6 drop-shadow-[0_0_10px_rgba(236,72,153,0.5)]" />
                </button>
            </header>

            {/* Body: Use px-safe-area */}
            <div className="flex-1 overflow-y-auto pt-20 pb-44 px-safe-area space-y-4 no-scrollbar">
                 {chatHistory.length === 0 && (
                    <div className="flex flex-col items-center justify-center mt-4 space-y-6 text-center opacity-90">
                        <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-full flex items-center justify-center shadow-lg shadow-purple-500/30">
                            <PaintBrushIcon className="w-10 h-10 text-white" />
                        </div>
                        <div>
                            <h2 className="text-xl font-bold text-white">อยากได้ภาพมงคลแบบไหน?</h2>
                            <p className="text-white/60 max-w-xs mx-auto mt-2 text-sm">สั่งจิตรกรรม AI หรือปรึกษาดวงชะตาได้เลยครับ (ฟรีไม่มีค่าใช้จ่าย)</p>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-2 w-full max-w-xs">
                            {SUGGESTED_PROMPTS.map((item, idx) => (
                                <button 
                                    key={idx}
                                    onClick={() => handlePromptClick(item.prompt)}
                                    className="bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl p-2.5 text-xs text-white transition-all text-left flex items-center space-x-2"
                                >
                                    <SparklesIcon className="w-3 h-3 text-amber-300 flex-shrink-0" />
                                    <span className="truncate">{item.label}</span>
                                </button>
                            ))}
                        </div>
                    </div>
                 )}

                {chatHistory.map((msg, index) => (
                    <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[85%] p-3 rounded-2xl ${msg.role === 'user' ? 'bg-purple-600 text-white rounded-br-none' : 'bg-slate-800/80 border border-white/10 text-white rounded-bl-none backdrop-blur-sm'}`}>
                            {msg.parts[0].text.includes('lucky_wallpaper_generation') ? (
                                <FormattedMessage text={msg.parts[0].text} />
                            ) : (
                                <p className="whitespace-pre-wrap text-sm leading-relaxed break-words"><FormattedMessage text={msg.parts[0].text} /></p>
                            )}
                        </div>
                    </div>
                ))}
                
                {isLoading && <CrystalBallLoader />}
                
                <div ref={messagesEndRef} />
            </div>

            {/* Footer: Use px-safe-area */}
            <footer className="fixed bottom-[100px] left-0 right-0 mx-auto w-full max-w-md bg-slate-900/90 backdrop-blur-md px-safe-area py-4 border-t border-white/10 z-40">
                <div className="flex items-center space-x-2 bg-slate-800/50 rounded-full p-1 pr-2 border border-white/10">
                    <input 
                        type="text" 
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                        placeholder="พิมพ์คำขอภาพมงคล..."
                        className="flex-1 bg-transparent border-none focus:ring-0 text-white placeholder-white/30 px-4 py-2 text-sm"
                        disabled={isLoading}
                    />
                    <button 
                        onClick={handleSend}
                        disabled={!input.trim() || isLoading}
                        className="w-10 h-10 bg-gradient-to-r from-purple-500 to-indigo-600 rounded-full flex items-center justify-center text-white shadow-lg disabled:opacity-50 disabled:shadow-none"
                    >
                        &uarr;
                    </button>
                </div>
            </footer>
        </div>
    );
};

export default PersonalCounselorScreen;
