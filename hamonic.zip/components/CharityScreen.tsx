
import React from 'react';
import { CharityIcon, LotusIcon, SparklesIcon } from './icons';
import { Screen } from '../types';

interface CharityScreenProps {
  onNavigate: (screen: Screen) => void;
  hasDonatedToday: boolean;
  meritPoints: number;
}

const CharityScreen: React.FC<CharityScreenProps> = ({ onNavigate, hasDonatedToday, meritPoints }) => {
  const handleDonateClick = () => {
    onNavigate(Screen.DonationUpload);
  };
  
  const flowersToGoldAura = 9 - (meritPoints % 9);
  const currentCyclePoints = meritPoints % 9;

  if (hasDonatedToday) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center text-slate-300 pt-16 space-y-4">
        <div style={{animationDelay: '100ms'}} className="animate-slide-in-up relative">
          <LotusIcon className="w-24 h-24 text-pink-400 drop-shadow-[0_0_20px_rgba(244,114,182,0.6)]" />
          <SparklesIcon className="w-8 h-8 text-white absolute -top-2 -right-4 animate-pulse" />
        </div>
        <h1 style={{animationDelay: '200ms'}} className="text-2xl font-bold text-amber-200 animate-slide-in-up">อนุโมทนาบุญ!</h1>
        <p style={{animationDelay: '300ms'}} className="max-w-xs animate-slide-in-up leading-relaxed">
          การให้ของคุณในวันนี้เปรียบเสมือนการหว่านเมล็ดพันธุ์แห่งความดี ขอบคุณที่เป็นแสงสว่างให้ชุมชนของเรา
        </p>
        
        <div style={{animationDelay: '350ms'}} className="bg-amber-500/10 px-4 py-2 rounded-full border border-amber-500/30 animate-slide-in-up mt-4">
            <p className="text-sm text-amber-200 font-semibold flex items-center">
                <LotusIcon className="w-4 h-4 mr-2" /> 
                สะสมดอกบัวแล้ว: {meritPoints} ดอก
            </p>
        </div>

        <p style={{animationDelay: '400ms'}} className="text-sm text-slate-400 pt-2 animate-slide-in-up">
          คุณสามารถร่วมสะสมเสบียงบุญได้อีกครั้งในวันพรุ่งนี้
        </p>
         <div style={{animationDelay: '500ms'}} className="animate-slide-in-up">
            <button 
                onClick={() => onNavigate(Screen.TransparencyLog)}
                className="mt-4 text-sm text-amber-400 font-semibold hover:text-amber-300 underline underline-offset-4 decoration-amber-400/30"
            >
                ตรวจสอบเส้นทางบุญของชุมชน
            </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center h-full text-center text-slate-300 pt-16 space-y-5">
      <div style={{animationDelay: '100ms'}} className="relative animate-slide-in-up">
        {/* Main Golden Lotus Icon */}
        <LotusIcon className="w-28 h-28 text-amber-300 drop-shadow-[0_0_25px_rgba(251,191,36,0.5)]" />
        <SparklesIcon className="w-10 h-10 text-white absolute -top-2 -right-2 animate-pulse" />
      </div>
      
      <div style={{animationDelay: '200ms'}} className="animate-slide-in-up">
        <h1 className="text-2xl font-bold text-amber-100">สะสมเสบียงบุญ</h1>
        <p className="text-xs text-amber-200/70 uppercase tracking-widest mt-1">Merit Accumulation</p>
      </div>
      
      <div style={{animationDelay: '300ms'}} className="flex items-baseline justify-center animate-slide-in-up py-2">
          <span className="text-9xl font-extrabold tracking-tighter bg-gradient-to-b from-amber-100 via-yellow-400 to-amber-600 text-transparent bg-clip-text drop-shadow-[0_0_25px_rgba(234,179,8,0.6)] filter">9</span>
          <span className="text-3xl font-bold ml-2 text-amber-400 drop-shadow-sm">บาท</span>
      </div>

      <div style={{animationDelay: '400ms'}} className="bg-white/5 backdrop-blur-sm rounded-2xl p-4 border border-white/10 max-w-xs animate-slide-in-up shadow-lg">
        <p className="text-sm text-slate-200 leading-relaxed font-medium mb-2">
            "เงิน 9 บาทของท่าน จะเป็นแสงสว่างช่วยพัฒนา Lucky Station และร่วมสมทบทุนสาธารณกุศล"
        </p>
        
        {/* Gamification Progress */}
        <div className="mt-3 pt-3 border-t border-white/10">
            <div className="flex justify-between items-center text-xs mb-1">
                <span className="text-amber-200">ความก้าวหน้าบารมี</span>
                <span className="text-white/60">{currentCyclePoints}/9 🪷</span>
            </div>
            <div className="w-full bg-black/30 rounded-full h-2 overflow-hidden">
                <div className="bg-gradient-to-r from-pink-500 to-amber-400 h-full rounded-full transition-all duration-1000" style={{ width: `${(currentCyclePoints / 9) * 100}%` }}></div>
            </div>
            <p className="text-[10px] text-white/50 mt-1 text-left">
                อีก {flowersToGoldAura} ดอก เพื่อปลดล็อก <span className="text-amber-300">"ออร่าเศรษฐี"</span> (กรอบโปรไฟล์ทองคำ)
            </p>
        </div>
      </div>

      <div style={{animationDelay: '500ms'}} className="bg-slate-900/60 backdrop-blur-md rounded-xl p-3 border border-slate-700 w-full max-w-xs flex items-center space-x-4 animate-slide-in-up shadow-inner">
        <img 
          src="https://promptpay.io/0812345678.png" 
          alt="PromptPay QR Code" 
          className="w-20 h-20 rounded-lg bg-white p-1"
        />
        <div className="text-left">
            <p className="text-sm text-amber-300 font-bold">สแกน QR เพื่อร่วมบุญ</p>
            <p className="text-xs text-slate-400">Lucky Station</p>
            <p className="text-[10px] text-slate-500 mt-1">โดย Thanadol Wanluk</p>
        </div>
      </div>

      <div style={{animationDelay: '600ms'}} className="animate-slide-in-up w-full max-w-xs pb-10">
        <button 
            onClick={() => onNavigate(Screen.TransparencyLog)}
            className="text-xs text-amber-400/80 hover:text-amber-300 mb-3 block text-center"
        >
            ตรวจสอบเส้นทางบุญของชุมชน &rarr;
        </button>
        
        <button 
          onClick={handleDonateClick}
          className="w-full bg-gradient-to-r from-purple-600 to-indigo-700 text-white font-bold py-3.5 px-8 rounded-full shadow-[0_0_20px_rgba(147,51,234,0.3)] border border-white/20 transform hover:scale-105 transition-all duration-300 flex items-center justify-center group"
        >
          <span>แจ้งโอนเงิน / แนบสลิป</span>
          <span className="ml-2 group-hover:translate-x-1 transition-transform">&rarr;</span>
        </button>
        <p className="text-[10px] text-slate-500 mt-2">(เพื่อรับแต้มบุญ "ดอกบัวทองคำ")</p>
      </div>
    </div>
  );
};

export default CharityScreen;
