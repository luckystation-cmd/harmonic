
import React, { useState, useEffect } from 'react';
import { CrownIcon, CheckCircleIcon, CloseIcon, SparklesIcon, HeartIcon } from './icons';
import { soundService } from '../services/soundService';

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
}

const SubscriptionModal: React.FC<SubscriptionModalProps> = ({ isOpen, onClose, onConfirm }) => {
  const [state, setState] = useState<'idle' | 'processing' | 'success'>('idle');

  useEffect(() => {
    if (isOpen) {
      setState('idle');
      soundService.playInteraction('swoosh'); // Sound when modal opens
    }
  }, [isOpen]);

  const handleSubscribe = () => {
    soundService.playInteraction('tap');
    setState('processing');
    
    // Simulate payment processing time (2 seconds)
    setTimeout(() => {
      setState('success');
      soundService.playInteraction('success'); // Reward sound on success
      soundService.triggerHaptic('success');
      
      // Wait a moment to show success state then close
      setTimeout(() => {
        onConfirm();
      }, 1500);
    }, 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/90 backdrop-blur-md transition-opacity" onClick={state !== 'processing' ? onClose : undefined}></div>
      
      {/* Modal Content */}
      <div className="relative bg-gradient-to-br from-[#1a0b2e] via-[#2e1065] to-[#000000] border border-pink-400/40 rounded-3xl w-full max-w-sm overflow-hidden shadow-[0_0_50px_rgba(236,72,153,0.15)] animate-slide-in-up">
        
        {/* Close Button */}
        {state === 'idle' && (
            <button onClick={onClose} className="absolute top-4 right-4 text-white/30 hover:text-white transition-colors z-10 p-2 bg-white/5 rounded-full">
            <CloseIcon className="w-5 h-5" />
            </button>
        )}

        {state === 'idle' && (
            <div className="p-6 text-center space-y-6 relative">
                {/* Decorative Background */}
                <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-pink-500/10 to-transparent pointer-events-none"></div>

                <div className="relative">
                    <div className="w-24 h-24 bg-gradient-to-br from-pink-200 via-fuchsia-400 to-purple-700 rounded-full mx-auto flex items-center justify-center shadow-[0_0_30px_rgba(236,72,153,0.4)] mt-2 animate-pulse-slow">
                        <HeartIcon className="w-12 h-12 text-white drop-shadow-md" />
                    </div>
                    <div className="absolute -top-2 -right-2">
                        <SparklesIcon className="w-8 h-8 text-pink-200 animate-spin-slow" />
                    </div>
                </div>
                
                <div>
                    <h2 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-100 via-pink-200 to-purple-400 mb-1">สนับสนุนนักพัฒนา</h2>
                    <p className="text-sm text-pink-100/60 font-light">ร่วมเป็นส่วนหนึ่งในการขับเคลื่อน Luckystation</p>
                </div>

                <div className="space-y-3 text-left bg-white/5 p-5 rounded-2xl border border-white/10 backdrop-blur-sm shadow-inner">
                    <FeatureItem text="✨ ปลดล็อกสถานะผู้สนับสนุนหลัก" highlighted />
                    <FeatureItem text="🎗️ รายได้ส่วนหนึ่งร่วมทำบุญทุกเดือน" />
                    <FeatureItem text="🖼️ ช่วยค่าเซิร์ฟเวอร์ AI เพื่อทุกคน" />
                </div>

                <div className="pt-2">
                    <div className="flex items-baseline justify-center space-x-2 mb-4">
                        <span className="text-sm text-white/50">ร่วมสนับสนุนเพียง</span>
                        <span className="text-3xl font-bold text-pink-400">99.-</span>
                        <span className="text-sm text-white/50">/ เดือน</span>
                    </div>
                    
                    <button 
                        onClick={handleSubscribe}
                        className="w-full bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-600 text-white font-bold py-4 rounded-full shadow-[0_0_20px_rgba(236,72,153,0.3)] transform transition-all hover:scale-105 active:scale-95 hover:shadow-[0_0_30px_rgba(236,72,153,0.5)] flex items-center justify-center group"
                    >
                        <HeartIcon className="w-5 h-5 mr-2 animate-pulse text-pink-100" />
                        <span>กดสนับสนุน / ทำบุญ (Simulation)</span>
                    </button>
                    <p className="text-[10px] text-white/30 mt-3">
                        *ระบบจำลองการบริจาคเพื่อการกุศล (Simulation Mode)
                    </p>
                </div>
            </div>
        )}

        {state === 'processing' && (
            <div className="p-12 text-center space-y-6 flex flex-col items-center justify-center min-h-[450px]">
                 <div className="relative w-24 h-24">
                    <div className="absolute inset-0 border-4 border-t-pink-400 border-r-pink-400/30 border-b-pink-400/10 border-l-pink-400/30 rounded-full animate-spin"></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                        <HeartIcon className="w-10 h-10 text-pink-400/50 animate-pulse" />
                    </div>
                </div>
                <h3 className="text-xl font-bold text-white animate-pulse">กำลังส่งมอบความปรารถนาดี...</h3>
                <p className="text-sm text-white/50 leading-relaxed max-w-[200px]">
                    ขอบคุณที่เป็นพลังใจให้เราพัฒนาแอปดีๆ ต่อไป
                </p>
            </div>
        )}

        {state === 'success' && (
             <div className="p-12 text-center space-y-6 flex flex-col items-center justify-center min-h-[450px]">
                <div className="relative">
                    <div className="absolute inset-0 bg-green-500/30 rounded-full blur-xl animate-pulse"></div>
                    <div className="w-24 h-24 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(34,197,94,0.5)] relative z-10 animate-bounce">
                        <CheckCircleIcon className="w-14 h-14 text-white" />
                    </div>
                </div>
                <div>
                    <h2 className="text-2xl font-bold text-pink-300 mb-2">อนุโมทนาบุญ!</h2>
                    <p className="text-white/90">คุณคือ <span className="font-bold text-amber-400">"ผู้สนับสนุนหลัก"</span> ของเรา</p>
                </div>
                <p className="text-sm text-white/50">ขอให้ผลบุญหนุนนำชีวิตท่านให้เจริญรุ่งเรือง</p>
            </div>
        )}

      </div>
    </div>
  );
};

const FeatureItem: React.FC<{text: string, highlighted?: boolean}> = ({ text, highlighted }) => (
    <div className="flex items-start space-x-3">
        <div className={`mt-0.5 rounded-full p-0.5 ${highlighted ? 'bg-pink-400/20' : 'bg-white/10'}`}>
             <CheckCircleIcon className={`w-4 h-4 ${highlighted ? 'text-pink-400' : 'text-green-400/70'}`} />
        </div>
        <span className={`text-sm ${highlighted ? 'text-pink-100 font-medium' : 'text-white/70'}`}>{text}</span>
    </div>
);

export default SubscriptionModal;
