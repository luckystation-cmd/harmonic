
import React, { useState, useRef } from 'react';
import { SymbolAnalysisIcon, CameraIcon, CloseIcon } from './icons';

interface SymbolAnalysisScreenProps {
  onAnalyze: (base64Data: string, mimeType: string) => void;
  onBack: () => void;
}

const blobToBase64 = (blob: Blob): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      // remove the data url prefix
      resolve(base64String.split(',')[1]);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
};

const SymbolAnalysisScreen: React.FC<SymbolAnalysisScreenProps> = ({ onAnalyze, onBack }) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [processingState, setProcessingState] = useState<'idle' | 'analyzing'>('idle');
  
  // Refs for inputs
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0];
      setSelectedFile(file);
      if (previewUrl) {
          URL.revokeObjectURL(previewUrl);
      }
      setPreviewUrl(URL.createObjectURL(file));
    }
  };

  const handleAnalyzeClick = async () => {
    if (!selectedFile) return;
    setProcessingState('analyzing');
    try {
      const base64Data = await blobToBase64(selectedFile);
      onAnalyze(base64Data, selectedFile.type);
    } catch (error: any) {
      console.error("Error processing file for analysis:", error);
      alert("เกิดข้อผิดพลาดในการประมวลผลไฟล์");
      setProcessingState('idle');
    }
  };
  
  const handleClearSelection = () => {
    setSelectedFile(null);
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
      setPreviewUrl(null);
    }
    setProcessingState('idle');
    // Reset inputs
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (cameraInputRef.current) cameraInputRef.current.value = '';
  };

  return (
    <div className="flex flex-col items-center justify-center h-full text-center text-stone-700 dark:text-stone-300 space-y-6 pt-16">
      <button onClick={onBack} className="absolute top-6 left-6 text-amber-300 font-semibold bg-black/20 px-3 py-1 rounded-full z-20">
        &larr; กลับ
      </button>

      <div style={{animationDelay: '100ms'}} className="animate-slide-in-up">
        <SymbolAnalysisIcon className="w-20 h-20 text-purple-300" />
      </div>

      <div style={{animationDelay: '200ms'}} className="animate-slide-in-up">
        <h1 className="text-2xl font-bold text-white">วิเคราะห์สัญลักษณ์มงคล</h1>
        <p className="mt-2 max-w-xs text-white/70">
          AI Scanner: ค้นหาความหมายจิตวิญญาณ & ตรวจสอบว่าเป็นภาพจริงหรือ AI
        </p>
      </div>
      
      <div style={{animationDelay: '300ms'}} className="w-full max-w-xs space-y-4 animate-slide-in-up">
        <div className="w-full bg-black/10 dark:bg-white/5 border-2 border-dashed border-black/20 dark:border-white/20 rounded-lg text-center flex flex-col items-center justify-center aspect-square relative">
          {previewUrl ? (
            <>
              <img src={previewUrl} alt="Preview" className="max-h-full max-w-full rounded-md object-contain" />
              <button onClick={handleClearSelection} className="absolute top-2 right-2 bg-black/50 text-white rounded-full p-1.5 backdrop-blur-sm" aria-label="Clear selection">
                <CloseIcon className="w-5 h-5" />
              </button>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center h-full w-full p-4 space-y-4">
              {/* File Upload */}
              <button onClick={() => fileInputRef.current?.click()} className="flex-1 w-full flex flex-col items-center justify-center bg-amber-500/10 border border-amber-500/30 hover:bg-amber-500/20 rounded-lg cursor-pointer transition-colors p-4 shadow-sm">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-amber-300" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                <span className="mt-2 text-amber-200 font-bold">เลือกจากคลังภาพ</span>
              </button>
              
              {/* Camera Button */}
              <button onClick={() => cameraInputRef.current?.click()} className="flex-1 w-full flex flex-col items-center justify-center bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg cursor-pointer transition-colors p-2">
                <CameraIcon className="h-8 w-8 text-stone-500 dark:text-stone-400" />
                <span className="mt-2 text-stone-600 dark:text-stone-300 font-medium text-sm">ถ่ายภาพ</span>
              </button>

               {/* Hidden Inputs */}
              <input id="image-upload" type="file" accept="image/*" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
              <input type="file" accept="image/*" capture="environment" ref={cameraInputRef} onChange={handleFileChange} className="hidden" />
            </div>
          )}
        </div>
      </div>

      <div style={{animationDelay: '400ms'}} className="animate-slide-in-up">
        <button
          onClick={handleAnalyzeClick}
          disabled={!selectedFile || processingState !== 'idle'}
          className={`px-8 py-3 rounded-full font-bold text-lg transition-all duration-300 w-64 ${
            selectedFile && processingState === 'idle'
              ? 'bg-amber-400 text-purple-900 shadow-lg shadow-amber-400/20 transform hover:scale-105'
              : 'bg-stone-400/50 dark:bg-stone-500/20 text-stone-600 dark:text-stone-400 cursor-not-allowed'
          }`}
        >
          {processingState === 'analyzing' ? 'กำลังสแกน...' : 'เริ่มวิเคราะห์'}
        </button>
      </div>
    </div>
  );
};

export default SymbolAnalysisScreen;
