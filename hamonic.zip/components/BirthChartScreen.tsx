import React, { useState, useEffect } from 'react';
import { BirthChartIcon } from './icons';
import { UserProfile } from '../types';

type AstrologyType = 'chinese' | 'thai';

interface BirthChartScreenProps {
  // FIX: Moved required parameter 'type' before optional parameters 'day' and 'month' to fix TypeScript error.
  onGenerate: (year: number, type: AstrologyType, day?: number, month?: number) => void;
  onBack: () => void;
  userDOB?: UserProfile['dob'];
}

const BirthChartScreen: React.FC<BirthChartScreenProps> = ({ onGenerate, onBack, userDOB }) => {
  const [birthYear, setBirthYear] = useState<string>('');
  const [birthMonth, setBirthMonth] = useState<string>('');
  const [birthDay, setBirthDay] = useState<string>('');
  const [astrologyType, setAstrologyType] = useState<AstrologyType>('chinese');
  
  const currentBuddhistYear = new Date().getFullYear() + 543;
  const minYear = currentBuddhistYear - 100;

  useEffect(() => {
    if (userDOB) {
      if (userDOB.year) setBirthYear((userDOB.year + 543).toString());
      if (userDOB.month) setBirthMonth(userDOB.month.toString());
      if (userDOB.day) setBirthDay(userDOB.day.toString());
    }
  }, [userDOB]);

  const handleGenerateClick = () => {
    const yearNumber = parseInt(birthYear, 10);
    const monthNumber = birthMonth ? parseInt(birthMonth, 10) : undefined;
    const dayNumber = birthDay ? parseInt(birthDay, 10) : undefined;

    if (!isNaN(yearNumber) && yearNumber >= minYear && yearNumber <= currentBuddhistYear) {
      // Basic validation for day and month
      if (monthNumber && (monthNumber < 1 || monthNumber > 12)) {
        alert('เดือนเกิดต้องอยู่ระหว่าง 1 - 12');
        return;
      }
      if (dayNumber && (dayNumber < 1 || dayNumber > 31)) {
        alert('วันที่เกิดต้องอยู่ระหว่าง 1 - 31');
        return;
      }

      const gregorianYear = yearNumber - 543;
      // FIX: Updated the function call to match the new signature of 'onGenerate'.
      onGenerate(gregorianYear, astrologyType, dayNumber, monthNumber);
    } else {
      alert(`กรุณาระบุปี พ.ศ. ที่ถูกต้อง (ระหว่าง ${minYear} - ${currentBuddhistYear})`);
    }
  };
  
  const handleYearChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (/^\d{0,4}$/.test(value)) {
      setBirthYear(value);
    }
  };

  const handleMonthChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (/^\d{0,2}$/.test(value)) {
      setBirthMonth(value);
    }
  };

  const handleDayChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (/^\d{0,2}$/.test(value)) {
      setBirthDay(value);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-full text-center text-slate-300 space-y-6 pt-16">
      <button onClick={onBack} className="absolute top-6 left-6 text-amber-300 font-semibold bg-black/30 px-3 py-1 rounded-full">
        &larr; กลับ
      </button>
      
      <div style={{animationDelay: '100ms'}} className="animate-slide-in-up">
        <BirthChartIcon className="w-20 h-20 text-purple-300" />
      </div>

      <div style={{animationDelay: '200ms'}} className="animate-slide-in-up">
        <h1 className="text-2xl font-bold text-slate-200">ผูกดวงชะตา (Beta)</h1>
        <p className="mt-2 max-w-xs text-slate-300/90">
          เลือกศาสตร์ที่ต้องการและกรอกข้อมูลเพื่อวิเคราะห์พื้นดวง
        </p>
      </div>

       <div style={{animationDelay: '300ms'}} className="bg-slate-800 p-1 rounded-full flex w-full max-w-xs animate-slide-in-up">
        <button
            onClick={() => setAstrologyType('chinese')}
            className={`w-1/2 py-2 rounded-full text-sm font-semibold transition-colors duration-300 ${astrologyType === 'chinese' ? 'bg-purple-600 text-white' : 'text-purple-200'}`}
        >
            โหราศาสตร์จีน
        </button>
        <button
            onClick={() => setAstrologyType('thai')}
            className={`w-1/2 py-2 rounded-full text-sm font-semibold transition-colors duration-300 ${astrologyType === 'thai' ? 'bg-purple-600 text-white' : 'text-purple-200'}`}
        >
            โหราศาสตร์ไทย
        </button>
      </div>

      <div style={{animationDelay: '400ms'}} className="w-full max-w-xs space-y-3 animate-slide-in-up">
         <input
          type="number"
          value={birthYear}
          onChange={handleYearChange}
          placeholder="ระบุปีเกิด (พ.ศ.)"
          className="w-full bg-slate-800 border border-slate-600 rounded-lg p-3 text-center text-white placeholder-slate-400 font-semibold appearance-none focus:outline-none focus:ring-2 focus:ring-amber-400 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
          max={currentBuddhistYear}
          min={minYear}
          autoComplete="off"
          autoCorrect="off"
          spellCheck="false"
        />
        <div className="flex space-x-3">
            <input
                type="number"
                value={birthDay}
                onChange={handleDayChange}
                placeholder="วันที่เกิด (ไม่บังคับ)"
                className="w-1/2 bg-slate-800 border border-slate-600 rounded-lg p-3 text-center text-white placeholder-slate-400 font-semibold appearance-none focus:outline-none focus:ring-2 focus:ring-amber-400 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                min="1"
                max="31"
                autoComplete="off"
                autoCorrect="off"
                spellCheck="false"
            />
            <input
                type="number"
                value={birthMonth}
                onChange={handleMonthChange}
                placeholder="เดือนเกิด (ไม่บังคับ)"
                className="w-1/2 bg-slate-800 border border-slate-600 rounded-lg p-3 text-center text-white placeholder-slate-400 font-semibold appearance-none focus:outline-none focus:ring-2 focus:ring-amber-400 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                min="1"
                max="12"
                autoComplete="off"
                autoCorrect="off"
                spellCheck="false"
            />
        </div>
      </div>

      <div style={{animationDelay: '500ms'}} className="animate-slide-in-up">
        <button
          onClick={handleGenerateClick}
          disabled={!birthYear || birthYear.length < 4}
          className={`px-8 py-3 rounded-full font-bold text-lg transition-all duration-300 ${
            birthYear && birthYear.length === 4
              ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/20 transform hover:scale-105'
              : 'bg-slate-700 text-slate-400 cursor-not-allowed'
          }`}
        >
          เริ่มวิเคราะห์
        </button>
      </div>
    </div>
  );
};

export default BirthChartScreen;