import React, { useState, useEffect } from 'react';
import { BirthChartIcon } from './icons';
import { UserProfile } from '../types';

interface WallpaperScreenProps {
  onGenerate: (year: number) => void;
  onBack: () => void;
  userDOB?: UserProfile['dob'];
}

const WallpaperScreen: React.FC<WallpaperScreenProps> = ({ onGenerate, onBack, userDOB }) => {
  const [birthYear, setBirthYear] = useState<string>('');
  const currentBuddhistYear = new Date().getFullYear() + 543;
  const minYear = currentBuddhistYear - 100; // Allow ages up to 100
  
  useEffect(() => {
    if (userDOB?.year) {
      const buddhistYear = userDOB.year + 543;
      setBirthYear(buddhistYear.toString());
    }
  }, [userDOB]);

  const handleGenerateClick = () => {
    const yearNumber = parseInt(birthYear, 10);
    if (!isNaN(yearNumber) && yearNumber >= minYear && yearNumber <= currentBuddhistYear) {
      const gregorianYear = yearNumber - 543; // Convert BE to CE for API
      onGenerate(gregorianYear);
    } else {
        alert(`กรุณาระบุปี พ.ศ. ที่ถูกต้อง (ระหว่าง ${minYear} - ${currentBuddhistYear})`);
    }
  };
  
  const handleYearChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    // Allow only numbers and limit to 4 digits
    if (/^\d{0,4}$/.test(value)) {
        setBirthYear(value);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-full text-center text-slate-300 space-y-8 pt-16">
      <button onClick={onBack} className="absolute top-6 left-6 text-amber-300 font-semibold bg-black/30 px-3 py-1 rounded-full">
        &larr; กลับ
      </button>
      
      <div style={{animationDelay: '100ms'}} className="animate-slide-in-up">
        <BirthChartIcon className="w-20 h-20 text-amber-200 opacity-80" />
      </div>

      <div style={{animationDelay: '200ms'}} className="animate-slide-in-up">
        <h1 className="text-2xl font-bold text-amber-200">สร้างวอลเปเปอร์เสริมดวง</h1>
        <p className="mt-2 max-w-xs text-slate-200/90">
          ระบุปีเกิด (พ.ศ.) ของคุณเพื่อสร้างวอลเปเปอร์ที่ไม่เหมือนใคร
        </p>
      </div>

      <div style={{animationDelay: '300ms'}} className="w-full max-w-xs animate-slide-in-up">
         <input
          type="number"
          value={birthYear}
          onChange={handleYearChange}
          placeholder="ระบุปีเกิด (พ.ศ.)"
          className="w-full bg-slate-800 border border-slate-600 rounded-lg p-3 text-center text-white placeholder-slate-400 font-semibold appearance-none focus:outline-none focus:ring-2 focus:ring-amber-400 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
          max={currentBuddhistYear}
          min={minYear}
          autoComplete="off"
          autoCorrect="off"
          spellCheck="false"
        />
      </div>

      <div style={{animationDelay: '400ms'}} className="animate-slide-in-up">
        <button
          onClick={handleGenerateClick}
          disabled={!birthYear || birthYear.length < 4}
          className={`px-8 py-3 rounded-full font-bold text-lg transition-all duration-300 ${
            birthYear && birthYear.length === 4
              ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/20 transform hover:scale-105'
              : 'bg-slate-700 text-slate-400 cursor-not-allowed'
          }`}
        >
          เริ่มสร้างวอลเปเปอร์
        </button>
      </div>
    </div>
  );
};

export default WallpaperScreen;