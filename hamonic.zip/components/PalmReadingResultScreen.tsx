
import React, { useState, useEffect } from 'react';
import { getPalmReadingAnalysis } from '../services/geminiService';
import { PalmReadingAnalysis, PalmLineAnalysis } from '../types';
import { PalmIcon } from './icons';

interface PalmReadingResultScreenProps {
  imageData: {
    data: string;
    mimeType: string;
  };
  onBack: () => void;
}

const FormattedText: React.FC<{ text: string }> = ({ text }) => {
    const parts = text.split(/(\*\*.*?\*\*|\*.*?\*)/g);
    return (
        <span>
            {parts.map((part, index) => {
                if (part.startsWith('**') && part.endsWith('**')) {
                    return <span key={index} className="font-bold text-amber-300">{part.slice(2, -2)}</span>;
                }
                if (part.startsWith('*') && part.endsWith('*')) {
                     return <span key={index} className="italic text-purple-300">{part.slice(1, -1)}</span>;
                }
                return <span key={index}>{part}</span>;
            })}
        </span>
    );
};

const LoadingIndicator: React.FC = () => (
    <div className="flex flex-col items-center justify-center text-center space-y-4 h-full">
        <div className="relative w-20 h-20">
            <div className="absolute inset-0 border-4 border-t-purple-500 border-white/10 rounded-full animate-spin"></div>
            <div className="absolute inset-0 flex items-center justify-center">
                <PalmIcon className="w-8 h-8 text-white/50 animate-pulse" />
            </div>
        </div>
        <p className="text-white font-medium animate-pulse">ปรมาจารย์กำลังสแกนฝ่ามือ...</p>
        <p className="text-xs text-white/50">วิเคราะห์: เนิน • เส้นหลัก • สัญลักษณ์พิเศษ</p>
    </div>
);

const LineAnalysisSection: React.FC<{ 
    title: string;
    line: PalmLineAnalysis;
    icon: string; 
}> = ({ title, line, icon }) => (
    <div className="glass-card p-4 rounded-xl border border-white/10 space-y-3 hover:bg-white/5 transition-colors">
        <h3 className="text-lg font-bold text-white flex items-center justify-between">
            <span className="flex items-center">
                <span className="text-2xl mr-3 drop-shadow-sm">{icon}</span>
                {title}
            </span>
        </h3>
        
        <div className="bg-white/5 rounded-lg p-3 border-l-2 border-purple-400">
            <p className="text-xs text-purple-300 font-bold mb-1 uppercase tracking-wider">ลักษณะที่พบ</p>
            <p className="text-white/90 text-sm leading-relaxed"><FormattedText text={line.description} /></p>
        </div>

        <div className="bg-white/5 rounded-lg p-3 border-l-2 border-amber-400">
             <p className="text-xs text-amber-300 font-bold mb-1 uppercase tracking-wider">คำทำนาย</p>
            <p className="text-white/90 text-sm leading-relaxed"><FormattedText text={line.prediction} /></p>
        </div>

        {line.age_timing && (
            <div className="flex items-center space-x-2 mt-2 text-xs text-stone-400 bg-black/20 p-2 rounded-lg">
                <span className="font-bold text-stone-300">⏳ ช่วงอายุสำคัญ:</span>
                <span><FormattedText text={line.age_timing} /></span>
            </div>
        )}
    </div>
);

const PalmReadingResultScreen: React.FC<PalmReadingResultScreenProps> = ({ imageData, onBack }) => {
  const [reading, setReading] = useState<PalmReadingAnalysis | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const analyze = async () => {
      try {
        const result = await getPalmReadingAnalysis(imageData.data, imageData.mimeType);
        setReading(result);
      } catch (err: any) {
        setError(err.message || 'ไม่สามารถวิเคราะห์ลายมือได้');
      } finally {
        setIsLoading(false);
      }
    };
    analyze();
  }, [imageData]);

  const imageUrl = `data:${imageData.mimeType};base64,${imageData.data}`;

  if (isLoading) {
    return <LoadingIndicator />;
  }

  if (error || !reading) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center px-6">
        <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mb-4 border border-red-500/30">
            <span className="text-3xl">⚠️</span>
        </div>
        <p className="text-red-200 font-bold text-lg mb-2">เกิดข้อผิดพลาด</p>
        <p className="text-white/60 mb-6 text-sm">{error}</p>
        <button onClick={onBack} className="bg-white/10 border border-white/20 text-white py-3 px-8 rounded-full font-bold transition-all hover:bg-white/20 hover:scale-105">
          ลองอีกครั้ง
        </button>
      </div>
    );
  }

  return (
    <div className="animate-fade-in space-y-6 pb-20">
      <header className="text-center space-y-2">
         <div className="inline-block p-3 rounded-full bg-purple-500/20 border border-purple-500/30 mb-2">
            <PalmIcon className="w-8 h-8 text-purple-300"/>
         </div>
        <h1 className="text-2xl font-bold text-white tracking-tight">คำทำนายหัตถศาสตร์</h1>
        <p className="text-xs text-white/50">วิเคราะห์โดย Grandmaster AI</p>
      </header>
      
      <div className="relative group mx-auto max-w-xs">
         <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
         <div className="relative rounded-xl overflow-hidden border border-white/10 bg-black/40">
            <img src={imageUrl} alt="Uploaded palm" className="w-full h-48 object-contain opacity-90" />
            <div className="absolute top-0 left-0 w-full h-1 bg-amber-400/30 shadow-[0_0_15px_rgba(251,191,36,0.5)] animate-[scan_3s_ease-in-out_infinite]"></div>
         </div>
      </div>

       <blockquote className="px-6 py-4 bg-gradient-to-r from-purple-900/40 to-indigo-900/40 border-l-4 border-amber-400 rounded-r-lg backdrop-blur-sm shadow-md">
        <h4 className="text-amber-400 text-xs font-bold uppercase mb-1 tracking-widest">บทสรุปดวงชะตา</h4>
        <p className="text-white text-lg leading-relaxed italic font-medium">
          "<FormattedText text={reading.final_verdict} />"
        </p>
      </blockquote>
        
      <div className="glass-card p-4 rounded-xl border border-purple-500/30 bg-purple-900/20">
        <h3 className="text-sm font-bold text-purple-200 uppercase tracking-wider mb-3 flex items-center">
            <span className="text-lg mr-2">✨</span> เนิน & สัญลักษณ์พิเศษ
        </h3>
        
        <div className="space-y-3">
            {reading.hand_analysis.dominant_mounts && (
                <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 mt-1.5 rounded-full bg-amber-400"></div>
                    <div>
                        <p className="text-white font-bold"><FormattedText text={reading.hand_analysis.dominant_mounts.mount_name} /></p>
                        <p className="text-white/70 text-sm"><FormattedText text={reading.hand_analysis.dominant_mounts.meaning} /></p>
                    </div>
                </div>
            )}
            
            {reading.special_signs && reading.special_signs.length > 0 && (
                <div className="flex items-start space-x-3">
                     <div className="w-2 h-2 mt-1.5 rounded-full bg-cyan-400"></div>
                     <div>
                        <p className="text-white font-bold">สัญลักษณ์ที่พบ:</p>
                        <div className="flex flex-wrap gap-2 mt-1">
                            {reading.special_signs.map((sign, idx) => (
                                <span key={idx} className="text-xs bg-cyan-900/40 text-cyan-200 px-2 py-1 rounded border border-cyan-500/30">
                                    <FormattedText text={sign} />
                                </span>
                            ))}
                        </div>
                     </div>
                </div>
            )}
        </div>
      </div>

      <div className="bg-red-900/10 border border-red-500/30 rounded-xl p-4 space-y-3">
        <h3 className="text-sm font-bold text-red-300 uppercase tracking-wider flex items-center">
             <span className="text-lg mr-2">⚠️</span> ข้อควรระวัง (Cautions)
        </h3>
        <div className="grid grid-cols-1 gap-2 text-sm">
            <div className="flex items-start space-x-2">
                <span className="text-red-400 font-bold w-16 flex-shrink-0">สุขภาพ:</span>
                <span className="text-white/80"><FormattedText text={reading.cautions.health} /></span>
            </div>
             <div className="flex items-start space-x-2">
                <span className="text-red-400 font-bold w-16 flex-shrink-0">การเงิน:</span>
                <span className="text-white/80"><FormattedText text={reading.cautions.finance} /></span>
            </div>
             <div className="flex items-start space-x-2">
                <span className="text-red-400 font-bold w-16 flex-shrink-0">ความรัก:</span>
                <span className="text-white/80"><FormattedText text={reading.cautions.love} /></span>
            </div>
        </div>
      </div>

      <div className="space-y-4">
          <LineAnalysisSection title="เส้นชีวิต (Life Line)" line={reading.hand_analysis.life_line} icon="🌿" />
          <LineAnalysisSection title="เส้นสมอง (Head Line)" line={reading.hand_analysis.head_line} icon="🧠" />
          <LineAnalysisSection title="เส้นใจ (Heart Line)" line={reading.hand_analysis.heart_line} icon="❤️" />
          <LineAnalysisSection title="เส้นวาสนา (Fate Line)" line={reading.hand_analysis.fate_line} icon="✨" />
      </div>
      
       <div className="text-center pb-4">
         <p className="text-[10px] text-white/30 mb-4 max-w-xs mx-auto">
            *ผลการวิเคราะห์เป็นเพียงความเชื่อส่วนบุคคล โปรดใช้วิจารณญาณ
         </p>
         <button onClick={onBack} className="w-full bg-white/10 border border-white/20 text-white py-3 rounded-full font-bold transition-all hover:bg-white/20 hover:scale-[1.02] active:scale-95 shadow-lg">
            สแกนมืออีกครั้ง
        </button>
       </div>

       <style>{`
        @keyframes scan {
            0%, 100% { top: 0%; opacity: 0; }
            10% { opacity: 1; }
            90% { opacity: 1; }
            100% { top: 100%; opacity: 0; }
        }
       `}</style>
    </div>
  );
};

export default PalmReadingResultScreen;
