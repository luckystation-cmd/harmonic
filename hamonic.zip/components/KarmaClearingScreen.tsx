import React, { useState, useRef, useEffect } from 'react';
import { KarmaRitualType } from '../types';
import { LotusIcon, LanternIcon, FishIcon, BirdIcon } from './icons';

type Step = 'intention' | 'writing' | 'choice' | 'releasing';

interface KarmaClearingScreenProps {
  onComplete: (worryText: string, ritualType: KarmaRitualType) => void;
  onBack: () => void;
}

const KarmaClearingScreen: React.FC<KarmaClearingScreenProps> = ({ onComplete, onBack }) => {
  const [step, setStep] = useState<Step>('intention');
  const [worryText, setWorryText] = useState('');
  const [ritualType, setRitualType] = useState<KarmaRitualType | null>(null);
  const [isReleased, setIsReleased] = useState(false);
  
  // FIX: Replaced NodeJS.Timeout with ReturnType<typeof setTimeout> which is browser-compatible.
  const holdTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [holdProgress, setHoldProgress] = useState(0);

  // Ref to store the starting Y coordinate of a touch
  const touchStartY = useRef<number | null>(null);

  const startHold = () => {
    setHoldProgress(0);
    holdTimeout.current = setTimeout(() => {
      setStep('writing');
    }, 2000); // 2 seconds to complete
    
    const interval = setInterval(() => {
        setHoldProgress(p => p + 5);
    }, 100);

    setTimeout(() => clearInterval(interval), 2000);
  };

  const endHold = () => {
    if (holdTimeout.current) {
      clearTimeout(holdTimeout.current);
    }
    setHoldProgress(0);
  };

  const handleRitualChoice = (type: KarmaRitualType) => {
    setRitualType(type);
    setStep('releasing');
  };

  const handleRelease = () => {
    if (!ritualType || isReleased) return;
    setIsReleased(true);
    setTimeout(() => {
      onComplete(worryText, ritualType);
    }, 4000); // Wait for animation to finish (4s)
  };
  
  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (isReleased) return;
    // Store the initial touch position
    touchStartY.current = e.touches[0].clientY;
  };

  const handleTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    if (isReleased || touchStartY.current === null) return;

    const touchEndY = e.changedTouches[0].clientY;
    const deltaY = touchStartY.current - touchEndY; // A positive delta indicates an upward swipe

    // If the swipe is upward and more than 50 pixels, trigger the release
    if (deltaY > 50) {
        handleRelease();
    }

    // Reset the starting touch position
    touchStartY.current = null;
  };

  const renderStep = () => {
    switch (step) {
      case 'intention':
        return (
          <div className="flex flex-col items-center justify-center text-center space-y-6 animate-fade-in">
            <LotusIcon className="w-20 h-20 text-amber-200" />
            <h1 className="text-2xl font-bold text-slate-200">ขั้นตอนที่ 1: ตั้งจิตอธิษฐาน</h1>
            <p className="max-w-xs text-slate-300/90">รวมสมาธิของคุณไปที่เรื่องที่ต้องการปล่อยวาง จากนั้นกดปุ่มค้างไว้เพื่อตั้งจิต</p>
            <div className="relative">
              <button
                onMouseDown={startHold}
                onMouseUp={endHold}
                onTouchStart={startHold}
                onTouchEnd={endHold}
                className="w-32 h-32 rounded-full bg-slate-800/50 border-2 border-amber-300/50 backdrop-blur-md text-amber-200 font-semibold active:scale-95 transition-transform"
              >
                กดค้างไว้
              </button>
              <div
                className="absolute inset-0 rounded-full border-4 border-amber-300 transition-all duration-2000 ease-linear"
                style={{ clipPath: `inset(${50 - holdProgress / 2}% 0 ${50 - holdProgress / 2}% 0)` }}
              />
            </div>
          </div>
        );
      case 'writing':
        return (
          <div className="flex flex-col items-center justify-center text-center space-y-6 animate-fade-in w-full">
            <h1 className="text-2xl font-bold text-slate-200">ขั้นตอนที่ 2: ระบายสิ่งที่กังวล</h1>
            <p className="max-w-xs text-slate-300/90">เขียนสิ่งที่คุณต้องการปล่อยวางลงในพื้นที่ด้านล่าง</p>
            <textarea
              value={worryText}
              onChange={(e) => setWorryText(e.target.value)}
              placeholder="ข้าพเจ้าขอปล่อยวาง..."
              className="w-full max-w-sm h-40 bg-slate-800 border border-slate-600 rounded-lg p-4 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-400"
              autoComplete="off"
              autoCorrect="off"
              spellCheck="false"
            />
            <p className="text-xs text-slate-500">🔒 ข้อความนี้จะถูกทำลายทิ้งและไม่ถูกบันทึกในระบบ</p>
            <button onClick={() => setStep('choice')} disabled={!worryText} className="px-8 py-3 rounded-full font-bold text-lg bg-amber-400 text-slate-900 shadow-lg shadow-amber-400/20 disabled:bg-slate-700 disabled:text-slate-400 disabled:shadow-none transition-all">
              ต่อไป
            </button>
          </div>
        );
      case 'choice':
        const rituals = [
          { type: 'lantern', icon: LanternIcon, name: 'ปล่อยโคมลอย' },
          { type: 'fish', icon: FishIcon, name: 'ปล่อยปลา' },
          { type: 'bird', icon: BirdIcon, name: 'ปล่อยนก' },
        ];
        return (
           <div className="flex flex-col items-center justify-center text-center space-y-6 animate-fade-in w-full">
            <h1 className="text-2xl font-bold text-slate-200">ขั้นตอนที่ 3: เลือกวิธีปล่อยวาง</h1>
            <p className="max-w-xs text-slate-300/90">เลือกพิธีกรรมเชิงสัญลักษณ์ที่ตรงกับความรู้สึกของคุณ</p>
            <div className="grid grid-cols-3 gap-4 w-full max-w-sm">
              {rituals.map(r => {
                const Icon = r.icon;
                return (
                  <button key={r.type} onClick={() => handleRitualChoice(r.type as KarmaRitualType)} className="bg-slate-800/50 rounded-xl p-4 flex flex-col items-center justify-center aspect-square space-y-2 border border-slate-700 hover:bg-slate-700/50 transition-colors">
                    <Icon className="w-12 h-12 text-amber-200" />
                    <span className="text-sm text-center font-medium text-slate-200">{r.name}</span>
                  </button>
                )
              })}
            </div>
          </div>
        )
      case 'releasing':
        const ritualDetails = {
          lantern: { icon: LanternIcon, text: "ปัดขึ้นเพื่อปล่อยโคม", bg: 'from-indigo-900 to-black', animation: 'animate-float-away-lantern' },
          fish: { icon: FishIcon, text: "ปัดขึ้นเพื่อปล่อยปลา", bg: 'from-cyan-800 to-blue-900', animation: 'animate-swim-away-fish' },
          bird: { icon: BirdIcon, text: "ปัดขึ้นเพื่อปล่อยนก", bg: 'from-sky-500 to-indigo-600', animation: 'animate-fly-away-bird' },
        };
        const currentRitual = ritualDetails[ritualType!];
        const Icon = currentRitual.icon;
        return (
          <div className={`fixed inset-0 z-50 flex flex-col items-center justify-center text-center space-y-6 animate-fade-in w-full max-w-md mx-auto bg-gradient-to-b ${currentRitual.bg}`}>
            <style>{`
              @keyframes float-away-lantern {
                0% { transform: translateY(0) scale(1) rotate(0deg); opacity: 1; }
                20% { transform: translateY(-15vh) scale(1.05) rotate(-2deg); }
                40% { transform: translateY(-30vh) scale(1) rotate(2deg); }
                100% { transform: translateY(-90vh) scale(0.1) rotate(0deg); opacity: 0; }
              }
              .animate-float-away-lantern {
                animation: float-away-lantern 4s cubic-bezier(0.5, 0, 0.8, 0.5) forwards;
              }

              @keyframes swim-away-fish {
                0% { transform: translateY(0) scale(1) rotate(0deg); opacity: 1; }
                100% { transform: translateY(90vh) scale(0.2) rotate(10deg); opacity: 0; }
              }
              .animate-swim-away-fish {
                animation: swim-away-fish 4s cubic-bezier(0.5, 0, 0.8, 0.5) forwards;
              }

              @keyframes fly-away-bird {
                0% { transform: translate(0, 0) scale(1) rotate(0deg); opacity: 1; }
                100% { transform: translate(20vw, -90vh) scale(0.2) rotate(15deg); opacity: 0; }
              }
              .animate-fly-away-bird {
                animation: fly-away-bird 4s cubic-bezier(0.5, 0, 0.8, 0.5) forwards;
              }
            `}</style>
             <div 
                className={`relative cursor-pointer ${isReleased ? currentRitual.animation : ''}`}
                onClick={handleRelease}
                onTouchStart={handleTouchStart}
                onTouchEnd={handleTouchEnd}
             >
              <Icon className="w-32 h-32 text-amber-200 drop-shadow-lg" />
            </div>
            <p className={`text-xl font-semibold text-white transition-opacity duration-500 ${isReleased ? 'opacity-0' : 'opacity-100 animate-pulse'}`}>
                {currentRitual.text}
            </p>
             {isReleased && (
                <p className="text-xl font-semibold text-white transition-opacity duration-1000 delay-1000 opacity-100 animate-fade-in">
                    กำลังส่งเจตจำนง...
                </p>
            )}
          </div>
        )
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-full pt-16">
      <button onClick={onBack} className="absolute top-6 left-6 text-amber-300 font-semibold bg-black/30 px-3 py-1 rounded-full z-20">
        &larr; กลับ
      </button>
      {renderStep()}
    </div>
  );
};

export default KarmaClearingScreen;