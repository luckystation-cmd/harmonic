import React, { useMemo } from 'react';
import { BrainIcon as LogoIcon, BirthChartIcon, SymbolAnalysisIcon, PalmIcon, LotusIcon, StarIcon, CalendarIcon, PaintBrushIcon, FlameIcon, SparklesIcon } from './icons';
import { DAILY_ENGAGEMENT_PROMPTS } from '../constants';
import { Screen } from '../types';

interface HomeScreenProps {
  onStartReading: (category: string) => void;
  onStartWallpaper: () => void;
  onStartBirthChart: () => void;
  onStartSymbolAnalysis: () => void;
  onStartPalmReading: () => void;
  onStartKarmaClearing: () => void;
  onStartPersonalCounselor: () => void;
  userName: string;
  lastLogin?: string;
  streak: number;
  isPremium: boolean;
  onUpgrade: () => void;
  onNavigate: (screen: Screen) => void;
}

const getDailyVibe = (date: Date) => {
    const dayOfYear = Math.floor((date.getTime() - new Date(date.getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24));
    const seed = date.getFullYear() * 1000 + dayOfYear;
    
    // Enhanced Palette
    const colors = [
        { name: 'Emerald', hex: '#10B981', glow: 'shadow-emerald-500/50' }, 
        { name: 'Cyan', hex: '#06B6D4', glow: 'shadow-cyan-500/50' },
        { name: 'Amethyst', hex: '#A855F7', glow: 'shadow-purple-500/50' }, 
        { name: 'Gold', hex: '#F59E0B', glow: 'shadow-amber-500/50' },
        { name: 'Rose', hex: '#F43F5E', glow: 'shadow-rose-500/50' },
    ];
    
    const mantras = [
        "จักรวาลจัดสรรสิ่งที่ดีที่สุดให้คุณเสมอ",
        "วันนี้คือโอกาสแห่งการเริ่มต้นใหม่",
        "ใจที่สงบคือกุญแจสู่ปัญญา",
        "โชคลาภอยู่รอบตัวคุณ",
        "คุณคือแม่เหล็กดึงดูดความสำเร็จ"
    ];

    const luckyNumber = (seed % 99) + 1;
    const luckyColor = colors[seed % colors.length];
    const mantra = mantras[seed % mantras.length];

    return { luckyNumber, luckyColor, mantra };
};

const DailyVibeCard: React.FC = () => {
    const { luckyNumber, luckyColor, mantra } = getDailyVibe(new Date());

    return (
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 to-black border border-white/10 shadow-2xl group">
            {/* Background Glow */}
            <div className={`absolute top-0 right-0 w-48 h-48 rounded-full bg-gradient-to-br from-${luckyColor.name === 'Gold' ? 'amber' : 'purple'}-500/20 to-transparent blur-3xl -mr-12 -mt-12 pointer-events-none`}></div>
            
            <div className="p-6 relative z-10">
                <div className="flex justify-between items-start mb-6">
                    <div className="flex items-center space-x-2">
                        <div className="p-2 bg-white/5 rounded-full backdrop-blur-sm border border-white/10">
                            <SparklesIcon className="w-4 h-4 text-amber-300" />
                        </div>
                        <span className="text-xs font-bold uppercase tracking-widest text-white/60">Daily Vibe</span>
                    </div>
                    <div className="text-right">
                         <p className="text-[10px] text-white/40 uppercase">Lucky No.</p>
                         <p className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-b from-white to-white/60 font-sans">{luckyNumber.toString().padStart(2, '0')}</p>
                    </div>
                </div>
                
                <div className="mb-6">
                    <p className="text-lg text-white font-medium leading-relaxed italic opacity-90">"{mantra}"</p>
                </div>
                
                <div className="flex items-center justify-between pt-4 border-t border-white/5">
                    <div className="flex items-center space-x-3">
                        <div 
                            className={`w-4 h-4 rounded-full ${luckyColor.glow} shadow-lg border border-white/20`} 
                            style={{ backgroundColor: luckyColor.hex }}
                        ></div>
                        <span className="text-sm font-semibold text-white/80">{luckyColor.name} Aura</span>
                    </div>
                    <span className="text-[10px] text-white/30">Tap to detail &rarr;</span>
                </div>
            </div>
            
            {/* Shimmer Overlay */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -skew-x-12 translate-x-[-200%] group-hover:animate-shimmer transition-all"></div>
        </div>
    );
};

const FeatureCard: React.FC<{
    title: string;
    subtitle: string;
    icon: React.ReactNode;
    onClick: () => void;
    color: string;
    className?: string;
    isNew?: boolean;
}> = ({ title, subtitle, icon, onClick, color, className, isNew }) => (
    <button 
        onClick={onClick}
        className={`relative overflow-hidden rounded-3xl p-5 text-left transition-all duration-300 hover:scale-[1.02] active:scale-95 border border-white/5 shadow-lg group flex flex-col justify-between ${className} ${color}`}
    >
        {isNew && (
            <div className="absolute top-3 right-3 bg-red-500 text-white text-[9px] font-bold px-2 py-0.5 rounded-full shadow-sm animate-pulse">
                NEW
            </div>
        )}
        
        <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-sm flex items-center justify-center mb-3 border border-white/10 group-hover:bg-white/20 transition-colors">
            {icon}
        </div>
        <div>
            <h3 className="text-base font-bold text-white mb-0.5">{title}</h3>
            <p className="text-[11px] text-white/60 font-medium">{subtitle}</p>
        </div>
        
        {/* Hover Glow */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
    </button>
);

const HomeScreen: React.FC<HomeScreenProps> = ({
  onStartReading, onStartWallpaper, onStartBirthChart, onStartSymbolAnalysis, onStartPalmReading, onStartKarmaClearing, onStartPersonalCounselor, userName, lastLogin, streak, isPremium, onUpgrade, onNavigate
}) => {
  const dailyPrompt = useMemo(() => {
    const today = new Date();
    return DAILY_ENGAGEMENT_PROMPTS[today.getDate() % DAILY_ENGAGEMENT_PROMPTS.length];
  }, []);

  return (
    <div className="space-y-8 pb-28">
      {/* --- Header Section --- */}
      <header className="flex justify-between items-start animate-slide-up" style={{ animationDelay: '0ms' }}>
        <div>
             <div className="flex items-center space-x-2 mb-1 opacity-70">
                <CalendarIcon className="w-3 h-3 text-amber-300" />
                <span className="text-[10px] font-bold tracking-widest uppercase text-amber-100">
                    {new Date().toLocaleDateString('th-TH', { weekday: 'long', day: 'numeric', month: 'short' })}
                </span>
            </div>
            <h1 className="text-3xl font-bold text-white leading-tight drop-shadow-md">
                สวัสดี, <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-300 to-pink-300">
                    {userName}
                </span>
            </h1>
        </div>
        
        <div 
            onClick={() => onNavigate(Screen.Profile)}
            className="relative group cursor-pointer"
        >
            {/* Avatar Glow */}
            <div className="absolute -inset-1 bg-gradient-to-r from-amber-300 to-purple-600 rounded-full blur opacity-40 group-hover:opacity-70 transition duration-500"></div>
            <div className="relative w-12 h-12 rounded-full bg-slate-900 border border-white/20 flex items-center justify-center overflow-hidden">
                 <LogoIcon className="w-6 h-6 text-white" />
            </div>
            {/* Streak Badge */}
            <div className="absolute -bottom-2 -left-2 bg-slate-900 border border-amber-500/30 rounded-full px-2 py-0.5 flex items-center shadow-sm">
                <FlameIcon className="w-3 h-3 text-amber-500 mr-1" />
                <span className="text-[10px] font-bold text-white">{streak}</span>
            </div>
        </div>
      </header>

      {/* --- Engagement Banner --- */}
      <div className="animate-slide-up" style={{ animationDelay: '100ms' }}>
         <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-3 flex items-center space-x-3 shadow-sm">
            <div className="p-2 bg-purple-500/20 rounded-full animate-pulse-slow">
                <SparklesIcon className="w-4 h-4 text-purple-300" />
            </div>
            <p className="text-xs text-white/90 font-medium flex-1">
                {dailyPrompt}
            </p>
         </div>
      </div>

      {/* --- Hero Section: Daily Vibe --- */}
      <div className="animate-slide-up cursor-pointer" style={{ animationDelay: '200ms' }} onClick={() => onStartReading('ไพ่ประจำวัน')}>
        <DailyVibeCard />
      </div>

      {/* --- Services Grid (Bento Box Layout) --- */}
      <div className="space-y-4 animate-slide-up" style={{ animationDelay: '300ms' }}>
        <h2 className="text-lg font-bold text-white/90 flex items-center">
            <span className="w-1.5 h-5 bg-amber-500 rounded-full mr-2.5"></span>
            Explore Universe
        </h2>
        
        <div className="grid grid-cols-2 gap-3">
            {/* Hero Feature: AI Art (Spans 2 columns) */}
            <FeatureCard 
                title="AI จิตรกรสายมู" 
                subtitle="สร้างวอลเปเปอร์ & ปรึกษาดวง" 
                icon={<PaintBrushIcon className="w-6 h-6 text-white" />}
                onClick={onStartPersonalCounselor}
                color="col-span-2 bg-gradient-to-r from-indigo-900/80 to-purple-900/80 border-indigo-500/30"
                className="min-h-[120px] items-start"
                isNew
            />

            <FeatureCard 
                title="ดูไพ่ทาโรต์" 
                subtitle="เช็คดวงรายวัน" 
                icon={<StarIcon className="w-6 h-6 text-amber-200" />}
                onClick={() => onStartReading('ไพ่ประจำวัน')}
                color="bg-slate-800/40 backdrop-blur-sm"
            />
            
            <FeatureCard 
                title="ดูลายมือ AI" 
                subtitle="สแกนเส้นชะตา" 
                icon={<PalmIcon className="w-6 h-6 text-rose-300" />}
                onClick={onStartPalmReading}
                color="bg-slate-800/40 backdrop-blur-sm"
            />

            <FeatureCard 
                title="วิเคราะห์สัญลักษณ์" 
                subtitle="แปลความหมาย" 
                icon={<SymbolAnalysisIcon className="w-6 h-6 text-cyan-300" />}
                onClick={onStartSymbolAnalysis}
                color="bg-slate-800/40 backdrop-blur-sm"
            />

            <FeatureCard 
                title="ผูกดวงชะตา" 
                subtitle="จีน / ไทย" 
                icon={<BirthChartIcon className="w-6 h-6 text-emerald-300" />}
                onClick={onStartBirthChart}
                color="bg-slate-800/40 backdrop-blur-sm"
            />
            
            <FeatureCard 
                title="วอลเปเปอร์" 
                subtitle="คำนวณปีเกิด" 
                icon={<BirthChartIcon className="w-6 h-6 text-pink-300" />}
                onClick={onStartWallpaper}
                color="bg-slate-800/40 backdrop-blur-sm"
            />
            
            <FeatureCard 
                title="แก้กรรม" 
                subtitle="พิธีปล่อยวาง" 
                icon={<LotusIcon className="w-6 h-6 text-teal-300" />}
                onClick={onStartKarmaClearing}
                color="bg-slate-800/40 backdrop-blur-sm"
            />
        </div>
      </div>
      
      {/* --- Merit / Support Banner --- */}
      <div className="animate-slide-up" style={{ animationDelay: '400ms' }}>
          <div 
            onClick={() => onNavigate(Screen.Charity)}
            className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-amber-900/40 to-orange-900/40 border border-amber-500/20 p-4 flex items-center justify-between cursor-pointer group"
          >
              <div className="flex items-center space-x-3 z-10">
                  <div className="p-2 bg-amber-500/20 rounded-full">
                      <LotusIcon className="w-5 h-5 text-amber-400" />
                  </div>
                  <div>
                      <h3 className="text-sm font-bold text-amber-100">สะสมเสบียงบุญ</h3>
                      <p className="text-[10px] text-amber-200/70">ร่วมสร้างสรรค์สิ่งดีๆ ให้ชุมชน</p>
                  </div>
              </div>
              <div className="z-10 bg-amber-500 text-black text-[10px] font-bold px-3 py-1 rounded-full shadow-lg group-hover:scale-105 transition-transform">
                  ร่วมบุญ 9.-
              </div>
              
              {/* Decorative Sparkles */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl -mr-10 -mt-10"></div>
          </div>
      </div>
    </div>
  );
};

export default HomeScreen;