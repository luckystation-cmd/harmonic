import React, { useState, useEffect, useMemo, useRef } from 'react';
import { MANTRAS } from '../constants';
import { SoundOnIcon, SoundOffIcon } from './icons';

interface MindFocusScreenProps {
  onComplete: () => void;
  isSoundEnabled: boolean;
  onToggleSound: () => void;
}

const MindFocusScreen: React.FC<MindFocusScreenProps> = ({ onComplete, isSoundEnabled, onToggleSound }) => {
  const initialTime = 30; // Timer set to 30 seconds
  const [timer, setTimer] = useState(initialTime);
  const audioRef = useRef<HTMLAudioElement>(null);
  
  const mantra = useMemo(() => MANTRAS[Math.floor(Math.random() * MANTRAS.length)], []);

  useEffect(() => {
    const interval = setInterval(() => {
        setTimer(prev => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    
    // Cleanup function
    return () => {
        clearInterval(interval);
    };
  }, []); // Run only once on mount
  
  useEffect(() => {
    if (audioRef.current) {
        if (isSoundEnabled) {
            audioRef.current.play().catch(error => console.log("Audio play failed: ", error));
        } else {
            audioRef.current.pause();
        }
    }
  }, [isSoundEnabled]);

  const isComplete = timer === 0;

  const handleStartPrediction = () => {
    if (audioRef.current) {
      audioRef.current.pause();
    }
    onComplete();
  };

  const handleSkip = () => {
    if (audioRef.current) {
      audioRef.current.pause();
    }
    onComplete();
  }


  return (
    <div className="fixed inset-0 bg-white/90 backdrop-blur-md flex flex-col items-center justify-center p-4 text-center animate-fade-in overflow-hidden z-50">
      <audio ref={audioRef} src="https://cdn.pixabay.com/audio/2022/10/18/audio_b25906a1d4.mp3" loop />

      <button onClick={onToggleSound} className="absolute top-6 right-6 z-20 p-2 text-purple-600 bg-purple-100 rounded-full shadow-sm">
        {isSoundEnabled ? <SoundOnIcon className="w-6 h-6" /> : <SoundOffIcon className="w-6 h-6" />}
      </button>

      {/* Pulsing circles animation */}
      <div className="relative flex items-center justify-center w-80 h-80 mb-8">
        <div className="absolute w-full h-full rounded-full bg-purple-200/30 animate-ripple-1"></div>
        <div className="absolute w-full h-full rounded-full bg-purple-200/30 animate-ripple-2"></div>
        <div className="absolute w-full h-full rounded-full bg-purple-200/30 animate-ripple-3"></div>
        
        {/* Central timer display */}
        <div className="relative w-48 h-48 flex items-center justify-center bg-white rounded-full border-4 border-purple-100 shadow-xl">
          <span className="text-6xl font-bold text-purple-600 tabular-nums">
             {Math.floor(timer / 60)}:{(timer % 60).toString().padStart(2, '0')}
          </span>
        </div>
      </div>

      <h3 className="text-lg font-bold text-purple-800 mb-2">ตั้งจิตให้สงบ...</h3>
      <p className="text-xl font-light text-slate-600 mt-2 max-w-sm z-10 leading-relaxed">
        "{mantra}"
      </p>

      <div className="mt-12 z-10">
        <button
          onClick={handleStartPrediction}
          disabled={!isComplete}
          className={`px-8 py-3 rounded-full font-bold text-lg transition-all duration-300 ${
            isComplete
              ? 'bg-purple-600 text-white shadow-lg shadow-purple-300 transform hover:scale-105'
              : 'bg-slate-200 text-slate-400 cursor-not-allowed'
          }`}
        >
          เริ่มทำนาย
        </button>
      </div>

       <div className="mt-6 z-10 text-center">
        <button
          onClick={handleSkip}
          className="text-slate-400 text-sm hover:text-purple-600 transition-colors"
        >
          ข้าม 30 วินาทีนี้
        </button>
        <p className="text-xs text-slate-400 mt-1">(การข้ามอาจส่งผลต่อสมาธิของคุณ)</p>
      </div>

       <style>{`
          @keyframes ripple {
            0% { transform: scale(0.6); opacity: 0; }
            50% { opacity: 0.5; }
            100% { transform: scale(1.2); opacity: 0; }
          }
          .animate-ripple-1 { animation: ripple 4s infinite; }
          .animate-ripple-2 { animation: ripple 4s infinite 1.33s; }
          .animate-ripple-3 { animation: ripple 4s infinite 2.66s; }
      `}</style>
    </div>
  );
};

export default MindFocusScreen;