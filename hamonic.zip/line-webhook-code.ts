
import { onRequest } from "firebase-functions/v2/https";
import * as line from "@line/bot-sdk";
import { GoogleGenAI } from "@google/genai";

// --- Configuration ---
const config = {
  channelAccessToken: process.env.LINE_CHANNEL_ACCESS_TOKEN || 'YOUR_LINE_ACCESS_TOKEN',
  channelSecret: process.env.LINE_CHANNEL_SECRET || 'YOUR_LINE_CHANNEL_SECRET',
};

// Update API Key with the new quota-fresh key
const GEMINI_API_KEY = process.env.API_KEY || 'AIzaSyChIl02zppWNrDlShc8RXsMWLq0eNBgn0A';

// --- Initialize Clients ---
const client = new line.Client(config);
const ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY });

// --- System Instruction (Shared DNA with App + Image Gen Capabilities) ---
const SYSTEM_INSTRUCTION = `
Context: You are 'Luckystation Harmonic AI' (กัลยาณมิตรดิจิทัล) on LINE OA.
Role:
1. **Modern Spiritual & Art Director:** Friendly, empathetic, and an expert in creating prompts for Thai sacred art.
2. **Image Generation Mode:** If the user asks for an image/wallpaper, output a JSON block.

**STRICT ART DIRECTION RULES (The "Real Mu" Style):**
- **Style:** Thai Contemporary Art mixed with Magical Realism.
- **Atmosphere:** Sacred, Mystical, Glowing, Ethereal, Divine, "Khlang" (Magic Power).
- **Lighting:** Cinematic lighting, volumetric fog, bioluminescent glows from yantras/jewelry.
- **Detail:** 8k resolution, Unreal Engine 5 render style, hyper-detailed ornamentation.
- **Sacred Seal:** ALL images must subtly include "Sak Yant" (Sacred Geometry) patterns.
- **NO TEXT:** The image must NOT contain any text, watermarks, letters, or signatures. Pure art only.

**CRITICAL VISUAL GUIDE: "NANG KWAK" (Beckoning Lady)**
If the user asks for "Nang Kwak", use this strategy to allow for unique "Luckystation" variations:
- **METAPHOR:** "A majestic Thai Goddess of Wealth."
- **POSE:** "Sitting politely (Thai style). Face looking forward."
- **🔴 RIGHT HAND (ACTION):**
    - **Option A (Classic):** "Right hand performing a gentle scooping motion (Maneki Neko style), fingers grouped together."
    - **Option B (Wealth Focus):** "**RIGHT HAND POINTING DOWNWARDS at the piles of gold/money on the floor.** Fingers extended towards the wealth."
- **✋ HAND SHAPE:** "**Fingers must be pointing DOWN.** Do NOT point up. Do NOT make rock/love signs."
- **🔵 LEFT HAND (PASSIVE):** "Left hand resting comfortably on the lap, holding a golden money bag."
- **NEGATIVE PROMPT:** "text, writing, watermark, pointing up, pointing at sky, rock sign, love sign, pinching, mudra, ok sign, palm up, showing palm, stop sign, two hands raised, symmetrical pose".

**CRITICAL VISUAL GUIDE: "PHAYA KRUT" (Garuda)**
If the user asks for "Garuda" or "Krut", use this description:
- **SUBJECT:** "The Mighty Garuda King (Phaya Krut), Divine Vehicle of Vishnu."
- **BODY:** "Anthropomorphic (Human-Bird Hybrid). Muscular red/burgundy torso with golden armor and Thai ornaments."
- **WINGS:** "Large, majestic, spread-out wings with intricate red and gold feathers, glowing with divine power."
- **EXPRESSION:** "Fierce, protective, commanding, eyes glowing with power."
- **ACTION:** "Standing or hovering in the sky, radiating immense authority and barami."

**CRITICAL VISUAL GUIDE: "NARAI SONG KRUT" (Vishnu Riding Garuda)**
If the user asks for "Narai Song Krut" or "Vishnu", use this description:
- **SUBJECT:** "Lord Vishnu (Phra Narai) riding on the shoulders of the Mighty Garuda King (Phaya Krut)."
- **COMPOSITION:** "Dynamic vertical composition. Vishnu sits majestically on Garuda's neck/shoulders. Garuda is in a flying/hovering pose."
- **VISHNU:** "4 arms holding divine weapons (Chakra, Conch, Mace, Lotus). Radiating golden divine aura. Wearing royal Thai celestial armor."
- **GARUDA:** "Spread wings, red and gold feathers, looking fierce and powerful. Claws clutching a Naga (Serpent) or standing on clouds."
- **SACRED ELEMENTS:** "**MUST INCLUDE GLOWING THAI YANTRA (Sak Yant)** symbols floating in the background sky or integrated into the aura. Mystical runes."
- **ATMOSPHERE:** "Epic, celestial war, divine power, storm clouds clearing for holy light."

Output Format for Images:
\`\`\`json
{
  "type": "lucky_wallpaper_generation",
  "selling_points": {
    "title_thai": "string",
    "meaning_thai": "string",
    "lucky_numbers": ["1", "9"]
  },
  "generation_prompts": {
    "midjourney_prompt": "Full English prompt using the visual guides above...",
    "negative_prompt": "text, writing, letters, signature, watermark, logo, brand, copyright, low quality, deformed, pointing up, rock sign, pinching, mudra, palm up, showing palm, stop sign, two hands dancing, left hand raised, splayed fingers",
    "aspect_ratio": "9:16"
  }
}
\`\`\`
`;

// --- Main Webhook Handler ---
// FIX: Explicitly type req and res as any to avoid TypeScript conflicts with global DOM types in shared environments.
export const lineWebhook = onRequest(async (req: any, res: any) => {
  if (req.method !== "POST") {
    res.status(405).send("Method Not Allowed");
    return;
  }

  const events = req.body.events;
  
  try {
    const results = await Promise.all(
      events.map(async (event: any) => await handleEvent(event))
    );
    res.status(200).json({ results });
  } catch (error) {
    console.error("Error handling events:", error);
    res.status(500).end();
  }
});

// --- Event Handler Logic ---
async function handleEvent(event: any) {
  if (event.type !== 'message' || event.message.type !== 'text') {
    return Promise.resolve(null);
  }

  const userId = event.source.userId;
  const userMessage = event.message.text;

  try {
    // 1. Context Injection
    let userProfileName = "กัลยาณมิตร";
    try {
      const profile = await client.getProfile(userId);
      userProfileName = profile.displayName;
    } catch (e) {
      console.log("Could not fetch profile, using default.");
    }

    // 2. Prepare Prompt
    const finalPrompt = `
User Context: Name "${userProfileName}"
User Query: "${userMessage}"
    `;

    // 3. Call Gemini
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        {
          role: "user",
          parts: [{ text: finalPrompt }]
        }
      ],
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
    });

    const replyText = response.text || "ขออภัยครับ ระบบกำลังรวบรวมสมาธิ กรุณาลองใหม่ในอีกสักครู่";

    // 4. Smart JSON Parsing for Image Generation Mode
    let jsonResponse = null;
    try {
        const cleanText = replyText.replace(/```json/g, '').replace(/```/g, '').trim();
        if (cleanText.startsWith('{')) {
            jsonResponse = JSON.parse(cleanText);
        }
    } catch (e) {
        // Not valid JSON, treat as normal text
    }

    // 5. Handle Structured Response (Image Gen)
    if (jsonResponse && jsonResponse.type === "lucky_wallpaper_generation") {
        const { selling_points, generation_prompts } = jsonResponse;
        
        // Console Log for debugging/production
        console.log(`[GENERATE IMAGE] User: ${userProfileName}`);
        console.log(`[PROMPT] ${generation_prompts.midjourney_prompt}`);

        // Reply with text first (In a real app, we would send the image here too if we had the URL)
        return client.replyMessage(event.replyToken, [
            { 
                type: 'text', 
                text: `🔮 ${selling_points.title_thai}\n\n${selling_points.meaning_thai}\n\nเลขมงคล: ${selling_points.lucky_numbers ? selling_points.lucky_numbers.join(', ') : '-'}` 
            },
            {
                type: 'text',
                text: `✨ ระบบกำลังส่งคำสั่งไปยังจักรวาลศิลปะเพื่อเนรมิตภาพ... (โปรดรอสักครู่ หรือกดสั่งใน Web App เพื่อเห็นภาพทันที)`
            }
        ]);
    }

    // 6. Normal Conversation
    return client.replyMessage(event.replyToken, {
      type: 'text',
      text: replyText,
    });

  } catch (error) {
    console.error(`Error processing message from ${userId}:`, error);
    return client.replyMessage(event.replyToken, {
      type: 'text',
      text: "ขออภัยครับ สัญญาณจักรวาลขัดข้องชั่วคราว โปรดลองใหม่ภายหลัง",
    });
  }
}
