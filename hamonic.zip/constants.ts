import { TarotCardData, Achievement, TransparencyPost } from './types';
import { FlameIcon, BrainIcon, HeartIcon, StarIcon, MoonIcon, SunIcon } from './components/icons';

export const MANTRAS: string[] = [
  "ข้าพเจ้าเปิดรับพลังงานแห่งจักรวาล เพื่อนำทางชีวิตไปสู่แสงสว่าง",
  "จิตใจของข้าพเจ้าสงบนิ่ง พร้อมรับฟังคำแนะนำจากไพ่ศักดิ์สิทธิ์",
  "ขอให้คำทำนายในวันนี้ เป็นดั่งเข็มทิศชี้ทางสู่ความสำเร็จและความสุข",
  "พลังแห่งสมาธิจะนำพาซึ่งความเข้าใจอย่างลึกซึ้ง",
  "ข้าพเจ้าเชื่อมั่นในสัญชาตญาณ และพร้อมรับมือกับทุกสิ่งที่เข้ามา"
];

export const MAJOR_ARCANA: TarotCardData[] = [
  { name: "The Fool", roman: "0", imageKey: "ar00" },
  { name: "The Magician", roman: "I", imageKey: "ar01" },
  { name: "The High Priestess", roman: "II", imageKey: "ar02" },
  { name: "The Empress", roman: "III", imageKey: "ar03" },
  { name: "The Emperor", roman: "IV", imageKey: "ar04" },
  { name: "The Hierophant", roman: "V", imageKey: "ar05" },
  { name: "The Lovers", roman: "VI", imageKey: "ar06" },
  { name: "The Chariot", roman: "VII", imageKey: "ar07" },
  { name: "Strength", roman: "VIII", imageKey: "ar08" },
  { name: "The Hermit", roman: "IX", imageKey: "ar09" },
  { name: "Wheel of Fortune", roman: "X", imageKey: "ar10" },
  { name: "Justice", roman: "XI", imageKey: "ar11" },
  { name: "The Hanged Man", roman: "XII", imageKey: "ar12" },
  { name: "Death", roman: "XIII", imageKey: "ar13" },
  { name: "Temperance", roman: "XIV", imageKey: "ar14" },
  { name: "The Devil", roman: "XV", imageKey: "ar15" },
  { name: "The Tower", roman: "XVI", imageKey: "ar16" },
  { name: "The Star", roman: "XVII", imageKey: "ar17" },
  { name: "The Moon", roman: "XVIII", imageKey: "ar18" },
  { name: "The Sun", roman: "XIX", imageKey: "ar19" },
  { name: "Judgement", roman: "XX", imageKey: "ar20" },
  { name: "The World", roman: "XXI", imageKey: "ar21" }
];

export const ACHIEVEMENTS: Achievement[] = [
  {
    id: 'STREAK_7',
    name: 'เปลวไฟเริ่มต้น',
    description: 'ดูไพ่ติดต่อกัน 7 วัน',
    icon: FlameIcon,
    isUnlocked: (state) => state.streak.count >= 7,
  },
  {
    id: 'STREAK_30',
    name: 'ผู้ฝึกตน',
    description: 'ดูไพ่ติดต่อกัน 30 วัน',
    icon: FlameIcon,
    isUnlocked: (state) => state.streak.count >= 30,
  },
  {
    id: 'MEDITATION_10',
    name: 'ปรมาจารย์สมาธิ',
    description: 'ทำสมาธิครบ 10 ครั้ง',
    icon: MoonIcon,
    isUnlocked: (state) => state.stats.meditations >= 10,
  },
   {
    id: 'MEDITATION_50',
    name: 'จิตนิ่งดั่งภูผา',
    description: 'ทำสมาธิครบ 50 ครั้ง',
    icon: MoonIcon,
    isUnlocked: (state) => state.stats.meditations >= 50,
  },
  {
    id: 'GIVER_1',
    name: 'ผู้ให้ครั้งแรก',
    description: 'ทำบุญออนไลน์ครั้งแรก',
    icon: HeartIcon,
    isUnlocked: (state) => state.stats.donations >= 1,
  },
  {
    id: 'GIVER_5',
    name: 'ผู้ให้ทางจิตวิญญาณ',
    description: 'ทำบุญออนไลน์ครบ 5 ครั้ง',
    icon: HeartIcon,
    isUnlocked: (state) => state.stats.donations >= 5,
  },
  {
    id: 'READER_1',
    name: 'นักอ่านไพ่มือใหม่',
    description: 'ดูไพ่ครั้งแรก',
    icon: StarIcon,
    isUnlocked: (state) => state.stats.readings >= 1,
  },
  {
    id: 'READER_50',
    name: 'จอมขมังเวทย์',
    description: 'ดูไพ่ครบ 50 ครั้ง',
    icon: StarIcon,
    isUnlocked: (state) => state.stats.readings >= 50,
  },
];

export const DAILY_ENGAGEMENT_PROMPTS: string[] = [
  "เติมพลังงานใจให้เต็ม 100% ก่อนเริ่มวันใหม่!",
  "มาสะสมแต้มบุญดวงดี (Daily Streak) กันวันนี้!",
  "เช็คดวงวันนี้... เพื่อวางแผนนำโชคให้เข้าทาง!",
  "อย่าให้ดวงนำคุณ... ให้จิตนำดวงคุณ!",
  "เช้านี้อย่าลืมตั้งสติ! มาเช็ค Vibe ประจำวันกัน!",
  "Unlock พลังงานดวงดี! มาเปิดไพ่ประจำวันกันค่ะ/ครับ",
  "ขาดไม่ได้! สร้างความกลมกลืน (Harmonic) ให้ชีวิตทุกเช้า",
  "แค่ 30 วิ! ใช้สมาธิรับคำแนะนำดีๆ จากไพ่ทาโรต์",
  "วันนี้มีอะไรให้มู... ที่จะช่วยคุณสำเร็จ? คลิกดูเลย!",
];

export const TOTAL_DONATED_AMOUNT = 12591; // Mock total

export const TRANSPARENCY_LOG_DATA: TransparencyPost[] = [
  {
    id: 'donation-002',
    date: 'กรกฎาคม 2567',
    title: 'โครงการอาหารกลางวันเด็ก',
    description: 'ร่วมสนับสนุนค่าอาหารกลางวันสำหรับน้องๆ ในพื้นที่ห่างไกล',
    amount: 5450,
    proofImageUrl: 'https://images.unsplash.com/photo-1593113598332-cd288d649433?q=80&w=800&auto=format&fit=crop',
  },
  {
    id: 'donation-001',
    date: 'มิถุนายน 2567',
    title: 'มูลนิธิโรงพยาบาลเด็ก',
    description: 'บริจาคสมทบทุนจัดซื้ออุปกรณ์การแพทย์สำหรับผู้ป่วยเด็ก',
    amount: 7141,
    proofImageUrl: 'https://images.unsplash.com/photo-1576091160550-2173dba9996a?q=80&w=800&auto=format&fit=crop',
  }
];