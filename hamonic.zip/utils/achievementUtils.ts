import { AppState } from '../types';
import { ACHIEVEMENTS } from '../constants';

export const checkAchievements = (state: AppState): string[] => {
  const unlockedAchievements = new Set(state.achievements);

  ACHIEVEMENTS.forEach(achievement => {
    if (!unlockedAchievements.has(achievement.id) && achievement.isUnlocked(state)) {
      unlockedAchievements.add(achievement.id);
    }
  });

  return Array.from(unlockedAchievements);
};
