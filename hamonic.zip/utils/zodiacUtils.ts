
export const getChineseZodiac = (gregorianYear: number): string => {
  const zodiacThai = [
    'ชวด', 'ฉลู', 'ขาล', 'เถาะ', 'มะโรง', 'มะเส็ง', 'มะเมีย', 'มะแม', 'วอก', 'ระกา', 'จอ', 'กุน'
  ];
  // Calculation is based on the Gregorian year (CE)
  const index = ((gregorianYear - 4) % 12 + 12) % 12;
  return zodiacThai[index];
};

export const getThaiZodiac = (day: number, month: number): string => {
  const signs = [
    { name: 'ราศีมังกร', start: { m: 1, d: 15 }, end: { m: 2, d: 12 } },
    { name: 'ราศีกุมภ์', start: { m: 2, d: 13 }, end: { m: 3, d: 14 } },
    { name: 'ราศีมีน', start: { m: 3, d: 15 }, end: { m: 4, d: 13 } },
    { name: 'ราศีเมษ', start: { m: 4, d: 14 }, end: { m: 5, d: 14 } },
    { name: 'ราศีพฤษภ', start: { m: 5, d: 15 }, end: { m: 6, d: 14 } },
    { name: 'ราศีเมถุน', start: { m: 6, d: 15 }, end: { m: 7, d: 16 } },
    { name: 'ราศีกรกฎ', start: { m: 7, d: 17 }, end: { m: 8, d: 16 } },
    { name: 'ราศีสิงห์', start: { m: 8, d: 17 }, end: { m: 9, d: 16 } },
    { name: 'ราศีกันย์', start: { m: 9, d: 17 }, end: { m: 10, d: 17 } },
    { name: 'ราศีตุลย์', start: { m: 10, d: 18 }, end: { m: 11, d: 16 } },
    { name: 'ราศีพิจิก', start: { m: 11, d: 17 }, end: { m: 12, d: 15 } },
    { name: 'ราศีธนู', start: { m: 12, d: 16 }, end: { m: 1, d: 14 } }
  ];

  for (const sign of signs) {
    // Handle signs that cross the year boundary (Sagittarius, Capricorn)
    if (sign.start.m > sign.end.m) {
      if ((month === sign.start.m && day >= sign.start.d) || (month === sign.end.m && day <= sign.end.d)) {
        return sign.name;
      }
    } else {
      if ((month === sign.start.m && day >= sign.start.d) || (month === sign.end.m && day <= sign.end.d) || (month > sign.start.m && month < sign.end.m)) {
        return sign.name;
      }
    }
  }

  return 'ไม่สามารถระบุราศีได้';
};
