
import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, (process as any).cwd(), '');
  return {
    plugins: [react()],
    server: {
      host: true
    },
    build: {
      outDir: 'dist',
      sourcemap: true
    },
    define: {
      // This is critical to make process.env.API_KEY work in the browser for Vercel
      // Added user provided key as fallback
      'process.env.API_KEY': JSON.stringify(env.API_KEY || "AIzaSyBqmpJk0IYy-8Pb-We0wJ8Xym64giw7Fs4")
    }
  }
})