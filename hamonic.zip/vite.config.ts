
import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, (process as any).cwd(), '');
  return {
    plugins: [react()],
    server: {
      host: true
    },
    build: {
      outDir: 'dist',
      sourcemap: true
    },
    define: {
      // Critical for Vercel: Maps process.env.API_KEY so the app can use it.
      // The fallback key allows it to work immediately without config, but it's better to set it in Vercel settings.
      'process.env.API_KEY': JSON.stringify(env.API_KEY || "AIzaSyBqmpJk0IYy-8Pb-We0wJ8Xym64giw7Fs4")
    }
  }
})