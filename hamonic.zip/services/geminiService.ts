
import { GoogleGenAI, Type, Schema } from "@google/genai";
import { TarotReading, BirthChartReading, SymbolAnalysisReading, PalmReadingAnalysis, KarmaClearingBlessing, LotteryPrediction, ChatMessage, UserProfile, KarmaRitualType } from '../types';

// Safety check for API Key to prevent white screen crash
const API_KEY = process.env.API_KEY;
if (!API_KEY) {
  console.warn("Gemini API Key is missing! Check Vercel Environment Variables.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY || 'DUMMY_KEY_FOR_BUILD' });
const MODEL_NAME = "gemini-2.5-flash";

// --- Shared System Instructions ---
const THAI_ASTROLOGER_INSTRUCTION = "You are an expert Thai Astrologer and Spiritual Guide. You MUST PROVIDE ALL ANSWERS IN THAI LANGUAGE (ภาษาไทย) ONLY. Do not use English under any circumstances. Use formal, mystical, and encouraging Thai vocabulary. Address the user by their name if provided to make the reading highly personal and empowering.";

const PALM_READER_INSTRUCTION = "You are a Grandmaster of Palmistry (Hantology). You analyze hand images with high precision. You MUST PROVIDE ALL ANSWERS IN THAI LANGUAGE (ภาษาไทย) ONLY.";

const SYMBOL_ANALYST_INSTRUCTION = "You are a Spiritual Symbol Analyst and Digital Image Forensics Expert. You interpret lucky signs and detect AI-generated images. You MUST PROVIDE ALL ANSWERS IN THAI LANGUAGE (ภาษาไทย) ONLY.";

// --- System Instructions for Art Director & Counselor ---
const COUNSELOR_SYSTEM_INSTRUCTION = `
Context: You are 'Luckystation Harmonic AI', a spiritual companion and expert Art Director for Thai Amulets.
Role:
1. **Spiritual Guide:** Offer advice based on Thai astrology, Tarot, and positive psychology. Be warm, empathetic, and empowering. **ALWAYS SPEAK IN THAI LANGUAGE.**
2. **AI Art Director:** When the user asks for an image/wallpaper, you MUST GENERATE A JSON response containing a highly detailed English prompt.

**STRICT ART DIRECTION RULES (The "Real Mu" Style):**
- **Style:** Thai Contemporary Art mixed with Magical Realism.
- **Atmosphere:** Sacred, Mystical, Glowing, Ethereal, Divine, "Khlang" (Magic Power).
- **Lighting:** Cinematic lighting, volumetric fog, bioluminescent glows from yantras/jewelry.
- **Detail:** 8k resolution, Unreal Engine 5 render style, hyper-detailed ornamentation.
- **Sacred Seal:** ALL images must subtly include "Sak Yant" (Sacred Geometry) patterns.

**CRITICAL VISUAL GUIDE: "NANG KWAK" (Beckoning Lady)**
If the user asks for "Nang Kwak", use this strategy:
- **METAPHOR:** "A majestic Thai Goddess of Wealth."
- **POSE:** "**ASYMMETRICAL.** Sitting sideways or politely."
- **🔴 RIGHT HAND (ACTION):**
    - **Option A (Scooping):** "Right hand performing a gentle scooping motion (Maneki Neko style), fingers grouped together."
    - **Option B (Pointing):** "**RIGHT HAND POINTING DOWNWARDS at the piles of gold.** Fingers extended towards the wealth."
- **👇 FINGER DIRECTION:** "Fingertips pointing **DOWN** towards the floor. **PALM HIDDEN/FACING FLOOR**."
- **🔵 LEFT HAND (PASSIVE):** "Left hand resting on the lap, holding a golden money bag."
- **NEGATIVE PROMPT:** "rock sign, love sign, pinching, mudra, ok sign, palm up, showing palm, stop sign, two hands raised, symmetrical pose".

**CRITICAL VISUAL GUIDE: "PHAYA KRUT" (Garuda)**
If the user asks for "Garuda" or "Krut", use this description:
- **SUBJECT:** "The Mighty Garuda King (Phaya Krut), Divine Vehicle of Vishnu."
- **BODY:** "Anthropomorphic (Human-Bird Hybrid). Muscular red/burgundy torso with golden armor and Thai ornaments."
- **WINGS:** "Large, majestic, spread-out wings with intricate red and gold feathers, glowing with divine power."
- **EXPRESSION:** "Fierce, protective, commanding, eyes glowing with power."
- **ACTION:** "Standing or hovering in the sky, radiating immense authority and barami."

**CRITICAL VISUAL GUIDE: "NARAI SONG KRUT" (Vishnu Riding Garuda)**
If the user asks for "Narai Song Krut" or "Vishnu", use this description:
- **SUBJECT:** "Lord Vishnu (Phra Narai) riding on the shoulders of the Mighty Garuda King (Phaya Krut)."
- **COMPOSITION:** "Dynamic vertical composition. Vishnu sits majestically on Garuda's neck/shoulders. Garuda is in a flying/hovering pose."
- **VISHNU:** "4 arms holding divine weapons (Chakra, Conch, Mace, Lotus). Radiating golden divine aura. Wearing royal Thai celestial armor."
- **GARUDA:** "Spread wings, red and gold feathers, looking fierce and powerful. Claws clutching a Naga (Serpent) or standing on clouds."
- **SACRED ELEMENTS:** "**MUST INCLUDE GLOWING THAI YANTRA (Sak Yant)** symbols floating in the background sky or integrated into the aura. Mystical runes."
- **ATMOSPHERE:** "Epic, celestial war, divine power, storm clouds clearing for holy light."

**Response Format:**
- If chatting: Respond normally in Thai text.
- If requested an image: Respond ONLY with this JSON block:
\`\`\`json
{
  "type": "lucky_wallpaper_generation",
  "selling_points": {
    "title_thai": "Title of the image (Thai)",
    "meaning_thai": "Spiritual meaning (Thai)",
    "lucky_numbers": ["1", "9"]
  },
  "generation_prompts": {
    "midjourney_prompt": "Full English prompt using the visual guides above...",
    "negative_prompt": "text, writing, letters, signature, watermark, logo, brand, copyright, low quality, ugly, deformed, extra fingers, bad anatomy",
    "aspect_ratio": "9:16"
  }
}
\`\`\`
`;

export const getTarotReading = async (cardNames: string[], category: string, userName?: string): Promise<TarotReading> => {
  const userContext = userName 
    ? `Owner of Destiny Name (เจ้าของชะตา): "${userName}". **IMPORTANT:** You must address the user as "คุณ${userName}" throughout the reading to make it deeply personal and respectful.` 
    : "User: Anonymous.";
    
  const response = await ai.models.generateContent({
    model: MODEL_NAME,
    contents: `Interpret this tarot reading. Category: ${category}. Cards: ${cardNames.join(', ')}. ${userContext}. Provide spread type, interpretation for each card (position, thai name, interpretation), overall summary, lucky action, and a daily quest (short spiritual task).`,
    config: {
      systemInstruction: THAI_ASTROLOGER_INSTRUCTION, // Force Thai Language
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          spread_type: { type: Type.STRING },
          cards: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                position: { type: Type.STRING },
                card_name_thai: { type: Type.STRING },
                interpretation: { type: Type.STRING },
              },
              required: ["position", "card_name_thai", "interpretation"],
            },
          },
          overall_summary: { type: Type.STRING },
          lucky_action: { type: Type.STRING },
          daily_quest: { type: Type.STRING },
        },
        required: ["spread_type", "cards", "overall_summary", "lucky_action", "daily_quest"],
      },
    },
  });
  return JSON.parse(response.text!) as TarotReading;
};

export const getPersonalAdvice = async (history: ChatMessage[], userProfile: UserProfile | null): Promise<string> => {
  const userContext = userProfile ? `User: ${userProfile.firstName}, DOB: ${userProfile.dob?.day}/${userProfile.dob?.month}/${userProfile.dob?.year}` : "User: Anonymous";
  
  const contents = [
      { role: 'user', parts: [{ text: `Context: ${userContext}` }] },
      ...history
  ];

  const response = await ai.models.generateContent({
    model: MODEL_NAME,
    contents: contents,
    config: {
        systemInstruction: COUNSELOR_SYSTEM_INSTRUCTION,
        temperature: 0.7,
    }
  });
  return response.text || "ขออภัย ไม่สามารถให้คำแนะนำได้ในขณะนี้";
};

export const generateImageFromPrompt = async (prompt: string): Promise<string> => {
    try {
        // EXCLUSIVE: Google Imagen 4.0 (Ultra Quality)
        // Using 'imagen-4.0-generate-001' for the highest possible detail and Thai aesthetics.
        // Requires a robust API key.
        
        console.log("Generating with Imagen 4.0...");
        
        const response = await ai.models.generateImages({
            model: 'imagen-4.0-generate-001',
            prompt: prompt,
            config: {
                numberOfImages: 1,
                aspectRatio: '9:16',
                outputMimeType: 'image/jpeg'
            }
        });

        // Imagen response structure extraction
        const imageBytes = response.generatedImages?.[0]?.image?.imageBytes;
        
        if (imageBytes) {
            return imageBytes;
        }
        
        throw new Error("No image generated from Imagen 4.0");

    } catch (e) {
        console.error("Imagen 4.0 generation failed", e);
        throw e; 
    }
}

export const generateWallpaperImage = async (year: number): Promise<string> => {
  const prompt = `A mystical, divine wallpaper for someone born in ${year}. Thai art style, golden glowing aura, sacred geometry, high quality, 4k. No text, no letters, no watermarks, no signatures. Pure art.`;
  return generateImageFromPrompt(prompt);
};

export const getBirthChartAnalysis = async (year: number, day: number | undefined, month: number | undefined, type: 'chinese' | 'thai'): Promise<BirthChartReading> => {
  const prompt = `Analyze birth chart for year ${year}, month ${month}, day ${day}. Type: ${type}. 
  Provide title, personality, strength, weakness, guidance, future age forecast (target age, prediction, caution), and lucky wallpaper recommendation (title, reason).`;
  
  const response = await ai.models.generateContent({
    model: MODEL_NAME,
    contents: prompt,
    config: {
      systemInstruction: THAI_ASTROLOGER_INSTRUCTION, // Force Thai Language
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          personality: { type: Type.STRING },
          strength: { type: Type.STRING },
          weakness: { type: Type.STRING },
          guidance: { type: Type.STRING },
          future_age_forecast: {
            type: Type.OBJECT,
            properties: {
                target_age: { type: Type.INTEGER },
                prediction: { type: Type.STRING },
                caution: { type: Type.STRING },
            },
            required: ["target_age", "prediction", "caution"]
          },
          lucky_wallpaper_recommendation: {
            type: Type.OBJECT,
            properties: {
                title: { type: Type.STRING },
                reason: { type: Type.STRING },
            },
            required: ["title", "reason"]
          }
        },
        required: ["title", "personality", "strength", "weakness", "guidance", "future_age_forecast", "lucky_wallpaper_recommendation"],
      },
    },
  });
  return JSON.parse(response.text!) as BirthChartReading;
};

export const getSymbolAnalysis = async (base64Data: string, mimeType: string): Promise<SymbolAnalysisReading> => {
  const prompt = "Analyze this image. 1. Identify spiritual/lucky symbol. 2. Provide spiritual insight. 3. Provide lucky numbers. 4. Perform DIGITAL FORENSICS to detect if this is AI-generated or a real photo.";
  
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash", 
    contents: {
        parts: [
            { inlineData: { mimeType, data: base64Data } },
            { text: prompt }
        ]
    },
    config: {
      systemInstruction: SYMBOL_ANALYST_INSTRUCTION, // Force Thai Language
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          symbol_identified: { type: Type.STRING },
          spiritual_insight: {
            type: Type.OBJECT,
            properties: {
                title_th: { type: Type.STRING },
                guidance_th: { type: Type.STRING },
            },
            required: ["title_th", "guidance_th"]
          },
          luck_insight: {
             type: Type.OBJECT,
             properties: {
                 title_th: { type: Type.STRING },
                 primary_numbers: { type: Type.ARRAY, items: { type: Type.STRING } },
                 justification_th: { type: Type.STRING },
             },
             required: ["title_th", "primary_numbers", "justification_th"]
          },
          digital_origin_analysis: {
              type: Type.OBJECT,
              properties: {
                  is_ai_generated: { type: Type.BOOLEAN },
                  ai_probability_score: { type: Type.NUMBER },
                  artifacts_found: { type: Type.ARRAY, items: { type: Type.STRING } },
                  verdict: { type: Type.STRING },
              },
              required: ["is_ai_generated", "ai_probability_score", "artifacts_found", "verdict"]
          }
        },
        required: ["symbol_identified", "spiritual_insight", "luck_insight", "digital_origin_analysis"],
      },
    },
  });
  return JSON.parse(response.text!) as SymbolAnalysisReading;
};

export const getPalmReadingAnalysis = async (base64Data: string, mimeType: string): Promise<PalmReadingAnalysis> => {
  const prompt = "Analyze this palm image deeply. Look for Major Lines (Life, Head, Heart, Fate), Mounts (Venus, Jupiter, etc), and Special Marks (Crosses, Stars). Provide predictions and warnings.";
  
  const lineSchema = {
    type: Type.OBJECT,
    properties: {
        description: { type: Type.STRING },
        prediction: { type: Type.STRING },
        age_timing: { type: Type.STRING },
    },
    required: ["description", "prediction"]
  } as const;

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: {
        parts: [
            { inlineData: { mimeType, data: base64Data } },
            { text: prompt }
        ]
    },
    config: {
      systemInstruction: PALM_READER_INSTRUCTION, // Force Thai Language
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          hand_analysis: {
            type: Type.OBJECT,
            properties: {
                life_line: lineSchema,
                head_line: lineSchema,
                heart_line: lineSchema,
                fate_line: lineSchema,
                dominant_mounts: {
                    type: Type.OBJECT,
                    properties: {
                        mount_name: { type: Type.STRING },
                        meaning: { type: Type.STRING },
                    },
                    required: ["mount_name", "meaning"]
                }
            },
            required: ["life_line", "head_line", "heart_line", "fate_line"]
          },
          special_signs: { type: Type.ARRAY, items: { type: Type.STRING } },
          cautions: {
              type: Type.OBJECT,
              properties: {
                  health: { type: Type.STRING },
                  finance: { type: Type.STRING },
                  love: { type: Type.STRING },
              },
              required: ["health", "finance", "love"]
          },
          final_verdict: { type: Type.STRING },
        },
        required: ["hand_analysis", "special_signs", "cautions", "final_verdict"],
      },
    },
  });
  return JSON.parse(response.text!) as PalmReadingAnalysis;
};

export const getKarmaClearingBlessing = async (intention: string, ritualType: KarmaRitualType): Promise<KarmaClearingBlessing> => {
  const prompt = `User performed karma clearing ritual '${ritualType}' with intention: '${intention}'. Provide a blessing and guidance.`;
  const response = await ai.models.generateContent({
    model: MODEL_NAME,
    contents: prompt,
    config: {
        systemInstruction: THAI_ASTROLOGER_INSTRUCTION, // Force Thai Language
        responseMimeType: "application/json",
        responseSchema: {
            type: Type.OBJECT,
            properties: {
                blessing: { type: Type.STRING },
                guidance: { type: Type.STRING },
            },
            required: ["blessing", "guidance"]
        }
    }
  });
  return JSON.parse(response.text!) as KarmaClearingBlessing;
};

export const getLotteryPrediction = async (dob: UserProfile['dob']): Promise<LotteryPrediction> => {
    const dobStr = dob ? `${dob.day}/${dob.month}/${dob.year}` : "Unknown";
    const prompt = `Generate lottery prediction based on DOB: ${dobStr}. 2 digit numbers, 3 digit numbers, and reasoning.`;
    const response = await ai.models.generateContent({
        model: MODEL_NAME,
        contents: prompt,
        config: {
            systemInstruction: THAI_ASTROLOGER_INSTRUCTION, // Force Thai Language
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    numbers_2_digit: { type: Type.ARRAY, items: { type: Type.STRING } },
                    numbers_3_digit: { type: Type.ARRAY, items: { type: Type.STRING } },
                    reasoning: { type: Type.STRING },
                },
                required: ["numbers_2_digit", "numbers_3_digit", "reasoning"]
            }
        }
    });
    return JSON.parse(response.text!) as LotteryPrediction;
};
