
import { AppState } from '../types';

// Audio Assets - REMASTERED (Using reliable, permanent sources)
const SOUND_ASSETS = {
  // BGM: Deep Space Ambience (Stable Internet Archive Link) - 432Hz Feel
  bgm: 'https://ia800304.us.archive.org/29/items/Meditation_432Hz/Meditation_432Hz.mp3', 
  // UI Tap: Soft Pop / Bubble (Google Actions Library - Fast & Reliable)
  tap: 'https://actions.google.com/sounds/v1/water/air_woosh_underwater.ogg',
  // Magic/Success: Magic Chime (Google Actions Library)
  success: 'https://actions.google.com/sounds/v1/cartoon/magic_chime.ogg',
  // Swoosh: Soft wind (Google Actions Library)
  swoosh: 'https://actions.google.com/sounds/v1/foley/whoosh_fast.ogg',
  // Flip: Page Turn / Card Flip (Google Actions Library)
  flip: 'https://actions.google.com/sounds/v1/office/page_turn.ogg', 
};

class SoundService {
  private bgmAudio: HTMLAudioElement | null = null;
  private sfxAudioMap: Map<string, HTMLAudioElement> = new Map();
  private isMuted: boolean = false;
  private fadeInterval: any = null;
  private targetVolume: number = 0.15; // Low volume for BGM

  constructor() {
    // Preload SFX immediately
    if (typeof window !== 'undefined') {
      Object.entries(SOUND_ASSETS).forEach(([key, url]) => {
        if (key !== 'bgm') {
          const audio = new Audio(url);
          audio.crossOrigin = "anonymous"; // Fix CORS issues
          audio.volume = 0.5; // Standard SFX Volume
          // Preload to ensure instant playback
          audio.load(); 
          this.sfxAudioMap.set(key, audio);
        }
      });
    }
  }

  public initializeBGM() {
    if (this.bgmAudio) return;
    if (typeof window !== 'undefined') {
      this.bgmAudio = new Audio(SOUND_ASSETS.bgm);
      this.bgmAudio.crossOrigin = "anonymous";
      this.bgmAudio.loop = true;
      this.bgmAudio.volume = 0; // Start at 0 for fade-in
      this.bgmAudio.load();
    }
  }

  public async startBGM() {
    if (!this.bgmAudio) this.initializeBGM();
    if (this.bgmAudio && !this.isMuted) {
      try {
        // Only play if paused to prevent errors
        if (this.bgmAudio.paused) {
            this.bgmAudio.volume = 0;
            const playPromise = this.bgmAudio.play();
            
            if (playPromise !== undefined) {
                playPromise.then(() => {
                    // Playback started successfully
                    this.fadeInBGM();
                }).catch(error => {
                    // Auto-play was prevented
                    console.warn("BGM Autoplay prevented by browser. Waiting for interaction.", error);
                });
            }
        }
      } catch (e) {
        console.warn("Audio play error", e);
      }
    }
  }

  private fadeInBGM() {
      if (!this.bgmAudio) return;
      if (this.fadeInterval) clearInterval(this.fadeInterval);
      
      this.fadeInterval = setInterval(() => {
          if (!this.bgmAudio) return;
          if (this.bgmAudio.volume < this.targetVolume) {
              // Smooth fade in
              this.bgmAudio.volume = Math.min(this.bgmAudio.volume + 0.005, this.targetVolume);
          } else {
              clearInterval(this.fadeInterval);
          }
      }, 100); 
  }

  public stopBGM() {
    if (this.bgmAudio) {
      this.bgmAudio.pause();
      // We don't reset currentTime to 0 so it resumes nicely if unmuted
    }
  }

  public setMute(muted: boolean) {
    this.isMuted = muted;
    if (muted) {
      this.stopBGM();
    } else {
      this.startBGM();
    }
  }

  public playSFX(type: 'tap' | 'success' | 'swoosh' | 'flip') {
    if (this.isMuted) return;
    
    // Map specific interaction types to sound assets
    let key = type;
    // You can map multiple types to the same sound key here if needed
    
    const originalAudio = this.sfxAudioMap.get(key);
    
    if (originalAudio) {
      // Clone node is essential for rapidfire sounds (e.g. typing or fast clicking)
      // otherwise the sound cuts itself off
      const clone = originalAudio.cloneNode() as HTMLAudioElement;
      
      // Adjust volume per type if needed
      if (type === 'tap') clone.volume = 0.3; // Softer tap
      if (type === 'success') clone.volume = 0.6; // Louder success
      
      clone.play().catch((e) => console.debug("SFX play failed", e));
    }
  }

  /**
   * Haptic Feedback Trigger
   * Works primarily on Android Chrome. iOS Safari ignores this.
   */
  public triggerHaptic(type: 'light' | 'medium' | 'heavy' | 'success' | 'error') {
    if (typeof navigator === 'undefined' || !navigator.vibrate) return;

    try {
        switch (type) {
        case 'light':
            navigator.vibrate(10); // Crisp tick
            break;
        case 'medium':
            navigator.vibrate(20);
            break;
        case 'heavy':
            navigator.vibrate(40);
            break;
        case 'success':
            navigator.vibrate([50, 50, 50]); // Da-da-da
            break;
        case 'error':
            navigator.vibrate([30, 30, 30, 30, 30]); // Buzz-buzz
            break;
        }
    } catch (e) {
        // Ignore haptic errors
    }
  }

  /**
   * Combined interaction: Sound + Haptic
   */
  public playInteraction(type: 'tap' | 'success' | 'swoosh' | 'flip') {
    this.playSFX(type);
    
    // Map sound types to haptic types
    if (type === 'tap' || type === 'flip') this.triggerHaptic('light');
    if (type === 'swoosh') this.triggerHaptic('light');
    if (type === 'success') this.triggerHaptic('success');
  }
}

export const soundService = new SoundService();
