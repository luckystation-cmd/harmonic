
import { AppState } from '../types';

export const STORAGE_KEY = 'luckystationHarmonicState';

export const getInitialState = (): AppState => ({
  userProfile: null,
  isPremium: false,
  readings: [],
  streak: {
    count: 0,
    lastReadingDate: null,
  },
  achievements: [],
  stats: {
    readings: 0,
    meditations: 0,
    donations: 0,
    meritPoints: 0,
  },
  votedToday: null,
  donatedToday: null,
  isSoundEnabled: true,
  lastLogin: null,
  counselorChatHistory: [],
  dailyImageCount: 0,
  lastImageGenDate: null,
});


export const saveState = (state: AppState) => {
  try {
    const serializedState = JSON.stringify(state);
    localStorage.setItem(STORAGE_KEY, serializedState);
  } catch (error) {
    console.error("Could not save state", error);
  }
};

export const loadState = (): AppState => {
  try {
    const serializedState = localStorage.getItem(STORAGE_KEY);
    if (serializedState === null) {
      return getInitialState();
    }
    const storedState = JSON.parse(serializedState);
    // Merge with initial state to ensure all keys are present
    const state = { ...getInitialState(), ...storedState };
    
    // Ensure nested stats object has meritPoints if loading old state
    if (state.stats && typeof state.stats.meritPoints === 'undefined') {
        state.stats.meritPoints = 0;
    }

    const today = new Date().toDateString();

    // If user is logged in, update lastLogin timestamp to now
    if (state.userProfile) {
        state.lastLogin = new Date().toISOString();
    }

    // Reset Daily Image Quota if it's a new day
    if (state.lastImageGenDate !== today) {
        state.dailyImageCount = 0;
        state.lastImageGenDate = today;
    }

    return state;
  } catch (error) {
    console.error("Could not load state", error);
    return getInitialState();
  }
};
